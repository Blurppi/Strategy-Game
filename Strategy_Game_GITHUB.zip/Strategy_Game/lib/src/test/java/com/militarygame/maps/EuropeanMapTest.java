package com.militarygame.maps;

public class EuropeanMapTest {

}
