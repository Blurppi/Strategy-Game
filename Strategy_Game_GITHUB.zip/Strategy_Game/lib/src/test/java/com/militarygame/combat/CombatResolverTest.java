package com.militarygame.combat;

public class CombatResolverTest {

}
