package com.militarygame.map.europe;

public enum TerrainType {
    GRASS("Grass", 1, false),
    FOREST("Forest", 2, false),
    MOUNTAIN("Mountain", 3, false),
    WATER("Water", 2, true),
    DESERT("Desert", 2, false),
    URBAN("Urban", 1, false),
    SWAMP("Swamp", 4, false),
    SNOW("Snow", 3, false);
    
    private String displayName;
    private int movementCost;
    private boolean isWater;
    
    TerrainType(String displayName, int movementCost, boolean isWater) {
        this.displayName = displayName;
        this.movementCost = movementCost;
        this.isWater = isWater;
    }
    
    public String getDisplayName() { return displayName; }
    public int getMovementCost() { return movementCost; }
    public boolean isWater() { return isWater; }
}
