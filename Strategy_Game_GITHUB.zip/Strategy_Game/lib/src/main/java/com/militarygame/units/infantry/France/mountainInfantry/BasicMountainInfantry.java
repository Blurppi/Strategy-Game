package com.militarygame.units.infantry.France.mountainInfantry;

public class BasicMountainInfantry {

}
