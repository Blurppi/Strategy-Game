package com.militarygame.countries;

public class Montenegro {

}
