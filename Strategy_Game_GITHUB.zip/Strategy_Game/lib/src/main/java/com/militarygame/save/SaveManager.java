package com.militarygame.save;

public class SaveManager {

}
