package com.militarygame.core;

public class GameState {

}
