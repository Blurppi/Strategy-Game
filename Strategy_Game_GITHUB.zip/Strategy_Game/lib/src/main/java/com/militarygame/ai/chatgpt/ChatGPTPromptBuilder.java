package com.militarygame.ai.chatgpt;

import com.militarygame.countries.*;
import com.militarygame.map.europe.EuropeMap;
import com.militarygame.units.Units;
import com.militarygame.cities.*;

public class ChatGPTPromptBuilder {
    private Countries country;
    private EuropeMap map;
    
    public ChatGPTPromptBuilder(Countries country, EuropeMap map) {
        this.country = country;
        this.map = map;
    }
    
    public String buildGameStatePrompt() {
        StringBuilder prompt = new StringBuilder();
        
        prompt.append("=== CURRENT GAME STATE ===\n");
        prompt.append("Turn: ").append(map.getCurrentTurn()).append("\n");
        prompt.append("Map Size: ").append(map.getWidth()).append("x").append(map.getHeight()).append("\n\n");
        
        // My status
        prompt.append("=== MY STATUS (").append(country.getName()).append(") ===\n");
        prompt.append("Cities Controlled: ").append(country.getCities().size()).append("\n");
        prompt.append("Cities: ");
        for (City city : country.getCities()) {
            prompt.append(city.getName()).append(" ");
        }
        prompt.append("\n\n");
        
        // My units
        prompt.append("Units: ").append(country.getUnits().size()).append("\n");
        for (Unit unit : country.getUnits()) {
            prompt.append("  - ").append(unit.getName())
                  .append(" at (").append(unit.getCurrentTile().getX())
                  .append(",").append(unit.getCurrentTile().getY())
                  .append(") Health: ").append(unit.getHealth()).append("/").append(unit.getMaxHealth())
                  .append("\n");
        }
        prompt.append("\n");
        
        // Research status
        prompt.append("Research Points: ").append(country.getResearchPoints()).append("\n");
        prompt.append("Available Techs to Research: ");
        for (String tech : country.getResearchTree().getAvailableTechs()) {
            prompt.append(tech).append(", ");
        }
        prompt.append("\n\n");
        
        // Enemy status
        prompt.append("=== ENEMY STATUS ===\n");
        for (Countries enemy : map.getCountries()) {
            if (!enemy.equals(country)) {
                prompt.append(enemy.getName()).append(": ")
                      .append(enemy.getUnits().size()).append(" units, ")
                      .append(enemy.getCities().size()).append(" cities\n");
            }
        }
        prompt.append("\n");
        
        prompt.append("QUESTION: What should my strategy be? Should I attack, defend, or research? " +
                     "Give me 3 specific actions to take this turn.\n");
        
        return prompt.toString();
    }
    
    public String buildUnitMovementPrompt(Units unit) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Unit: ").append(unit.getName()).append("\n");
        prompt.append("Current Position: (").append(unit.getCurrentTile().getX())
              .append(",").append(unit.getCurrentTile().getY()).append(")\n");
        prompt.append("Health: ").append(unit.getHealth()).append("/").append(unit.getMaxHealth()).append("\n");
        prompt.append("Movement Range: ").append(unit.getMovementRange()).append("\n");
        
        prompt.append("Nearby enemies: ");
        // Add nearby enemy info
        
        prompt.append("Where should this unit move? Reply with coordinates (x,y).");
        return prompt.toString();
    }
    
    public String buildAttackDecisionPrompt(Units attacker, Units defender) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("My ").append(attacker.getName())
              .append(" (Attack: ").append(attacker.getAttack())
              .append(", Defense: ").append(attacker.getDefense()).append(")\n");
        prompt.append("vs Enemy ").append(defender.getName())
              .append(" (Attack: ").append(defender.getAttack())
              .append(", Defense: ").append(defender.getDefense()).append(")\n");
        prompt.append("Should I attack? Reply YES or NO with reasoning.");
        return prompt.toString();
    }
}
