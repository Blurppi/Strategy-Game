package com.militarygame.util;

public class Constants {

}
