package com.militarygame.countries;

public class France {

}
