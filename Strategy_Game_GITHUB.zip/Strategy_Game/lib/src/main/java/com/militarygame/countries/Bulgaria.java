package com.militarygame.countries;

public class Bulgaria {

}
