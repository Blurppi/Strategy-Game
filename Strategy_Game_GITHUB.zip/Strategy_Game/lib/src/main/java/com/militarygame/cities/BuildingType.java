package com.militarygame.cities;


public enum BuildingType {
	MILITARY_BASE_LVL1("Military Base Level 1", 250 , 250, 500, 250, 0, 2000, 0, 0, 0, 0, 0, 100),
	MILITARY_BASE_LVL2("Military Base Level 2", 500 , 500, 1000, 500, 0, 3000, 0, 0, 0, 0, 0, 200),
	MILITARY_BASE_LVL3("Military Base Level 3", 750 , 750, 1500, 750, 0, 4000, 0, 0, 0, 0, 0, 300),
	MILITARY_BASE_LVL4("Military Base Level 4", 1000 , 1000, 2000, 1000, 100, 5000, 0, 0, 0, 0, 0, 400),
	MILITARY_BASE_LVL5("Military Base Level 5", 1250 , 1250, 2500, 1250, 200, 6000, 0, 0, 0, 0, 0, 500),
    AIRPORT_LVL1("Airport Level 1", 750, 1000, 1000, 500, 0, 2800, 0, 0, 0, 0, 0, 200),
    AIRPORT_LVL2("Airport Level 2", 1000, 1250, 1250, 750, 0, 3800, 0, 0, 0, 0, 0, 300), 
    AIRPORT_LVL3("Airport Level 3", 1250, 1500, 1500, 1000, 150, 4800, 0, 0, 0, 0, 0, 400), 
    AIRPORT_LVL4("Airport Level 4", 1500, 1750, 1750, 1250, 250, 5800, 0, 0, 0, 0, 0, 500), 
    AIRPORT_LVL5("Airport Level 5", 500, 750, 750, 500, 350, 2000, 0, 0, 0, 0, 0, 150 ), 
    HARBOR_LVL1("Harbor Level 1", 750, 1000, 1000, 750, 0, 3000, 0, 0, 0, 0, 0, 300),
    HARBOR_LVL2("Harbor Level 2", 1000, 1250, 1250, 1000, 0, 4000, 0, 0, 0, 0, 0, 450),
    HARBOR_LVL3("Harbor Level 3", 1250, 1500, 1500, 1250, 0, 5000, 0, 0, 0, 0, 0, 600),
    HARBOR_LVL4("Harbor Level 4", 1500, 1750, 1750, 1500, 50, 6000, 0, 0, 0, 0, 0, 750),
    HARBOR_LVL5("HARBOR Level 5", 1750, 2000, 2000, 1750, 150, 7000, 0, 0, 0, 0, 0, 1000),
    WEAPON_INDUSTRY_LVL1("Weapon Industry Level 1", 400, 350, 350, 250, 150, 1400, 0, 0, 0, 0, 0, 50),
    WEAPON_INDUSTRY_LVL2("Weapon Industry Level 2", 650, 600, 600, 500, 200, 1900, 0, 0, 0, 0, 0, 100),
    WEAPON_INDUSTRY_LVL3("Weapon Industry Level 3", 900, 850, 850, 750, 250, 2400, 0, 0, 0, 0, 0, 150),
    WEAPON_INDUSTRY_LVL4("Weapon Industry Level 4", 1150, 1100, 1100, 1000, 300, 2900, 0, 0, 0, 0, 0, 200),
    WEAPON_INDUSTRY_LVL5("Weapon Industry Level 5", 1300, 1250, 1250, 1150, 350, 3400, 0, 0, 0, 0, 0, 350),
    HOSPITAL_LVL1("Hospital Level 1", 500, 500, 250, 250, 0, 1400, 0, 0, 0, 0, 0, 100),
    HOSPITAL_LVL2("Hospital Level 2", 750, 750, 500, 500, 0, 1900, 0, 0, 0, 0, 0, 200),
    HOSPITAL_LVL3("Hospital Level 3", 1000, 1000, 750, 750, 0, 2400, 0, 0, 0, 0, 0, 300),
    HOSPITAL_LVL4("Hospital Level 4", 1250, 1250, 1000, 1000, 50, 2900, 0, 0, 0, 0, 0, 400),
    HOSPITAL_LVL5("Hospital Level 5", 1500, 1500, 1250, 1250, 100, 3400, 0, 0, 0, 0, 0, 500),
    RADAR_LVL1("Radar Station Level 1", 130, 200, 100, 160, 0, 250, 10, 10, 0, 10, 0, 30),
    RADAR_LVL2("Radar Station Level 2", 250, 300, 200, 260, 0, 350, 20, 20, 0, 20, 0, 40),
    RADAR_LVL3("Radar Station Level 3", 350, 400, 300, 360, 0, 450, 30, 30, 0, 30, 0, 40),
    RECRUITMENT_OFFICE_LVL1("Recruitment Office Level 1", 250, 250, 250, 250, 0, 1400, 0, 0, 0, 0, 0, 50),
    RECRUITMENT_OFFICE_LVL2("Recruitment Office Level 2", 500, 500, 500, 500, 0, 1900, 0, 0, 0, 0, 0, 100 ),
    RECRUITMENT_OFFICE_LVL3("Recruitment Office Level 3", 750, 750, 750, 750, 0, 2400, 0, 0, 0, 0, 0, 150 ),
    RECRUITMENT_OFFICE_LVL4("Recruitment Office Level 4", 1000, 1000, 1000, 1000, 50, 2900, 0, 0, 0, 0, 0, 300),
    RECRUITMENT_OFFICE_LVL5("Recruitment Office Level 5", 1250, 1250, 1250, 1250, 1250, 3400, 0, 0, 0, 0, 0, 450),
    SECRET_WEAPON_INDUSTRY_LVL1("Secret Resaerch Lab Level 1", 750, 400, 250, 750, 500, 3500, 0, 0, 0, 0, 0, 100),
    SECRET_WEAPON_INDUSTRY_LVL2("Secret Resaerch Lab Level 2", 1000, 650, 500, 1000, 750, 4000, 0, 0, 0, 0, 0, 200),
    SECRET_WEAPON_INDUSTRY_LVL3("Secret Resaerch Lab Level 3", 1250, 900, 750, 1250, 1000, 4500, 0, 0, 0, 0, 0, 300),
    SECRET_WEAPON_INDUSTRY_LVL4("Secret Resaerch Lab Level 4", 1500, 1150, 1000, 1500, 1250, 5000, 0, 0, 0, 0, 0, 400),
    SECRET_WEAPON_INDUSTRY_LVL5("Secret Resaerch Lab Level 5", 1750, 1300, 1250, 1750, 1500, 6000, 0, 0, 0, 0, 0, 500),
    BUNKER_LVL1("Bunker Level 1", 500, 750, 750, 0, 0, 2000, 0, 0, 0, 0, 0, 100),
    BUNKER_LVL2("Bunker Level 2", 750, 1000, 1000, 250, 0, 2500, 0, 0, 0, 0, 0, 200),
    BUNKER_LVL3("Bunker Level 3", 1000, 1250, 1250, 500, 0, 3000, 0, 0, 0, 0, 0, 300),
    BUNKER_LVL4("Bunker Level 4", 1250, 1500, 1500, 750, 100, 4000, 0, 0, 0, 0, 0, 400),
    BUNKER_LVL5("Bunker Level 5", 1500, 1750, 1750, 1000, 150, 5000, 0, 0, 0, 0, 0, 500),
    COMBAT_OUTPOST_LVL1("Combat Outpost Level 1", 500, 750, 100, 0, 0, 2000, 0, 0, 0, 0, 0, 50),
    COMBAT_OUTPOST_LVL2("Combat Outpost Level 2", 600, 850, 200, 0, 0, 3000, 0, 0, 0, 0, 0, 100),
    COMBAT_OUTPOST_LVL3("Combat Outpost Level 3", 700, 950, 300, 0, 0, 4000, 0, 0, 0, 0, 0, 200),
    AERODROME("aerodrome", 700, 900, 800, 200, 0, 2500, 0, 0, 0, 0, 0, 100),
    FIELD_HOSPITAL_LVL1("Field Hospital Level 1", 750, 750, 50, 50, 0, 1300, 0, 0, 0, 0, 0, 50),
    FIELD_HOSPITAL_LVL2("Field Hospital Level 2", 1000, 1000, 100, 100, 0, 1800, 0, 0, 0, 0, 0, 100),
    FIELD_HOSPITAL_LVL3("Field Hospital Level 3", 1250, 1250, 150, 150, 0, 2300, 0, 0, 0, 0, 0, 150),
    PONTOON("Pontoon", 250, 250, 500, 0, 0, 1300, 0, 0, 0, 0, 0, 50),
    MILITARY_LOGISTICS("Military Logistics", 250, 250, 250, 0, 0, 500, 0, 0, 0, 0, 0, 50),
    MERCENARY_OUTPOST_LVL1("Mercenary Outpost Level 1", 500, 500, 1000, 250, 0, 5000, 0, 0, 0, 0, 0, 50),
    MERCENARY_OUTPOST_LVL2("Mercenary Outpost Level 2", 750, 750, 1250, 500, 0, 6000, 0, 0, 0, 0, 0, 100),
    MERCENARY_OUTPOST_LVL3("Mercenary Outpost Level 3", 1000, 1000, 1500, 750, 10, 7000, 0, 0, 0, 0, 0, 150),
    GUN_EMPLACEMENT_LVL1("Gun Emplacement Level 1", 150, 350, 100, 175, 0, 500, 0, 25, 0, 25, 0, 50),
	GUN_EMPLACEMENT_LVL2("Gun Emplacement Level 2", 300, 500, 200, 275, 0, 1000, 0, 50, 0, 50, 0, 100 ),
	GUN_EMPLACEMENT_LVL3("Gun Emplacement Level 3", 450, 650, 300, 375, 0, 1500, 0, 75, 0, 75, 0, 150),
	CITY_FARM_LVL1("Urban Farm Level 1", 150, 25, 10, 0, 0, 1000, 25, 15, 5, 0, 0, 0),
	CITY_FARM_LVL2("Urban Farm Level 2", 200, 50, 20, 0, 0, 1250, 50, 30, 10, 0, 0, 50),
	CITY_FARM_LVL3("Urban Farm Level 3", 250, 75, 30, 0, 0, 1500, 75, 45, 15, 0, 0, 100),
	CITY_FARM_LVL4("Urban Farm Level 4", 300, 100, 40, 0, 0, 1750, 100, 60, 20, 0, 0, 150),
	CITY_FARM_LVL5("Urban Farm Level 5", 350, 125, 50, 0, 0, 2000, 125, 75, 25, 0, 0, 200),
	RURAL_FARM_LVL1("Countryside Farm Level 1", 100, 25, 10, 0, 0, 500, 15, 5, 10, 0, 0, 0),
	RURAL_FARM_LVL2("Countryside Farm Level 2", 200, 50, 20, 0, 0, 1000, 30, 15, 20, 0, 0, 100),
	RURAL_FARM_LVL3("Countryside Farm Level 3", 300, 75, 30, 0, 0, 1500, 45, 25, 30, 0, 0, 200),
	COMPONENTS_INDUSTRY_LVL1("Components Industry Level 1", 150, 25, 10, 0, 0, 1000, 25, 15, 5, 0, 0, 0),
	COMPONENTS_INDUSTRY_LVL2("Components Industry Level 2", 200, 50, 20, 0, 0, 1250, 50, 30, 10, 0, 0, 50),
	COMPONENTS_INDUSTRY_LVL3("Components Industry Level 3", 250, 75, 30, 0, 0, 1500, 75, 45, 15, 0, 0, 100),
	COMPONENTS_INDUSTRY_LVL4("Components Industry Level 4", 300, 100, 40, 0, 0, 1750, 100, 60, 20, 0, 0, 150),
	COMPONENTS_INDUSTRY_LVL5("Components Industry Level 5", 350, 125, 50, 0, 0, 2000, 125, 75, 25, 0, 0, 200),
	RAFFINERY_LVL1("Raffinery Level 1", 150, 25, 10, 0, 0, 1000, 25, 15, 5, 0, 0, 0),
	RAFFINERY_LVL2("Raffinery Level 2", 200, 50, 20, 0, 0, 1250, 50, 30, 10, 0, 0, 50),
	RAFFINERY_LVL3("Raffinery Level 3", 250, 75, 30, 0, 0, 1500, 75, 45, 15, 0, 0, 100),
	RAFFINERY_LVL4("Raffinery Level 4", 300, 100, 40, 0, 0, 1750, 100, 60, 20, 0, 0, 150),
	RAFFINERY_LVL5("Raffinery Level 5", 350, 125, 50, 0, 0, 2000, 125, 75, 25, 0, 0, 200),
	ELECTRONICS_INDUSTRY_LVL1("Electronics Industry Level 1", 150, 25, 10, 0, 0, 1000, 25, 15, 5, 0, 0, 0),
	ELECTRONICS_INDUSTRY_LVL2("Electronics Industry Level 2", 200, 50, 20, 0, 0, 1250, 50, 30, 10, 0, 0, 50),
	ELECTRONICS_INDUSTRY_LVL3("Electronics Industry Level 3", 250, 75, 30, 0, 0, 1500, 75, 45, 15, 0, 0, 100),
	ELECTRONICS_INDUSTRY_LVL4("Electronics Industry Level 4", 300, 100, 40, 0, 0, 1750, 100, 60, 20, 0, 0, 150),
	ELECTRONICS_INDUSTRY_LVL5("Electronics Industry Level 5", 350, 125, 50, 0, 0, 2000, 125, 75, 25, 0, 0, 200),
	RARE_MATERIALS_INDUSTRY_LVL1("Rare Materials Industry Level 1", 150, 25, 10, 0, 0, 1000, 25, 15, 5, 0, 0, 0),
	RARE_MATERIALS_INDUSTRY_LVL2("Rare Materials Industry Level 2", 200, 50, 20, 0, 0, 1250, 50, 30, 10, 0, 0, 50),
	RARE_MATERIALS_INDUSTRY_LVL3("Rare Materials Industry Level 3", 250, 75, 30, 0, 0, 1500, 75, 45, 15, 0, 0, 100),
	RARE_MATERIALS_INDUSTRY_LVL4("Rare Materials Industry Level 4", 300, 100, 40, 0, 0, 1750, 100, 60, 20, 0, 0, 150),
	RARE_MATERIALS_INDUSTRY_LVL5("Rare Materials Industry Level 5", 350, 125, 50, 0, 0, 2000, 125, 75, 25, 0, 0, 200);
	

	// Inner class for costs
    static class Cost {
        public int supplies, components, fuel, electronics, rareMaterials, money;

        Cost(int supplies, int components, int fuel,
             int electronics, int rareMaterials, int money) {
            this.supplies = supplies;
            this.components = components;
            this.fuel = fuel;
            this.electronics = electronics;
            this.rareMaterials = rareMaterials;
            this.money = money;
        }
    }

    private String name;
    private Cost buildCost;
    private Cost maintenanceCost;

    // Enum constructor
    BuildingType(String name,
                 int buildCostSupplies, int buildCostComponents, int buildCostFuel,
                 int buildCostElectronics, int buildCostRareMaterials, int buildCostMoney,
                 int maintenanceCostSupplies, int maintenanceCostComponents, int maintenanceCostFuel,
                 int maintenanceCostElectronics, int maintenanceCostRareMaterials, int maintenanceCostMoney) {

        this.name = name;

        this.buildCost = new Cost(
            buildCostSupplies, buildCostComponents, buildCostFuel,
            buildCostElectronics, buildCostRareMaterials, buildCostMoney
        );

        this.maintenanceCost = new Cost(
            maintenanceCostSupplies, maintenanceCostComponents, maintenanceCostFuel,
            maintenanceCostElectronics, maintenanceCostRareMaterials, maintenanceCostMoney
        );
    }

    public String getName() {
        return name;
    }

    public Cost getBuildCost() {
        return buildCost;
    }

    public Cost getMaintenanceCost() {
        return maintenanceCost;
    }

    /**
     * Get the base level number from the building type (1-5)
     */
    public int getLevel() {
        String nameUpper = this.name.toUpperCase();
        if (nameUpper.contains("LEVEL 5")) return 5;
        if (nameUpper.contains("LEVEL 4")) return 4;
        if (nameUpper.contains("LEVEL 3")) return 3;
        if (nameUpper.contains("LEVEL 2")) return 2;
        if (nameUpper.contains("LEVEL 1")) return 1;
        return 0; // Special buildings without levels
    }

    /**
     * Get the base building type (e.g., MILITARY_BASE from MILITARY_BASE_LVL3)
     */
    public String getBaseName() {
        String nameUpper = this.name.toUpperCase();
        if (nameUpper.contains("LEVEL")) {
            return nameUpper.replaceAll(" LEVEL \\d+", "").toLowerCase();
        }
        return this.name.toLowerCase();
    }

    /**
     * Check if this building can be upgraded
     */
    public BuildingType getNextLevel() {
        int currentLevel = getLevel();
        if (currentLevel >= 5) return null;

        String baseName = getBaseName();
        int nextLevel = currentLevel + 1;

        // Find the next level building
        for (BuildingType type : BuildingType.values()) {
            if (type.getBaseName().equals(baseName) && type.getLevel() == nextLevel) {
                return type;
            }
        }
        return null;
    }
}