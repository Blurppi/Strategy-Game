package com.militarygame.units.aerial.weapons;

import java.util.*;

public class WeaponInventory {
    private Map<String, Weapons> availableWeapons;
    private Map<String, Boolean> researchedWeapons;
    private List<WeaponsTemplate> templates;
    
    public WeaponInventory() {
        this.availableWeapons = new HashMap<>();
        this.researchedWeapons = new HashMap<>();
        this.templates = new ArrayList<>();
        
        initializeBaseWeapons();
    }
    
    /**
     * Initialize starting weapons
     */
    private void initializeBaseWeapons() {
        // Starting weapons for Mirage 2000
        addWeapon("Magic 1", new Weapons("Magic 1", WeaponsType.AIR_AIR_MISSILE, 18, 6, 1, 2), true);
        addWeapon("Matra 530", new Weapons("Matra 530", WeaponsType.AIR_AIR_MISSILE, 28, 10, 1, 2), true);
        addWeapon("30mm Cannon", new Weapons("30mm Cannon", WeaponsType.CANNON, 8, 1, 20, 0), true);
        addWeapon("Fuel Tank", new Weapons("Fuel Tank", WeaponsType.ROCKET, 0, 0, 0, 0), true);
        addWeapon("Rockets", new Weapons("Rocket", WeaponsType.ROCKET, 8, 1, 20, 1), true);
        
        // Locked until researched
        addWeapon("Super Matra 530", new Weapons("Super Matra 530", WeaponsType.AIR_AIR_MISSILE, 32, 12, 1, 2), false);
        addWeapon("Magic 2", new Weapons("Magic 2", WeaponsType.AIR_AIR_MISSILE, 22, 7, 1, 2), false);
        addWeapon("MICA AA", new Weapons("MICA AA", WeaponsType.AIR_AIR_MISSILE, 35, 14, 1, 3), false);
        addWeapon("MICA IR", new Weapons("MICA IR", WeaponsType.AIR_AIR_MISSILE, 33, 13, 1, 3), false);
        addWeapon("Meteor", new Weapons("Meteor", WeaponsType.AIR_AIR_MISSILE, 40, 20, 1, 3), false);

    }
    
    /**
     * Add weapon to inventory
     */
    public void addWeapon(String weaponName, Weapons weapon, boolean isResearched) {
        availableWeapons.put(weaponName, weapon);
        researchedWeapons.put(weaponName, isResearched);
    }
    
    /**
     * Research a weapon
     */
    public boolean researchWeapon(String weaponName) {
        if (availableWeapons.containsKey(weaponName)) {
            researchedWeapons.put(weaponName, true);
            System.out.println("✓ Researched: " + weaponName);
            return true;
        }
        System.out.println("✗ Weapon not found: " + weaponName);
        return false;
    }
    
    /**
     * Check if weapon is researched
     */
    public boolean isWeaponResearched(String weaponName) {
        return researchedWeapons.getOrDefault(weaponName, false);
    }
    
    /**
     * Get weapon by name
     */
    public Weapons getWeapon(String weaponName) {
        return availableWeapons.get(weaponName);
    }
    
    /**
     * Get all available weapons
     */
    public List<String> getAvailableWeapons() {
        List<String> weapons = new ArrayList<>();
        for (String weaponName : availableWeapons.keySet()) {
            if (isWeaponResearched(weaponName)) {
                weapons.add(weaponName);
            }
        }
        return weapons;
    }
    
    /**
     * Get all weapons (researched and locked)
     */
    public List<String> getAllWeapons() {
        return new ArrayList<>(availableWeapons.keySet());
    }
    
    /**
     * Create a weapon template
     */
    public WeaponsTemplate createTemplate(String templateName, String aircraftType) {
        WeaponsTemplate template = new WeaponsTemplate(templateName, aircraftType);
        templates.add(template);
        System.out.println("✓ Created template: " + templateName);
        return template;
    }
    
    /**
     * Get template by name
     */
    public WeaponsTemplate getTemplate(String templateName) {
        for (WeaponsTemplate template : templates) {
            if (template.getName().equalsIgnoreCase(templateName)) {
                return template;
            }
        }
        return null;
    }
    
    /**
     * Get all templates for aircraft type
     */
    public List<WeaponsTemplate> getTemplates(String aircraftType) {
        List<WeaponsTemplate> result = new ArrayList<>();
        for (WeaponsTemplate template : templates) {
            if (template.getAircraftType().equalsIgnoreCase(aircraftType)) {
                result.add(template);
            }
        }
        return result;
    }
    
    /**
     * Delete a template
     */
    public boolean deleteTemplate(String templateName) {
        for (WeaponsTemplate template : templates) {
            if (template.getName().equalsIgnoreCase(templateName)) {
                templates.remove(template);
                System.out.println("✓ Deleted template: " + templateName);
                return true;
            }
        }
        return false;
    }
    
    /**
     * List all templates
     */
    public void listTemplates() {
        if (templates.isEmpty()) {
            System.out.println("No templates available");
            return;
        }
        
        System.out.println("\n=== Weapon Templates ===");
        for (WeaponsTemplate template : templates) {
            System.out.println(template.getTemplateInfo());
        }
    }
    
    public List<WeaponsTemplate> getAllTemplates() {
        return new ArrayList<>(templates);
    }
}