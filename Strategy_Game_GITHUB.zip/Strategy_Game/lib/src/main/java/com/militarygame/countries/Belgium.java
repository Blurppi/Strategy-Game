package com.militarygame.countries;

public class Belgium {

}
