package com.militarygame.countries;

public class Ukraine {

}
