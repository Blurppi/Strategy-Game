package com.militarygame.map.europe;

public class EuropeTile {
    private int x, y;
    private EuropeTerrainType terrain;
    private County region;
    
    public EuropeTile(int x, int y, EuropeTerrainType terrain) {
        this.x = x;
        this.y = y;
        this.terrain = terrain;
        this.region = null;
    }
    
    public int getX() { return x; }
    public int getY() { return y; }
    public EuropeTerrainType getTerrain() { return terrain; }
    public void setTerrain(EuropeTerrainType terrain) { this.terrain = terrain; }
    
    public County getRegion() { return region; }
    public void setRegion(County region) { this.region = region; }
}
