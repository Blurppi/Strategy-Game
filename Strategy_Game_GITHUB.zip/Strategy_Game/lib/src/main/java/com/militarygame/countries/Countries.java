
package com.militarygame.countries;

import com.militarygame.researchTree.ResearchTreeFrance;
import com.militarygame.cities.Cities;
import com.militarygame.map.europe.EuropeMap;
import com.militarygame.units.Units;
import java.awt.Color;
import java.util.*;

public class Countries {
    private String name;
    private CountryType type;
    private Color color;
    
    // Territory
    private List<Cities> controlledCities;
    private List<EuropeMap> controlledRegions;
    
    // Military
    private List<Units> units;
    private int militaryPower; // Overall military strength
    
    // Research and technology
    private ResearchTreeFrance researchTree;
    private int researchPoints;
    private int researchPointsPerTurn;
    
    // Economy
    private int money;
    private int moneyPerTurn;
    
    // Statistics
    private int population;
    private int morale;
    private boolean isPlayerControlled;
    private boolean isAlive;
    
    public Countries(String name, CountryType type) {
        this.name = name;
        this.type = type;
        this.color = getColorForCountry(type);
        
        this.controlledCities = new ArrayList<>();
        this.controlledRegions = new ArrayList<>();
        this.units = new ArrayList<>();
        
        this.researchTree = new ResearchTreeFrance();
        this.researchPoints = 1000; // Starting research points
        this.researchPointsPerTurn = 50;
        
        this.money = 5000; // Starting money
        this.moneyPerTurn = 100;
        
        this.population = 0;
        this.morale = 75;
        this.militaryPower = 0;
        
        this.isPlayerControlled = false;
        this.isAlive = true;
    }
    
    /**
     * Get color for country based on type
     */
    private Color getColorForCountry(CountryType type) {
        return switch (type) {
            case FRANCE -> new Color(0, 85, 164);           // Blue
            case RUSSIA -> new Color(239, 65, 53);          // Red
            case GERMANY -> new Color(33, 33, 33);          // Dark Gray
            case UK -> new Color(12, 35, 69);   // Navy Blue
            case ITALY -> new Color(206, 17, 38);           // Red
            case SPAIN -> new Color(255, 196, 0);           // Gold
            case POLAND -> new Color(255, 255, 255);        // White
            case TURKEY -> new Color(206, 17, 38);          // Red
            case UKRAINE -> new Color(0, 87, 184);          // Blue
            default -> new Color(128, 128, 128);            // Gray
        };
    }
    
    /**
     * Add a city to the country
     */
    public void addCity(Cities city) {
        if (city != null) {
            controlledCities.add(city);
            city.setOwner(this);
            
            // Add population from city
            population += city.getStats().getPopulation();
            
            // Add research points from city
            researchPointsPerTurn += city.getStats().getResearchPointsPerTurn();
            
            System.out.println("✓ " + city.getName() + " added to " + name);
        }
    }
    
    /**
     * Remove a city from the country
     */
    public void removeCity(Cities city) {
        if (controlledCities.remove(city)) {
            population -= city.getStats().getPopulation();
            researchPointsPerTurn -= city.getStats().getResearchPointsPerTurn();
            System.out.println("✗ " + city.getName() + " lost by " + name);
        }
    }
    
    /**
     * Conquer a city from another country
     */
    public void conquerCity(Cities city, Countries previousOwner) {
        if (previousOwner != null) {
            previousOwner.removeCity(city);
        }
        addCity(city);
        city.getStats().setMorale(40); // Reduced morale after conquest
        System.out.println("⚔ " + name + " conquered " + city.getName());
    }
    
    /**
     * Add a region to the country
     */
    public void addRegion(EuropeMap region) {
        if (region != null && !controlledRegions.contains(region)) {
            controlledRegions.add(region);
            region.setOwner(this);
            System.out.println("✓ " + region.getName() + " added to " + name);
        }
    }
    
    /**
     * Remove a region from the country
     */
    public void removeRegion(EuropeMap region) {
        if (controlledRegions.remove(region)) {
            System.out.println("✗ " + region.getName() + " lost by " + name);
        }
    }
    
    /**
     * Add a unit to the country
     */
    public void addUnit(Units unit) {
        if (unit != null) {
            units.add(unit);
            unit.setOwner(this);
            updateMilitaryPower();
            System.out.println("✓ Unit " + unit.getName() + " added to " + name);
        }
    }
    
    /**
     * Remove a unit from the country
     */
    public void removeUnit(Units unit) {
        if (units.remove(unit)) {
            updateMilitaryPower();
            System.out.println("✗ Unit " + unit.getName() + " removed from " + name);
        }
    }
    
    /**
     * Update military power based on units
     */
    private void updateMilitaryPower() {
        militaryPower = 0;
        for (Units unit : units) {
            militaryPower += unit.getAttack() + unit.getDefense();
        }
    }
    
    /**
     * Add research points
     */
    public void addResearchPoints(int points) {
        researchPoints += points;
    }
    
    /**
     * Consume research points for technology
     */
    public boolean consumeResearchPoints(int points) {
        if (researchPoints >= points) {
            researchPoints -= points;
            return true;
        }
        return false;
    }
    
    /**
     * Research a technology
     */
    public boolean researchTech(String techName) {
        // Get cost from research tree
        ResearchTreeFrance.TechNode tech = researchTree.getTech(techName);
        
        if (tech != null) {
            int cost = tech.getResearchCost();
            
            if (consumeResearchPoints(cost)) {
                researchTree.researchTech(techName);
                System.out.println("✓ " + name + " researched " + techName);
                return true;
            }
        }
        System.out.println("✗ Not enough research points for " + techName);
        return false;
    }
    
    /**
     * Add money
     */
    public void addMoney(int amount) {
        money += amount;
    }
    
    /**
     * Consume money
     */
    public boolean consumeMoney(int amount) {
        if (money >= amount) {
            money -= amount;
            return true;
        }
        return false;
    }
    
    /**
     * Update country at the end of each turn
     */
    public void update() {
        // Update all cities
        for (Cities city : controlledCities) {
            city.update();
            
            // Collect resources from cities
            researchPoints += city.getStats().getResearchPointsPerTurn();
            money += 100; // Base money per turn (you can enhance this)
        }
        
        // Update units
        for (Units unit : units) {
            unit.update();
        }
        
        // Update population
        population = 0;
        for (Cities city : controlledCities) {
            population += city.getStats().getPopulation();
        }
        
        // Update morale
        if (morale < 100) {
            morale = Math.min(morale + 1, 100);
        }
        
        // Check if country is still alive
        if (controlledCities.isEmpty() && units.isEmpty()) {
            isAlive = false;
            System.out.println("💀 " + name + " has been defeated!");
        }
    }
    
    /**
     * Get country statistics for display
     */
    public String getStatistics() {
        return String.format(
            "%s - Cities: %d, Units: %d, Population: %d, Military Power: %d, Research Points: %d, Money: %d",
            name, controlledCities.size(), units.size(), population, militaryPower, researchPoints, money
        );
    }
    
    /**
     * Check if country is still alive
     */
    public boolean isAlive() {
        return isAlive && !controlledCities.isEmpty();
    }
    
    // ===== GETTERS & SETTERS =====
    
    public String getName() { return name; }
    public CountryType getType() { return type; }
    public Color getColor() { return color; }
    
    public List<Cities> getCities() { return new ArrayList<>(controlledCities); }
    public int getCityCount() { return controlledCities.size(); }
    
    public List<EuropeMap> getRegions() { return new ArrayList<>(controlledRegions); }
    public int getRegionCount() { return controlledRegions.size(); }
    
    public List<Units> getUnits() { return new ArrayList<>(units); }
    public int getUnitCount() { return units.size(); }
    public int getMilitaryPower() { return militaryPower; }
    
    public ResearchTreeFrance getResearchTree() { return researchTree; }
    public int getResearchPoints() { return researchPoints; }
    public void setResearchPoints(int points) { this.researchPoints = points; }
    public int getResearchPointsPerTurn() { return researchPointsPerTurn; }
    
    public int getMoney() { return money; }
    public void setMoney(int amount) { this.money = amount; }
    public int getMoneyPerTurn() { return moneyPerTurn; }
    public void setMoneyPerTurn(int amount) { this.moneyPerTurn = amount; }
    
    public int getPopulation() { return population; }
    public int getMorale() { return morale; }
    public void setMorale(int morale) { this.morale = Math.max(0, Math.min(morale, 100)); }
    
    public boolean isPlayerControlled() { return isPlayerControlled; }
    public void setPlayerControlled(boolean controlled) { this.isPlayerControlled = controlled; }
}