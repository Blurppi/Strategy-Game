package com.militarygame.rendering;

public class UiRenderer {

}
