package com.militarygame.map.europe;

import com.militarygame.countries.*;
import com.militarygame.cities.Cities;
import java.util.*;

public class EuropeMap {
    private int width;
    private int height;
    private EuropeTile[][] tiles;
    private List<Countries> countries;
    private List<Cities> cities;
    private List<County> allRegions;
    private Map<String, List<County>> countryRegions;
    private MapData mapData;
    private int currentTurn;
    
    public EuropeMap(int width, int height) {
        this.width = width;
        this.height = height;
        this.tiles = new Tile[height][width];
        this.countries = new ArrayList<>();
        this.cities = new ArrayList<>();
        this.allRegions = new ArrayList<>();
        this.countryRegions = new HashMap<>();
        this.mapData = new MapData();
        this.currentTurn = 1;
        
        initializeTiles();
    }
    
    private void initializeTiles() {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                tiles[y][x] = new EuropeTile(x, y, EuropeTerrainType.GRASS);
            }
        }
        System.out.println("✓ Tiles initialized: " + width + "x" + height);
    }
    
    /**
     * Initialize regions for a country
     */
    public void addCountryRegions(Countries country) {
        List<County> regions = mapData.getRegionsForCountry(country.getName());
        
        for (County region : regions) {
            region.setOwner(country);
            allRegions.add(region);
            
            // Add tiles to region based on coordinates
            addTilesToRegion(region);
        }
        
        countryRegions.put(country.getName(), regions);
        System.out.println("✓ Added " + regions.size() + " regions to " + country.getName());
    }
    
    /**
     * Add tiles to a region based on its coordinates and size
     */
    private void addTilesToRegion(County region) {
        int startX = region.getX();
        int startY = region.getY();
        int endX = Math.min(startX + region.getWidth(), width);
        int endY = Math.min(startY + region.getHeight(), height);
        
        for (int y = startY; y < endY; y++) {
            for (int x = startX; x < endX; x++) {
                if (x >= 0 && x < width && y >= 0 && y < height) {
                    EuropeTile tile = tiles[y][x];
                    region.addTile(tile);
                    tile.setRegion(region); // Update tile to know which region it belongs to
                }
            }
        }
    }
    
    // Getters
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public EuropeTile getTile(int x, int y) { 
        if (x >= 0 && x < width && y >= 0 && y < height) {
            return tiles[y][x]; 
        }
        return null;
    }
    public EuropeTile[][] getTiles() { return tiles; }
    public List<Countries> getCountries() { return new ArrayList<>(countries); }
    public List<Cities> getCities() { return new ArrayList<>(cities); }
    public List<County> getRegions() { return new ArrayList<>(allRegions); }
    public List<County> getRegionsForCountry(String countryName) {
        return countryRegions.getOrDefault(countryName, new ArrayList<>());
    }
    public int getCurrentTurn() { return currentTurn; }
    
    public void setCountries(List<Countries> countries) {
        this.countries = countries;
        
        // Initialize regions for each country
        for (Countries country : countries) {
            addCountryRegions(country);
        }
    }
    
    public void addCity(Cities city) {
        cities.add(city);
    }
    
    public void addCountry(Countries country) {
        countries.add(country);
        addCountryRegions(country);
    }
}
