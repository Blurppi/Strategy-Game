package com.militarygame.unitType;

public class France {

}
