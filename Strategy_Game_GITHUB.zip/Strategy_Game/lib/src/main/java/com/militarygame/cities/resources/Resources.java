package com.militarygame.cities.resources;

public class Resources {
    private ResourceType type;
    private int amount;
    private int maxStorage;
    private int productionPerTurn;
    private int consumptionPerTurn;
    
    public Resources(ResourceType type, int maxStorage) {
        this.type = type;
        this.maxStorage = maxStorage;
        this.amount = maxStorage / 2; // Start at 50%
        this.productionPerTurn = 0;
        this.consumptionPerTurn = 0;
    }
    
    /**
     * Add resources to this resource
     */
    public void addProduction(int amount) {
        this.amount = Math.min(this.amount + amount, maxStorage);
    }
    
    /**
     * Consume resources
     */
    public boolean consume(int amount) {
        if (this.amount >= amount) {
            this.amount -= amount;
            return true;
        }
        return false;
    }
    
    /**
     * Update production each turn
     */
    public void updateProduction() {
        int net = productionPerTurn - consumptionPerTurn;
        this.amount = Math.max(0, Math.min(this.amount + net, maxStorage));
    }
    
    /**
     * Get percentage of storage used
     */
    public int getStoragePercentage() {
        return (amount * 100) / maxStorage;
    }
    
    /**
     * Check if at max capacity
     */
    public boolean isAtMaxCapacity() {
        return amount >= maxStorage;
    }
    
    /**
     * Check if critically low
     */
    public boolean isCriticallyLow() {
        return amount < (maxStorage / 10); // Less than 10%
    }
    
    // ===== GETTERS & SETTERS =====
    
    public ResourceType getType() { return type; }
    
    public int getAmount() { return amount; }
    public void setAmount(int amount) { 
        this.amount = Math.min(Math.max(amount, 0), maxStorage); 
    }
    public void addAmount(int amount) {
        this.amount = Math.min(this.amount + amount, maxStorage);
    }
    
    public int getMaxStorage() { return maxStorage; }
    public void setMaxStorage(int maxStorage) { this.maxStorage = maxStorage; }
    
    public int getProductionPerTurn() { return productionPerTurn; }
    public void setProductionPerTurn(int production) { 
        this.productionPerTurn = Math.max(production, 0); 
    }
    
    public int getConsumptionPerTurn() { return consumptionPerTurn; }
    public void setConsumptionPerTurn(int consumption) { 
        this.consumptionPerTurn = Math.max(consumption, 0); 
    }
    public void addConsumption(int amount) { 
        this.consumptionPerTurn += amount; 
    }
}
