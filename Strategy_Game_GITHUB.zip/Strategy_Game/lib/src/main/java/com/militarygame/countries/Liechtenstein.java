package com.militarygame.countries;

public class Liechtenstein {

}
