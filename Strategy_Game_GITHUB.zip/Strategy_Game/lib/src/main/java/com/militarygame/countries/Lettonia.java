package com.militarygame.countries;

public class Lettonia {

}
