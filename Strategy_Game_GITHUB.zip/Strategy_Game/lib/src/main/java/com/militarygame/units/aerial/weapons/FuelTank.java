package com.militarygame.units.aerial.weapons;

public class FuelTank {
    private String name;
    private int capacity; // litres
    private int currentFuel;
    
    public FuelTank(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.currentFuel = capacity;
    }
    
    public void refill() {
        this.currentFuel = capacity;
    }
    
    public void consumeFuel(int amount) {
        this.currentFuel = Math.max(0, currentFuel - amount);
    }
    
    public String getName() { return name; }
    public int getCapacity() { return capacity; }
    public int getCurrentFuel() { return currentFuel; }
}