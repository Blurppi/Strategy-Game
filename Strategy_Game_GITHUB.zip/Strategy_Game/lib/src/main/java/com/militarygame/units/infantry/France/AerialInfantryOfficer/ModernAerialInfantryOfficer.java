package com.militarygame.units.infantry.France.AerialInfantryOfficer;

public class ModernAerialInfantryOfficer {

}
