package com.militarygame.save;

public class SaveFormat {

}
