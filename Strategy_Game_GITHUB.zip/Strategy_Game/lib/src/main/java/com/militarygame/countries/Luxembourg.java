package com.militarygame.countries;

public class Luxembourg {

}
