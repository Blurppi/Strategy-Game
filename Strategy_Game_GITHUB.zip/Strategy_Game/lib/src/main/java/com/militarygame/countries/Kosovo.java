package com.militarygame.countries;

public class Kosovo {

}
