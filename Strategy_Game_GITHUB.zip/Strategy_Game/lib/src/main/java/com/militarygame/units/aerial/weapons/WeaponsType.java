package com.militarygame.units.aerial.weapons;

public enum WeaponsType {
    AIR_AIR_MISSILE("Air-to-Air Missile", 1),
    AIR_GROUND_MISSILE("Air-to-Ground Missile", 2),
    CANNON("Cannon", 3),
    ROCKET("Rocket", 4),
    BOMB("Bomb", 5),
    TORPEDO("Torpedo", 6);
    
    private String displayName;
    private int category;
    
    WeaponsType(String displayName, int category) {
        this.displayName = displayName;
        this.category = category;
    }
    
    public String getDisplayName() { return displayName; }
    public int getCategory() { return category; }
}