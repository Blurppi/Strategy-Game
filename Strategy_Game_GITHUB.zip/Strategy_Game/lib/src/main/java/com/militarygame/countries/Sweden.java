package com.militarygame.countries;

public class Sweden {

}
