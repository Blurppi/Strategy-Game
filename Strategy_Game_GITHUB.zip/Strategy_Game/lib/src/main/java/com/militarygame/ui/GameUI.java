package com.militarygame.ui;

public class GameUI {

}
