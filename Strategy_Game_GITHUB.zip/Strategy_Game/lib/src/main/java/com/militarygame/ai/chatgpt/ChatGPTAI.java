package com.militarygame.ai.chatgpt;

import com.militarygame.ai.AIcontroller;
import com.militarygame.ai.AIstrategy;
import com.militarygame.ai.AIdifficulty;
import com.militarygame.countries.*;
import com.militarygame.map.europe.EuropeMap;
import com.theokanning.openai.service.OpenAiService;
import com.theokanning.openai.completion.chat.ChatCompletionRequest;
import com.theokanning.openai.completion.chat.ChatMessage;

import java.util.ArrayList;
import java.util.List;
import java.time.Duration;

public class ChatGPTAI extends AIcontroller {
    private OpenAiService service;
    private ChatGPTPromptBuilder promptBuilder;
    private ChatGPTResponseParser responseParser;
    private String model;
    
    public ChatGPTAI(Countries country, EuropeMap map, AIstrategy strategy, 
                     AIdifficulty difficulty, String apiKey) {
        super(country, map, strategy, difficulty);
        
        this.service = new OpenAiService(apiKey, Duration.ofSeconds(30));
        this.promptBuilder = new ChatGPTPromptBuilder(country, map);
        this.responseParser = new ChatGPTResponseParser();
        
        // Choose model based on difficulty
        this.model = difficulty == AIdifficulty.IMPOSSIBLE ? "gpt-4" : "gpt-3.5-turbo";
    }
    
    /**
     * Ask ChatGPT for a decision
     */
    public String askChatGPT(String systemPrompt, String userPrompt) {
        List<ChatMessage> messages = new ArrayList<>();
        
        messages.add(new ChatMessage("system", systemPrompt));
        messages.add(new ChatMessage("user", userPrompt));
        
        ChatCompletionRequest request = ChatCompletionRequest.builder()
            .model(model)
            .messages(messages)
            .temperature(0.7)
            .maxTokens(difficulty.getTokenBudget())
            .build();
        
        try {
            String response = service.createChatCompletion(request)
                .getChoices()
                .get(0)
                .getMessage()
                .getContent();
            
            return response;
        } catch (Exception e) {
            System.err.println("Error calling ChatGPT: " + e.getMessage());
            return null;
        }
    }
    
    @Override
    public void takeTurn() {
        System.out.println("[" + country.getName() + " AI (ChatGPT)] Taking turn...");
        
        // Build comprehensive game state
        String gameState = promptBuilder.buildGameStatePrompt();
        
        // Ask ChatGPT for overall strategy
        String systemPrompt = "You are a military strategist in a European war game. " +
                            "You control " + country.getName() + ". " +
                            "Make strategic decisions about unit movements, attacks, and technology research. " +
                            "Be concise and tactical.";
        
        String aiAnalysis = askChatGPT(systemPrompt, gameState);
        System.out.println("[" + country.getName() + " Analysis]: " + aiAnalysis);
        
        // Parse and execute decisions
        responseParser.parseAndExecuteDecisions(aiAnalysis, decisionExecutor);
        
        // Also use sub-AIs for specific decisions
        super.takeTurn();
    }
    
    @Override
    public void shutdown() {
        service.shutdownExecutor();
    }
}