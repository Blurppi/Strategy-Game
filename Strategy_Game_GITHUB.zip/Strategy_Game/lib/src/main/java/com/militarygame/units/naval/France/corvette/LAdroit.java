package com.militarygame.units.naval.France.corvette;

public class LAdroit {

}
