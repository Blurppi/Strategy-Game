package com.militarygame.util;

public class Config {

}
