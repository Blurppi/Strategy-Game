package com.militarygame.units.infantry.France.gendarmerie;

public class BasicGendarmerie {

}
