package com.militarygame.cities;

public class CityBuilding {
    private BuildingType type;
    private int health;
    private int maxHealth;
    private boolean isConstructed;
    private int constructionProgress; // 0-100
    
    public CityBuilding(BuildingType type) {
        this.type = type;
        this.maxHealth = 100;
        this.health = maxHealth;
        this.isConstructed = true;
        this.constructionProgress = 100;
    }
    
    public CityBuilding(BuildingType type, boolean underConstruction) {
        this.type = type;
        this.maxHealth = 100;
        this.health = maxHealth;
        this.isConstructed = !underConstruction;
        this.constructionProgress = underConstruction ? 0 : 100;
    }
    
    /**
     * Upgrade to next building level
     */
    public CityBuilding upgrade() {
        BuildingType nextLevel = type.getNextLevel();
        if (nextLevel != null) {
            System.out.println("✓ Upgrading " + type.getName() + " to " + nextLevel.getName());
            return new CityBuilding(nextLevel);
        }
        System.out.println("✗ " + type.getName() + " is already max level");
        return null;
    }
    
    /**
     * Check if can be upgraded
     */
    public boolean canUpgrade() {
        return type.getNextLevel() != null;
    }
    
    /**
     * Get next level
     */
    public BuildingType getNextLevel() {
        return type.getNextLevel();
    }
    
    public void takeDamage(int damage) {
        this.health -= damage;
        if (this.health < 0) {
            this.health = 0;
            this.isConstructed = false;
        }
    }
    
    public void repair(int amount) {
        this.health = Math.min(this.health + amount, maxHealth);
        if (this.health == maxHealth) {
            this.isConstructed = true;
        }
    }
    
    public void updateConstruction(int progressPerTurn) {
        if (!isConstructed) {
            constructionProgress += progressPerTurn;
            if (constructionProgress >= 100) {
                constructionProgress = 100;
                isConstructed = true;
            }
        }
    }
    
    // Getters
    public BuildingType getType() { return type; }
    public int getLevel() { return type.getLevel(); }
    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }
    public boolean isConstructed() { return isConstructed; }
    public int getConstructionProgress() { return constructionProgress; }
    
    public BuildingType.Cost getBuildCost() { return type.getBuildCost(); }
    public BuildingType.Cost getMaintenanceCost() { return type.getMaintenanceCost(); }
    
    public int getMaintenanceCostTotal() {
        BuildingType.Cost cost = getMaintenanceCost();
        return cost.supplies + cost.components + cost.fuel + 
               cost.electronics + cost.rareMaterials + cost.money;
    }
}