package com.militarygame.weapons;

public class Gun {

}
