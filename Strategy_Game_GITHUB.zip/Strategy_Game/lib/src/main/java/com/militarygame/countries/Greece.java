package com.militarygame.countries;

public class Greece {

}
