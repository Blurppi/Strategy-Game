package com.militarygame.map.europe;

public class MapGenerator {

}
