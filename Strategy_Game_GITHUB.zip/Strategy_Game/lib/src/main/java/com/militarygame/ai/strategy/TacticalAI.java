package com.militarygame.ai.strategy;

import com.militarygame.ai.AIstrategy;
import com.militarygame.countries.*;
import com.militarygame.map.europe.EuropeMap;
import com.militarygame.units.Units;
import com.militarygame.ai.decisionMaking.UnitMoveDecision;

public class TacticalAI {
    private Countries country;
    private EuropeMap map;
    private AIstrategy strategy;
    
    public TacticalAI(Countries country, EuropeMap map, AIstrategy strategy) {
        this.country = country;
        this.map = map;
        this.strategy = strategy;
    }
    
    public UnitMoveDecision decideUnitMovement(Units unit) {
        // Find nearest enemy
        Units nearestEnemy = findNearestEnemy(unit);
        
        if (nearestEnemy == null) {
            // Move towards unclaimed cities
            return moveTowardsCities(unit);
        }
        
        // Move based on strategy
        switch (strategy) {
            case AGGRESSIVE:
                return moveTowardsEnemy(unit, nearestEnemy);
            case DEFENSIVE:
                return moveTowardsFriendlyCities(unit);
            case BALANCED:
                return moveTowardsCities(unit);
            default:
                return null;
        }
    }
    
    private Units findNearestEnemy(Units unit) {
        Units nearest = null;
        int minDistance = Integer.MAX_VALUE;
        
        for (Countries enemy : map.getCountries()) {
            if (!enemy.equals(country)) {
                for (Units enemyUnit : enemy.getUnits()) {
                    int distance = calculateDistance(unit, enemyUnit);
                    if (distance < minDistance) {
                        minDistance = distance;
                        nearest = enemyUnit;
                    }
                }
            }
        }
        return nearest;
    }
    
    private int calculateDistance(Units u1, Units u2) {
        int dx = u1.getCurrentTile().getX() - u2.getCurrentTile().getX();
        int dy = u1.getCurrentTile().getY() - u2.getCurrentTile().getY();
        return (int) Math.sqrt(dx * dx + dy * dy);
    }
    
    private UnitMoveDecision moveTowardsEnemy(Units unit, Units enemy) {
        // Use A* pathfinding to move towards enemy
        // TODO: Implement pathfinding
        return null;
    }
    
    private UnitMoveDecision moveTowardsCities(Units unit) {
        // Move towards nearest unclaimed city
        return null;
    }
    
    private UnitMoveDecision moveTowardsFriendlyCities(Units unit) {
        // Move towards friendly cities for defense
        return null;
    }
    
    public void setStrategy(AIstrategy strategy) {
        this.strategy = strategy;
    }
}