package com.militarygame.unit;

public class France {

}
