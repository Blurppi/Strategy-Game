package com.militarygame.rendering;

import com.militarygame.map.europe.*;
import java.awt.*;
import java.util.*;

public class MapRenderer {
    private EuropeMap map;
    private static final int TILE_SIZE = 4; // Small tiles for zoomed-out view
	private static final EuropeTerrainType  = null;
	private static final EuropeTerrainType  = null;
    
    public MapRenderer(EuropeMap map) {
        this.map = map;
    }
    
    public void render(Graphics2D g2d, int screenWidth, int screenHeight, CameraController camera) {
        // Draw terrain
        drawTerrain(g2d, screenWidth, screenHeight, camera);
        
        // Draw regions with borders
        drawRegions(g2d, screenWidth, screenHeight, camera);
        
        // Draw region names
        drawRegionLabels(g2d, screenWidth, screenHeight, camera);
    }
    
    private void drawTerrain(Graphics2D g2d, int screenWidth, int screenHeight, CameraController camera) {
        int startX = (int) (camera.getCameraX() / TILE_SIZE);
        int startY = (int) (camera.getCameraY() / TILE_SIZE);
        int endX = startX + (screenWidth / TILE_SIZE) + 1;
        int endY = startY + (screenHeight / TILE_SIZE) + 1;
        
        for (int y = Math.max(0, startY); y < Math.min(map.getHeight(), endY); y++) {
            for (int x = Math.max(0, startX); x < Math.min(map.getWidth(), endX); x++) {
                Tile tile = map.getTile(x, y);
                if (tile != null) {
                    drawTile(g2d, tile, camera);
                }
            }
        }
    }
    
    private void drawTile(Graphics2D g2d, EuropeTile tile, CameraController camera) {
        int screenX = (int) (tile.getX() * TILE_SIZE - camera.getCameraX());
        int screenY = (int) (tile.getY() * TILE_SIZE - camera.getCameraY());
        
        // Color based on terrain
        switch (tile.getTerrain()) {
            case GRASS:
                g2d.setColor(new Color(34, 139, 34));
                break;
            case WATER:
                g2d.setColor(new Color(0, 105, 148));
                break;
            case MOUNTAIN:
                g2d.setColor(new Color(139, 90, 43));
                break;
            case DESERT:
                g2d.setColor(new Color(238, 214, 175));
                break;
            case FOREST:
                g2d.setColor(new Color(0, 100, 0));
                break;
		default:
			break;
        }
        
        g2d.fillRect(screenX, screenY, TILE_SIZE, TILE_SIZE);
    }
    
    private void drawRegions(Graphics2D g2d, int screenWidth, int screenHeight, CameraController camera) {
        for (County region : map.getRegions()) {
            if (region.getOwner() == null) continue;
            
            // Draw region border
            int screenX = (int) (region.getX() * TILE_SIZE - camera.getCameraX());
            int screenY = (int) (region.getY() * TILE_SIZE - camera.getCameraY());
            int screenWidth_ = region.getWidth() * TILE_SIZE;
            int screenHeight_ = region.getHeight() * TILE_SIZE;
            
            // Draw border in owner's color
            g2d.setColor(region.getOwner().getColor());
            g2d.setStroke(new BasicStroke(2));
            g2d.drawRect(screenX, screenY, screenWidth_, screenHeight_);
        }
    }
    
    private void drawRegionLabels(Graphics2D g2d, int screenWidth, int screenHeight, CameraController camera) {
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 10));
        
        for (County region : map.getRegions()) {
            int screenX = (int) (region.getX() * TILE_SIZE - camera.getCameraX() + region.getWidth() * TILE_SIZE / 2);
            int screenY = (int) (region.getY() * TILE_SIZE - camera.getCameraY() + region.getHeight() * TILE_SIZE / 2);
            
            // Only draw if visible on screen
            if (screenX > 0 && screenX < screenWidth && screenY > 0 && screenY < screenHeight) {
                FontMetrics fm = g2d.getFontMetrics();
                int textWidth = fm.stringWidth(region.getName());
                g2d.drawString(region.getName(), screenX - textWidth / 2, screenY);
            }
        }
    }
}