package com.militarygame.countries;

public class Italy {

}
