package com.militarygame.researchTree;

import java.util.*;

public class ResearchTreeFrance {
    
    // Tech nodes for France's research tree
    private Map<String, TechNode> allTechs;
    
    public ResearchTreeFrance() {
        allTechs = new HashMap<>();
        initializeFrenchTechTree();
    }
    
    /**
     * Initialize France's complete research tree
     */
    private void initializeFrenchTechTree() {
        // ===== V. RECON + COMBAT =====
        createTechChain(new Object[]{
            "AML 90", 500,
            "Amélioration du moteur et transmission", 600,
            "Amélioration de la protection", 700,
            "Amélioration du canon", 800,
            "ERC 90", 900,
            "Amélioration du moteur", 1000,
            "Amélioration polyvalence", 1100,
            "Combat en réseau", 1200,
            "Jaguar", 1500
        });
        
        createTechChain(new Object[]{
            "AML 90 Alt", 500,
            "Amélioration moteur", 600,
            "Amélioration munitions", 700,
            "Amélioration Blindage", 800,
            "AMX 10 RC", 1000
        });
        
        // ===== V. COMBAT BLINDÉ =====
        createTechChain(new Object[]{
            "AMX 10 P", 600,
            "Amélioration mobilité", 700,
            "Survivabilité accrue", 800,
            "Amélioration moteur", 900,
            "Combat en réseau", 1000,
            "VBCI", 1200
        });
        
        createTechChain(new Object[]{
            "VAB", 500,
            "Blindage renforcé", 600,
            "Protection contre les mines et IED", 700,
            "Meilleure mobilité", 800,
            "Sécurité accrue", 900,
            "VBMR Griffon", 1100
        });
        
        // ===== V. AMPHIBIE =====
        createTechChain(new Object[]{
            "AMX 10 P Amphibie", 700,
            "Amélioration propulsion", 800,
            "Amélioration flottaison", 900,
            "Amélioration survivabilité", 1000,
            "Amélioration blindage", 1100
        });
        
        // ===== TANK (CHARS) =====
        createTechChain(new Object[]{
            "AMX 30", 800,
            "Amélioration optiques", 900,
            "Survivabilité améliorée", 1000,
            "Moteur amélioré", 1100,
            "AMX 30 B2 Brenus", 1300,
            "Amélioration blindage", 1400,
            "Modernisation moteur", 1500,
            "MSC", 1600,
            "Amélioration moteur", 1700,
            "Amélioration Optiques", 1800,
            "Blindage composite et ERA", 2000,
            "Leclerc", 2500,
            "Amélioration blindage", 2600,
            "Amélioration mitrailleuses", 2700,
            "Combat en réseaux", 2800,
            "APS", 2900,
            "Leclerc XLR", 3200
        });
        
        // ===== CHASSEUR DE CHARS (Tank Destroyers) =====
        createTechChain(new Object[]{
            "AMX 13", 700,
            "Amélioration moteur", 800,
            "Ajout missiles", 900,
            "Mephisto", 1200,
            "Amélioration protection", 1300,
            "Amélioration survivabilité", 1400,
            "Combat en réseaux", 1500,
            "Jaguar TD", 1700
        });
        
        // ===== ARTILLERIE (Artillery) =====
        createTechChain(new Object[]{
            "TRF1", 700,
            "Amélioration moteur", 800,
            "Amélioration Blindage", 900,
            "Amélioration portée", 1000,
            "AUF1", 1300,
            "Amélioration moteur", 1400,
            "Amélioration portée", 1500,
            "Combat en réseaux", 1600,
            "CAESAR", 1900,
            "Brouillage anti-drones", 2000
        });
        
        createTechChain(new Object[]{
            "TRF1 Rocket", 800,
            "Amélioration moteur", 900,
            "Amélioration des munitions", 1000,
            "M270", 1300,
            "Survivabilité améliorée", 1400,
            "Automatisation tir et chargement", 1500,
            "Amélioration munitions", 1600,
            "Combat en réseaux", 1700,
            "M270 LRU", 2000
        });
        
        // ===== VEHICULES ANTI-AÉRIENS (AA Vehicles) =====
        createTechChain(new Object[]{
            "AMX 13 DCA", 700,
            "Amélioration radar", 800,
            "Amélioration blindage", 900,
            "Survivabilité accrue", 1000,
            "AMX 30 DCA", 1200,
            "Amélioration munitions", 1300,
            "Amélioration mobilité", 1400,
            "Amélioration guidage et acquisition", 1500,
            "Crotale", 1800
        });
        
        createTechChain(new Object[]{
            "AMX 30 DCA Alt", 900,
            "Amélioration munitions", 1000,
            "Amélioration mobilité", 1100,
            "Amélioration guidage et acquisition", 1200,
            "Roland 1", 1500,
            "Amélioration missiles", 1600,
            "Amélioration radar", 1700,
            "Amélioration brouillage", 1800,
            "SAMP/T", 2200,
            "Amélioration radar", 2300,
            "Amélioration missiles", 2400,
            "Amélioration acquisition des cibles", 2500,
            "Amélioration détection des cibles", 2600,
            "SAMP/T NG", 3000,
            "Radar Ground fire", 3200
        });
        
        // ===== HÉLICOPTÈRES (Helicopters) =====
        createTechChain(new Object[]{
            "Gazelle HAP", 1000,
            "Amélioration armement", 1100,
            "Ajout missiles antichars", 1200,
            "Amélioration capteurs", 1300,
            "Amélioration survivabilité", 1400,
            "Tigre HAP", 2000
        });
        
        createTechChain(new Object[]{
            "Gazelle HAD", 1000,
            "Amélioration puissance moteur", 1100,
            "Amélioration armement air-sol", 1200,
            "Amélioration polyvalence", 1300,
            "Tigre HAD", 2000
        });
        
        createTechChain(new Object[]{
            "AB 212 ASW", 1200,
            "Amélioration capteurs sonar", 1300,
            "Amélioration radar maritime", 1400,
            "Amélioration autonomie", 1500,
            "Panther", 1800,
            "Amélioration avionique", 1900,
            "Amélioration capteurs multi-missions", 2000,
            "Amélioration armement antisurface et ASM", 2100,
            "AW159 Wildcats", 2500
        });
        
        // ===== CHASSEURS (Fighters) =====
        createTechChain(new Object[]{
            "Etendard", 1200,
            "Amélioration avionique", 1300,
            "Amélioration capacité d'emport", 1400,
            "Amélioration précision armement", 1500,
            "Super Etendard", 1800,
            "Amélioration capteurs", 1900,
            "Amélioration polyvalence (air-sol / air-air)", 2000,
            "Combat en réseau", 2100,
            "Rafale M", 2500
        });
        
        createTechChain(new Object[]{
            "Mirage F1", 1200,
            "Amélioration radar", 1300,
            "Amélioration missiles air-air", 1400,
            "Amélioration polyvalence", 1500,
            "Mirage 2000", 1800,
            "Amélioration avionique", 1900,
            "Amélioration furtivité relative", 2000,
            "Combat en réseau", 2100,
            "Rafale", 2500
        });
        
        // ===== DRONES =====
        createTechChain(new Object[]{
            "CT 20", 800,
            "Amélioration autonomie", 900,
            "Amélioration guidage", 1000,
            "Sperwer", 1300,
            "Amélioration capteurs ISR", 1400,
            "Amélioration endurance", 1500,
            "Combat en réseau", 1600,
            "Patroller", 2000,
            "Amélioration furtivité", 2100,
            "nEUROn", 2800
        });
        
        // ===== AVION DE PATROUILLE MARITIME (Maritime Patrol) =====
        createTechChain(new Object[]{
            "ATL", 1500,
            "Amélioration capteurs", 1600,
            "Amélioration détection sous-marine", 1700,
            "Amélioration traitement des données", 1800,
            "ATL 2", 2200
        });
        
        // ===== AWACS =====
        createTechChain(new Object[]{
            "C-135F", 1800,
            "Ajout radar de surveillance", 1900,
            "Amélioration détection aérienne", 2000,
            "E-3 Sentry", 2400,
            "Amélioration radar AESA", 2500,
            "Amélioration détection multi-cibles", 2600,
            "Amélioration guerre électronique", 2700,
            "GlobalEye", 3200
        });
        
        // ===== NAVAL - PATROUILLEURS/CORVETTES =====
        createTechChain(new Object[]{
            "P-400", 1200,
            "Amélioration autonomie", 1300,
            "Amélioration capteurs", 1400,
            "Dumont D'Urville", 1700,
            "Amélioration furtivité", 1800,
            "Amélioration systèmes de surveillance", 1900,
            "L'Adroit", 2200
        });
        
        createTechChain(new Object[]{
            "Dumont D'Urville Alt", 1700,
            "Amélioration armement", 1800,
            "Amélioration vitesse", 1900,
            "Amélioration détection radar", 2000,
            "La combattante II", 2300
        });
        
        // ===== FRÉGATES (Frigates) =====
        createTechChain(new Object[]{
            "Georges Leygues", 1800,
            "Amélioration lutte ASM", 1900,
            "Amélioration radar", 2000,
            "Aquitaine", 2500
        });
        
        createTechChain(new Object[]{
            "Georges Leygues Alt", 1800,
            "Amélioration furtivité", 1900,
            "Amélioration polyvalence", 2000,
            "La Fayette", 2500
        });
        
        // ===== DESTROYER =====
        createTechChain(new Object[]{
            "T47", 2000,
            "Modernisation armement", 2100,
            "Amélioration radar", 2200,
            "T47 modernisé", 2600
        });
        
        // ===== PORTE-AVIONS (Carriers) =====
        createTechChain(new Object[]{
            "Foch", 3000,
            "Modernisation aviation embarquée", 3100,
            "Amélioration systèmes", 3200,
            "Charles de Gaulle", 4000
        });
        
        createTechChain(new Object[]{
            "Foch Amphibie", 3000,
            "Ajout capacité projection amphibie", 3100,
            "Amélioration transport troupes", 3200,
            "Mistral", 3800
        });
        
        // ===== SOUS-MARINS (Submarines) =====
        createTechChain(new Object[]{
            "Daphné SNA", 2200,
            "Passage propulsion nucléaire", 2400,
            "Amélioration discrétion", 2600,
            "Rubis", 3000,
            "Amélioration furtivité", 3100,
            "Amélioration capteurs", 3200,
            "Suffren", 3800
        });
        
        createTechChain(new Object[]{
            "Daphné SNLE", 2500,
            "Passage propulsion nucléaire", 2700,
            "Amélioration discrétion", 2900,
            "Le Redoutable", 3300,
            "Amélioration missiles", 3400,
            "Amélioration discrétion", 3500,
            "Triomphant", 4200
        });
        
        // ===== MISSILES =====
        createTechChain(new Object[]{
            "M20", 1500,
            "Amélioration portée", 1600,
            "Amélioration précision", 1700,
            "M51", 2200
        });
        
        createTechChain(new Object[]{
            "ASMP", 2000,
            "Amélioration portée", 2100,
            "Amélioration pénétration", 2200,
            "ASMP-A", 2800
        });
        
        createTechChain(new Object[]{
            "AM38", 1400,
            "Amélioration portée", 1500,
            "Amélioration guidage", 1600,
            "AM40", 1900,
            "Amélioration intégration aérienne", 2000,
            "AM39", 2300
        });
        
        createTechChain(new Object[]{
            "Mistral", 1300,
            "Mistral 1", 1400,
            "Résistance leurres thermiques", 1500,
            "Efficacité accrue", 1600,
            "Mistral 2", 1900,
            "Autodirecteur imagerie infrarouge", 2000,
            "Résistance accrue", 2100,
            "Précision améliorée", 2200,
            "Mistral 3", 2600
        });
        
        createTechChain(new Object[]{
            "SCALP", 2000,
            "Optimisation vol basse altitude", 2100,
            "Amélioration guidage", 2200,
            "Résistance au brouillage", 2300,
            "MdCN", 2700
        });
        
        createTechChain(new Object[]{
            "SCALP Alt", 2000,
            "Amélioration furtivité", 2100,
            "Amélioration précision", 2200,
            "SCALP-EG", 2700
        });
        
        // ===== AIR-AIR MISSILES =====
        createTechChain(new Object[]{
            "Matra 530", 1200,
            "Amélioration guidage radar", 1300,
            "Amélioration portée", 1400,
            "Amélioration précision", 1500,
            "Super Matra 530", 1800,
            "Amélioration autodirecteur", 1900,
            "Amélioration résistance brouillage", 2000,
            "Amélioration polyvalence (BVR / WVR)", 2100,
            "MICA", 2500,
            "Amélioration portée", 2600,
            "Amélioration guidage actif", 2700,
            "Amélioration capacité multicibles", 2800,
            "Combat en réseau", 2900,
            "Meteor", 3500
        });
        
        createTechChain(new Object[]{
            "Matra R550 Magic", 1000,
            "Matra R550 Magic 1", 1100,
            "Amélioration guidage infrarouge", 1200,
            "Amélioration maniabilité", 1300,
            "Amélioration portée", 1400,
            "R550 Magic 2", 1700,
            "Amélioration autodirecteur infrarouge", 1800,
            "Amélioration résistance aux contre-mesures", 1900,
            "Amélioration capacité tous aspects", 2000,
            "MICA IR", 2400
        });
        // ===== ARMES AIR-SOL =====
        createTechChain(new Object[] {
        		"SAMP 250kg", 800,
        		"Augmentation masse explosive", 900,
        		"Standardisation OTAN", 1000,
        		"MK82 500kg", 1000,
        		"Ajout guidage laser", 1100,
        		"Amélioration précision",1200,
        		"GBU-12 250kg",1300,
        		"Augmentation masse explosive",1400,
        		"Amélioration contre les blindages",1500,
        		"GBU-16 500kg", 1600,
        		"Augmentation masse explosive",1700,
        		"Amélioration pénétration",1800,
        		"GBU-10 1000kg",1900,
        		"Ajout guidage modulaire",2000,
        		"Amélioration précision",2100,
        		"AASM 250kg",2200,
        		"amélioration portée",2300,
        		"Guidage multi-mode",2400,
        		"AASM 500kg",2500,
        		"Augmentation pénétration", 2600,
        		"Amélioration contre le blindage",2700,
        		"AASM 1000kg",2800
        		
        });
        // ===== ARMES (Weapons) =====
        createTechChain(new Object[]{
            "FAMAS", 800,
            "Amélioration ergonomie", 900,
            "Amélioration modularité", 1000,
            "Amélioration fiabilité", 1100,
            "Amélioration compatibilité OTAN", 1200,
            "HK416", 1600
        });
        
        // ===== C3/C4ISR SYSTEMS =====
        createTechChain(new Object[]{
            "Communications Analogique", 1000,
            "Numérisation des communications", 1100,
            "Amélioration transmission données", 1200,
            "Intégration capteurs", 1300,
            "Systèmes C3", 1600,
            "Amélioration interconnexion", 1700,
            "Intégration multi-domaines", 1800,
            "Amélioration partage temps réel", 1900,
            "C4ISR", 2300,
            "Amélioration cybersécurité", 2400,
            "Intégration drones et satellites", 2500,
            "Combat collaboratif", 2600,
            "C5ISR", 3200
        });
        
        // ===== TARGETING SYSTEMS =====
        createTechChain(new Object[]{
            "Désignation laser basique", 900,
            "Amélioration précision", 1000,
            "Amélioration portée", 1100,
            "Intégration avionique", 1200,
            "Pod ATLIS", 1600,
            "Amélioration capteurs IR", 1700,
            "Amélioration suivi cible", 1800,
            "Amélioration vision nocturne", 1900,
            "Damoclès", 2300,
            "Amélioration résolution", 2400,
            "Amélioration multi-capteurs", 2500,
            "Combat en réseau", 2600,
            "TALIOS", 3100
        });
        
        // ===== INFANTRY EQUIPMENT =====
        createTechChain(new Object[]{
            "Équipement basique", 600,
            "Ajout gilet pare-balles", 700,
            "Amélioration ergonomie", 800,
            "Protection balistique", 900,
            "Amélioration modularité", 1000,
            "Ajout systèmes électroniques", 1100,
            "Intégration communication", 1200,
            "FELIN", 1700
        });
        
        System.out.println("✓ French tech tree initialized with " + allTechs.size() + " technologies");
    }
    
    /**
     * Helper method to create a tech chain
     */
    private void createTechChain(Object[] techs) {
        TechNode previousNode = null;
        
        for (int i = 0; i < techs.length; i += 2) {
            String techName = (String) techs[i];
            int cost = (Integer) techs[i + 1];
            
            TechNode node = new TechNode(techName, cost, previousNode);
            allTechs.put(techName, node);
            
            previousNode = node;
        }
    }
    
    /**
     * Get a technology by name
     */
    public TechNode getTech(String techName) {
        return allTechs.get(techName);
    }
    
    /**
     * Check if a technology exists
     */
    public boolean hasTech(String techName) {
        return allTechs.containsKey(techName);
    }
    
    /**
     * Get all available technologies
     */
    public Collection<TechNode> getAllTechs() {
        return allTechs.values();
    }
    
    /**
     * Get technologies that can be researched (prerequisites met)
     */
    public List<TechNode> getAvailableTechs() {
        List<TechNode> available = new ArrayList<>();
        for (TechNode tech : allTechs.values()) {
            if (tech.canResearch()) {
                available.add(tech);
            }
        }
        return available;
    }
    
    /**
     * Research a technology
     */
    public boolean researchTech(String techName) {
        TechNode tech = allTechs.get(techName);
        if (tech != null && tech.canResearch()) {
            tech.setResearched(true);
            System.out.println("✓ Researched: " + techName);
            return true;
        }
        System.out.println("✗ Cannot research: " + techName);
        return false;
    }
    
    /**
     * Inner class for technology nodes
     */
    public static class TechNode {
        private String name;
        private int researchCost;
        private TechNode prerequisite;
        private boolean isResearched;
        private List<TechNode> unlocks; // Technologies this unlocks
        
        public TechNode(String name, int cost, TechNode prerequisite) {
            this.name = name;
            this.researchCost = cost;
            this.prerequisite = prerequisite;
            this.isResearched = false;
            this.unlocks = new ArrayList<>();
            
            if (prerequisite != null) {
                prerequisite.unlocks.add(this);
            }
        }
        
        /**
         * Check if this tech can be researched
         */
        public boolean canResearch() {
            return !isResearched && (prerequisite == null || prerequisite.isResearched);
        }
        
        // Getters and setters
        public String getName() { return name; }
        public int getResearchCost() { return researchCost; }
        public TechNode getPrerequisite() { return prerequisite; }
        public boolean isResearched() { return isResearched; }
        public void setResearched(boolean researched) { this.isResearched = researched; }
        public List<TechNode> getUnlocks() { return new ArrayList<>(unlocks); }
    }
}