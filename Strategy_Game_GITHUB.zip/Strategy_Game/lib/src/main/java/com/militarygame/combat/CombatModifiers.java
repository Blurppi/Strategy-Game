package com.militarygame.combat;

public class CombatModifiers {

}
