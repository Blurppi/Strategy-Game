package com.militarygame.ai.strategy;

public class ResearchAI {

}
