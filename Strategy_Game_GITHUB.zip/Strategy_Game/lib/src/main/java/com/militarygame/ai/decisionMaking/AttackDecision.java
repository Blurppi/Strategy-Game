package com.militarygame.ai.decisionMaking;

public class AttackDecision {

}
