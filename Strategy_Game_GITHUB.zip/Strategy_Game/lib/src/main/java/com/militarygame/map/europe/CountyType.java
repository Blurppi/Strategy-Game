package com.militarygame.map.europe;

public enum CountyType {
    CAPITAL(1),      // National capital region
    MAJOR(3),        // Major regions
    MEDIUM(2),       // Medium regions
    MINOR(0);        // Minor regions
    
    private int strategicValue;
    
    CountyType(int value) {
        this.strategicValue = value;
    }
    
    public int getStrategicValue() {
        return strategicValue;
    }
}