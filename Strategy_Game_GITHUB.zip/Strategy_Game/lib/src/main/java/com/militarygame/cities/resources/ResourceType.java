package com.militarygame.cities.resources;

public enum ResourceType {
    // Specialized resources (produced in specific buildings)
    SUPPLIES("Supplies", "Required for unit maintenance and supplies"),
    COMPONENTS("Components", "Electronics and mechanical parts"),
    FUEL("Fuel", "Propellant for vehicles and aircraft"),
    ELECTRONICS("Electronics", "Advanced technology components"),
    RARE_MATERIALS("Rare Materials", "Strategic minerals and materials"),
    
    // Universal resources (produced in all cities)
    MONEY("Money", "Currency for purchases and transactions"),
    MANPOWER("Manpower", "Population available for military service");
    
    private String name;
    private String description;
    
    ResourceType(String name, String description) {
        this.name = name;
        this.description = description;
    }
    
    public String getName() { return name; }
    public String getDescription() { return description; }
    
    public boolean isSpecialized() {
        return this != MONEY && this != MANPOWER;
    }
}