package com.militarygame.units.naval.France.destroyer;

public class ModernizedT47 {

}
