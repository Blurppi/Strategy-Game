package com.militarygame.countries;

public class Monaco {

}
