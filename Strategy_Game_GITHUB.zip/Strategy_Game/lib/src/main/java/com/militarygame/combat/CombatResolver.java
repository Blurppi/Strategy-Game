package com.militarygame.combat;

public class CombatResolver {

}
