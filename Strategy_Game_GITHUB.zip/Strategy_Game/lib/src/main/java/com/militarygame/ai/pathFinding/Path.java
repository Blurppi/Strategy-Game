package com.militarygame.ai.pathFinding;

public class Path {

}
