package com.militarygame.rendering;

import com.militarygame.cities.City;
import com.militarygame.map.europe.EuropeMap;
import java.awt.*;
import java.util.List;

public class CityRenderer {
    private EuropeMap map;
    private static final int CITY_SIZE = 20;
    
    public CityRenderer(EuropeMap map) {
        this.map = map;
    }
    
    public void render(Graphics2D g2d, List<City> cities, CameraController camera) {
        for (City city : cities) {
            renderCity(g2d, city, camera);
        }
    }
    
    private void renderCity(Graphics2D g2d, City city, CameraController camera) {
        int screenX = (int) (city.getX() * 4 - camera.getCameraX());
        int screenY = (int) (city.getY() * 4 - camera.getCameraY());
        
        // Draw city circle
        g2d.setColor(city.getOwner() != null ? city.getOwner().getColor() : Color.GRAY);
        g2d.fillOval(screenX - CITY_SIZE / 2, screenY - CITY_SIZE / 2, CITY_SIZE, CITY_SIZE);
        
        // Draw city border
        g2d.setColor(Color.WHITE);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawOval(screenX - CITY_SIZE / 2, screenY - CITY_SIZE / 2, CITY_SIZE, CITY_SIZE);
        
        // Draw city name
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 10));
        g2d.drawString(city.getName(), screenX + 10, screenY - 5);
        
        // Draw health bar
        drawHealthBar(g2d, city, screenX, screenY);
        
        // Draw siege indicator
        if (city.isUnderSiege()) {
            g2d.setColor(Color.RED);
            g2d.setStroke(new BasicStroke(3));
            g2d.drawOval(screenX - CITY_SIZE / 2 - 5, screenY - CITY_SIZE / 2 - 5, CITY_SIZE + 10, CITY_SIZE + 10);
        }
    }
    
    private void drawHealthBar(Graphics2D g2d, City city, int x, int y) {
        int barWidth = 30;
        int barHeight = 3;
        float healthPercent = (float) city.getHealth() / city.getMaxHealth();
        
        // Background (red)
        g2d.setColor(Color.RED);
        g2d.fillRect(x - barWidth / 2, y + CITY_SIZE / 2 + 5, barWidth, barHeight);
        
        // Health (green)
        g2d.setColor(Color.GREEN);
        g2d.fillRect(x - barWidth / 2, y + CITY_SIZE / 2 + 5, (int) (barWidth * healthPercent), barHeight);
    }
}
