package com.militarygame.units.armored.France.IFV;

import com.militarygame.countries.Countries;
import com.militarygame.units.armored.Armored;

public class AMX10P extends Armored {
    
    private int troopCapacity;
    private int carriedTroops;
    private int gunCaliber;
    private boolean isAmphibious;
    
    public AMX10P(String name, Countries owner, int x, int y) {
        super(name, owner, x, y);
        initializeAMX10P();
    }
    
    /**
     * Initialize AMX 10 P specific stats
     */
    private void initializeAMX10P() {
        // AMX 10 P stats (French Infantry Fighting Vehicle)
        this.maxHealth = 70;
        this.health = maxHealth;
        this.attack = 18;
        this.defense = 12;
        this.attackRange = 2;
        this.movementSpeed = 4;
        this.maxMovementPoints = movementSpeed;
        this.movementPoints = maxMovementPoints;
        
        this.maxAmmunition = 350;
        this.ammunition = maxAmmunition;
        this.maxFuel = 240;
        this.fuel = maxFuel;
        this.maxSupplies = 180;
        this.supplies = maxSupplies;
        
        // IFV specific
        this.armorLevel = 2;
        this.troopCapacity = 8;
        this.carriedTroops = 0;
        this.gunCaliber = 20;
        this.hasTracksOrWheels = true; // Tracks
        this.isAmphibious = true;
        this.turretRotationSpeed = 12;
        
        System.out.println("🇫🇷 AMX 10 P '" + getName() + "' initialized");
        System.out.println("  Health: " + maxHealth);
        System.out.println("  Troop Capacity: " + troopCapacity);
        System.out.println("  Gun: " + gunCaliber + "mm");
        System.out.println("  Amphibious: Yes");
    }
    
    /**
     * Load troops
     */
    public boolean loadTroops(int amount) {
        if (carriedTroops + amount > troopCapacity) {
            System.out.println("✗ Not enough capacity. Available: " + (troopCapacity - carriedTroops));
            return false;
        }
        carriedTroops += amount;
        System.out.println("✓ Loaded " + amount + " troops (" + carriedTroops + "/" + troopCapacity + ")");
        return true;
    }
    
    /**
     * Unload troops
     */
    public boolean unloadTroops(int amount) {
        if (amount > carriedTroops) {
            System.out.println("✗ Cannot unload " + amount + " troops (only " + carriedTroops + " available)");
            return false;
        }
        carriedTroops -= amount;
        System.out.println("✓ Unloaded " + amount + " troops (" + carriedTroops + "/" + troopCapacity + ")");
        return true;
    }
    
    /**
     * Cross water (amphibious capability)
     */
    public boolean crossWater(int waterTiles) {
        if (!isAmphibious) {
            System.out.println("✗ " + getName() + " is not amphibious");
            return false;
        }
        
        int fuelCost = waterTiles * 3;
        if (fuel < fuelCost) {
            System.out.println("✗ Not enough fuel to cross water");
            return false;
        }
        
        this.fuel -= fuelCost;
        System.out.println("✓ " + getName() + " crossed water (" + waterTiles + " tiles)");
        return true;
    }
    
    // Getters
    public int getTroopCapacity() { return troopCapacity; }
    public int getCarriedTroops() { return carriedTroops; }
    public int getGunCaliber() { return gunCaliber; }
    public boolean isAmphibious() { return isAmphibious; }
    
    @Override
    public void update() {
        if (!isAlive()) return;
        
        // Extra fuel consumption if carrying troops
        int extraFuelCost = (carriedTroops * 1);
        if (fuel > extraFuelCost) {
            fuel -= extraFuelCost;
        }
        
        super.update();
    }
}
