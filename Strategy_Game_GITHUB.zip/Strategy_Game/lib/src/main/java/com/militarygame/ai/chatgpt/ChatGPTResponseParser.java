package com.militarygame.ai.chatgpt;

import com.militarygame.ai.decisionMaking.DecisionExecutor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatGPTResponseParser {
    
    public void parseAndExecuteDecisions(String response, DecisionExecutor executor) {
        // Parse coordinates: (x,y)
        Pattern coordPattern = Pattern.compile("\\((\\d+),(\\d+)\\)");
        Matcher coordMatcher = coordPattern.matcher(response);
        
        while (coordMatcher.find()) {
            int x = Integer.parseInt(coordMatcher.group(1));
            int y = Integer.parseInt(coordMatcher.group(2));
            System.out.println("Parsed move decision: (" + x + "," + y + ")");
        }
        
        // Parse YES/NO decisions
        if (response.toLowerCase().contains("yes")) {
            System.out.println("Decision: YES - Attack");
        } else if (response.toLowerCase().contains("no")) {
            System.out.println("Decision: NO - Don't attack");
        }
        
        // Parse research decisions
        if (response.toLowerCase().contains("research")) {
            System.out.println("Decision: Start research");
        }
    }
}
