package com.militarygame.countries;

public class Latvia {

}
