package com.militarygame.weapons.missiles.france;

public class Mistral2 {

}
