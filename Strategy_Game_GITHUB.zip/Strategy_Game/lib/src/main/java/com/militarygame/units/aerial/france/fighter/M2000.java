package com.militarygame.units.aerial.france.fighter;

import com.militarygame.countries.*;
import com.militarygame.units.aerial.Aircrafts;
import com.militarygame.units.aerial.weapons.WeaponInventory;
import com.militarygame.units.aerial.weapons.WeaponsTemplate;

public class M2000 extends Aircrafts {
    
    // Mirage 2000 specific stats
    public boolean deltaWingActive;
    private int avionicsLevel;
    private boolean canvonFormation;
    private int radarUpgradeLevel;
    private int engineBoostLevel;
    private int maneuverabilityBonus;
    
    // Weapon system
    private WeaponInventory weaponInventory;
    private String[] equippedWeapons; // Weapons on each hardpoint
    private WeaponsTemplate currentTemplate; // Currently loaded template
    
    public M2000(String name, Countries owner, int x, int y) {
        super(name, owner, x, y);
        initializeMirage2000();
    }
    
    /**
     * Initialize Mirage 2000 specific stats
     */
    private void initializeMirage2000() {
        // Mirage 2000 is a Delta-canard configuration fighter
        this.health = 85;
        this.maxHealth = 85;
        this.attack = 35;
        this.defense = 18;
        this.maxAmmunition = 500;
        this.ammunition = 500;
        this.maxFuel = 4700;
        this.fuel = 4700;
        this.maxSupplies = 150;
        this.supplies = 150;
        
        // Aircraft specific
        this.maxAltitude = 17000;
        this.maxSpeed = 2338;
        
        // Mirage 2000 specific
        this.deltaWingActive = true;
        this.avionicsLevel = 3;
        this.radarUpgradeLevel = 2;
        this.engineBoostLevel = 1;
        this.maneuverabilityBonus = 10;
        
        // Initialize weapon inventory
        this.weaponInventory = new WeaponInventory();
        this.equippedWeapons = new String[6];
        
        // Load default loadout (Magic + Matra)
        loadDefaultLoadoutAA();
        
        System.out.println("✈ Mirage 2000 " + getName() + " initialized");
        System.out.println("  Max Speed: Mach 2.2");
        System.out.println("  Avionics: Level " + avionicsLevel);
        System.out.println("  Default Loadout: Magic + Matra missiles");
    }
    
    /**
     * Load default weapon loadout
     */
    private void loadDefaultLoadoutAA() {
        equippedWeapons[0] = "Magic 1";				// AA missile
        equippedWeapons[1] = "Matra 530";			// AA missile
        equippedWeapons[2] = "";					// Bomb
        equippedWeapons[3] = "";					// Bomb
        equippedWeapons[4] = "Fuel Tank";			// Fuel Tank
        equippedWeapons[5] = "";					// Bomb
        equippedWeapons[6] = "";					// Bomb
        equippedWeapons[7] = "";					// Targeting pod
        equippedWeapons[8] = "Matra 530";			// AA missile
        equippedWeapons[9] = "Magic 1";				// AA missile
        equippedWeapons[10] = "30 mm Cannon";		// Cannon
    }
    
    /**
     * Equip weapon on hardpoint
     */
    public boolean equipWeapon(int hardpointIndex, String weaponName) {
        if (hardpointIndex < 0 || hardpointIndex >= 10) {
            System.out.println("✗ Invalid hardpoint: " + hardpointIndex);
            return false;
        }
        
        // Check if weapon is researched
        if (!weaponInventory.isWeaponResearched(weaponName)) {
            System.out.println("✗ Weapon not researched: " + weaponName);
            return false;
        }
        
        equippedWeapons[hardpointIndex] = weaponName;
        System.out.println("✓ " + weaponName + " equipped to hardpoint " + hardpointIndex);
        return true;
    }
    
    /**
     * Get equipped weapon on hardpoint
     */
    public String getEquippedWeapon(int hardpointIndex) {
        if (hardpointIndex >= 0 && hardpointIndex < 10) {
            return equippedWeapons[hardpointIndex];
        }
        return null;
    }
    
    /**
     * Research a weapon (unlocks it for use)
     */
    public boolean researchWeapon(String weaponName) {
        if (weaponInventory.researchWeapon(weaponName)) {
            System.out.println("✓ " + getName() + " researched " + weaponName);
            return true;
        }
        return false;
    }
    
    /**
     * Create a weapon loadout template
     */
    public WeaponsTemplate createLoadoutTemplate(String templateName, String description) {
        WeaponsTemplate template = weaponInventory.createTemplate(templateName, "Mirage2000");
        template.setDescription(description);
        
        // Copy current loadout to template
        for (int i = 0; i < 10; i++) {
            if (equippedWeapons[i] != null) {
                template.setWeaponOnHardpoint(i, equippedWeapons[i]);
            }
        }
        
        System.out.println("✓ Created loadout template: " + templateName);
        return template;
    }
    
    /**
     * Load a weapon template
     */
    public boolean loadTemplate(String templateName) {
        WeaponsTemplate template = weaponInventory.getTemplate(templateName);
        if (template == null) {
            System.out.println("✗ Template not found: " + templateName);
            return false;
        }
        
        // Load weapons from template
        for (int i = 0; i < 10; i++) {
            String weapon = template.getWeaponOnHardpoint(i);
            if (weapon != null) {
                equipWeapon(i, weapon);
            }
        }
        
        this.currentTemplate = template;
        System.out.println("✓ Loaded template: " + templateName);
        return true;
    }
    
    /**
     * Get all available weapons
     */
    public java.util.List<String> getAvailableWeapons() {
        return weaponInventory.getAvailableWeapons();
    }
    
    /**
     * Get weapon inventory
     */
    public WeaponInventory getWeaponInventory() {
        return weaponInventory;
    }
    
    /**
     * Get current loadout info
     */
    public String getCurrentLoadout() {
        StringBuilder sb = new StringBuilder();
        sb.append("Current Loadout for ").append(getName()).append(":\n");
        
        for (int i = 0; i < 10; i++) {
            String weapon = equippedWeapons[i];
            sb.append("  Hardpoint ").append(i).append(": ").append(weapon != null ? weapon : "Empty").append("\n");
        }
        
        if (currentTemplate != null) {
            sb.append("Template: ").append(currentTemplate.getName());
        }
        
        return sb.toString();
    }
    
    /**
     * Upgrade avionics
     */
    public boolean upgradeAvionics() {
        if (avionicsLevel >= 5) {
            System.out.println("✗ Avionics already at maximum level");
            return false;
        }
        
        avionicsLevel++;
        System.out.println("✓ Avionics upgraded to Level " + avionicsLevel);
        return true;
    }
    
    /**
     * Upgrade radar
     */
    public boolean upgradeRadar() {
        if (radarUpgradeLevel >= 5) {
            System.out.println("✗ Radar already at maximum level");
            return false;
        }
        
        radarUpgradeLevel++;
        System.out.println("✓ Radar upgraded to Level " + radarUpgradeLevel);
        return true;
    }
    
    /**
     * Upgrade engine
     */
    public boolean upgradeEngine() {
        if (engineBoostLevel >= 5) {
            System.out.println("✗ Engine already at maximum level");
            return false;
        }
        
        engineBoostLevel++;
        System.out.println("✓ Engine upgraded to Level " + engineBoostLevel);
        return true;
    }
    
    /**
     * Perform Canvon maneuver
     */
    public void performCanvonManeuver() {
        if (!canvonFormation) {
            System.out.println("✗ Canvon maneuver not available");
            return;
        }
        
        if (fuel < 50) {
            System.out.println("✗ Not enough fuel for Canvon maneuver");
            return;
        }
        
        this.fuel -= 50;
        System.out.println("🔄 " + getName() + " performed Canvon maneuver");
    }
    
    /**
     * Get detailed info
     */
    public String getDetailedInfo() {
        return String.format(
            "Mirage 2000 '%s'\n" +
            "  Status: %s\n" +
            "  Health: %d/%d\n" +
            "  Position: (%d, %d)\n" +
            "  Altitude: %d m\n" +
            "  Fuel: %d / %d\n" +
            "  Ammunition: %d\n" +
            "  Avionics: Level %d\n" +
            "  Radar: Level %d\n" +
            "  Engine: Level %d",
            getName(),
            getStatus(),
            health, maxHealth,
            getX(), getY(),
            getAltitude(),
            fuel, maxFuel,
            ammunition,
            avionicsLevel,
            radarUpgradeLevel,
            engineBoostLevel
        );
    }
    
    // Getters
    public int getAvionicsLevel() { return avionicsLevel; }
    public int getRadarUpgradeLevel() { return radarUpgradeLevel; }
    public int getEngineBoostLevel() { return engineBoostLevel; }
    public WeaponsTemplate getCurrentTemplate() { return currentTemplate; }
    public int getManeuverabilityBonus() { return maneuverabilityBonus; }
}