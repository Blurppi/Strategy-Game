package com.militarygame.countries;

public class Iceland {

}
