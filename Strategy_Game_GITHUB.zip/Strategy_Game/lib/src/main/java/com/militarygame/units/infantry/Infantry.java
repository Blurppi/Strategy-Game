package com.militarygame.units.infantry;

public class Infantry {
	protected int maxHealth;				//Vie max de l'unité
	protected int health;					//Vie actuelle de l'unité
	protected int attack;					//Degats infliges d'une attaque de cette unite
	protected int defense;					//Degats infliges lors de la defense
	protected int attackRange;				//Distance possible d'une attaque
	protected int movementSpeed;			//Vitesse de deplacement
	protected int maxMovementPoints;
	protected int movementPoints;
	protected int morale;					//Pourcentage qui augmente/baisse l'attaque, la defense etc.
	protected int maxMorale;
	protected int stamina;					// ""		""		""		""		""		""		""		.
	protected int maxStamina;
}
