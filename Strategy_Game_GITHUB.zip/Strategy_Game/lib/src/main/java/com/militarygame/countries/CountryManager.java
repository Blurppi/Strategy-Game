package com.militarygame.countries;

public class CountryManager {

}
