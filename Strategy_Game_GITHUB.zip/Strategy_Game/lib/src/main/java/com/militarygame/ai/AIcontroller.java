package com.militarygame.ai;

import com.militarygame.countries.*;
import com.militarygame.map.europe.EuropeMap;
import com.militarygame.ai.strategy.*;
import com.militarygame.ai.decisionMaking.*;

public abstract class AIcontroller {
    protected Countries country;
    protected EuropeMap map;
    protected AIstrategy strategy;
    protected AIdifficulty difficulty;
    
    protected TacticalAI tacticalAI;
    protected StrategicAI strategicAI;
    protected ResearchAI researchAI;
    protected CombatAI combatAI;
    
    protected DecisionExecutor decisionExecutor;
    
    public AIcontroller(Countries country, EuropeMap map, AIstrategy strategy, AIdifficulty difficulty) {
        this.country = country;
        this.map = map;
        this.strategy = strategy;
        this.difficulty = difficulty;
        
        initializeAISubsystems();
    }
    
    protected void initializeAISubsystems() {
        this.tacticalAI = new TacticalAI(country, map, strategy);
        this.strategicAI = new StrategicAI(country, map, strategy);
        this.researchAI = new ResearchAI(country, map, strategy, difficulty);
        this.combatAI = new CombatAI(country, map, strategy, difficulty);
        
        this.decisionExecutor = new DecisionExecutor(country, map);
    }
    
    /**
     * Main AI turn logic
     */
    public void takeTurn() {
        System.out.println("[" + country.getName() + " AI] Taking turn...");
        
        // 1. Research decisions
        ResearchDecision researchDecision = researchAI.decideWhatToResearch();
        if (researchDecision != null) {
            decisionExecutor.executeResearchDecision(researchDecision);
        }
        
        // 2. Unit movement
        for (Unit unit : country.getUnits()) {
            UnitMoveDecision moveDecision = tacticalAI.decideUnitMovement(unit);
            if (moveDecision != null) {
                decisionExecutor.executeMovement(moveDecision);
            }
        }
        
        // 3. Combat decisions
        for (Unit unit : country.getUnits()) {
            AttackDecision attackDecision = combatAI.decideAttack(unit);
            if (attackDecision != null) {
                decisionExecutor.executeAttack(attackDecision);
            }
        }
        
        // 4. Strategic analysis
        String strategy = strategicAI.analyzeGameState();
        System.out.println("[" + country.getName() + " Strategy]: " + strategy);
    }
    
    public void setStrategy(AIStrategy strategy) {
        this.strategy = strategy;
        tacticalAI.setStrategy(strategy);
        strategicAI.setStrategy(strategy);
        researchAI.setStrategy(strategy);
        combatAI.setStrategy(strategy);
    }
    
    public abstract void shutdown();
}