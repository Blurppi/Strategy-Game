package com.militarygame.units.aerial.france.fighter;

import com.militarygame.countries.Countries;
import com.militarygame.units.aerial.Aircrafts;
import com.militarygame.units.aerial.weapons.WeaponInventory;

public class MirageF1 extends Aircrafts {
    
    // Mirage F1 specs
    private int avionicsLevel;
    private int radarUpgradeLevel;
    private int engineBoostLevel;
    private int maneuverabilityBonus; // +5 (good maneuverability, but less than newer models)
    
    // Weapon system
    private WeaponInventory weaponInventory;
    private String[] equippedWeapons;
    
    public MirageF1(String name, Countries owner, int x, int y) {
        super(name, owner, x, y);
        initializeMirageF1();
    }
    
    /**
     * Initialize Mirage F1
     */
    private void initializeMirageF1() {
        this.maxHealth = 80;
        this.health = maxHealth;
        this.attack = 32;
        this.defense = 16;
        this.maxAmmunition = 400;
        this.ammunition = maxAmmunition;
        this.maxFuel = 4500; // Internal fuel
        this.fuel = maxFuel;
        this.maxSupplies = 140;
        this.supplies = maxSupplies;
        
        // Aircraft specific
        this.maxAltitude = 16500;
        this.maxSpeed = 2124; // Mach 2.0
        
        // Mirage F1 specificities (older model)
        this.avionicsLevel = 1;
        this.radarUpgradeLevel = 1;
        this.engineBoostLevel = 1;
        this.maneuverabilityBonus = 5; // Lower maneuverability (older design)
        
        // Initialize weapon inventory
        this.weaponInventory = new WeaponInventory();
        this.equippedWeapons = new String[8];
        
        // Load default loadout
        loadDefaultLoadoutAA();
        
        // Add external fuel tanks (1200L each - FEWER than newer models)
        addFuelTank("External Tank 1", 1200);
        addFuelTank("External Tank 2", 1200);
        
        System.out.println("✈ Mirage F1 '" + getName() + "' initialized");
        System.out.println("  Max Speed: Mach 2.0");
        System.out.println("  Avionics Level: " + avionicsLevel);
        System.out.println("  Default Loadout: Magic + Matra");
        System.out.println("  Total Fuel: " + getFuel() + "L (Internal: 4500L + External: 2400L)");
        System.out.println("  Maneuverability Bonus: +" + maneuverabilityBonus);
    }
    
    /**
     * Load default Air-to-Air loadout
     */
    private void loadDefaultLoadoutAA() {
        equippedWeapons[0] = "Magic 1";
        equippedWeapons[1] = "Heavy Flares";
        equippedWeapons[2] = "Matra 530";
        equippedWeapons[3] = "Fuel Tank";
        equippedWeapons[4] = "Matra 530";
        equippedWeapons[5] = "Heavy Flares";
        equippedWeapons[6] = "Magic 1";
        equippedWeapons[7] = "30mm Cannon";
    }
    
    /**
     * Perform high-G turn
     */
    public void performHighGTurn() {
        if (fuel < 40) {
            System.out.println("✗ Not enough fuel for high-G turn");
            return;
        }
        
        this.defense += (5 + maneuverabilityBonus / 2); // +7 defense with bonus (less than newer models)
        this.fuel -= 40;
        System.out.println("🔄 " + getName() + " executing high-G turn (Defense +" + (5 + maneuverabilityBonus / 2) + ")");
    }
    
    /**
     * Equip weapon on hardpoint
     */
    public boolean equipWeapon(int hardpointIndex, String weaponName) {
        if (hardpointIndex < 0 || hardpointIndex > 7) {
            System.out.println("✗ Invalid hardpoint: " + hardpointIndex);
            return false;
        }
        
        if (!weaponInventory.isWeaponResearched(weaponName)) {
            System.out.println("✗ Weapon not researched yet: " + weaponName);
            return false;
        }
        
        equippedWeapons[hardpointIndex] = weaponName;
        System.out.println("✓ " + weaponName + " equipped to hardpoint " + hardpointIndex);
        return true;
    }
    
    /**
     * Get equipped weapon on hardpoint
     */
    public String getEquippedWeapon(int hardpointIndex) {
        if (hardpointIndex >= 0 && hardpointIndex < 8) {
            return equippedWeapons[hardpointIndex];
        }
        return null;
    }
    
    /**
     * Research a weapon
     */
    public boolean researchWeapon(String weaponName) {
        if (weaponInventory.researchWeapon(weaponName)) {
            System.out.println("✓ " + getName() + " researched " + weaponName);
            return true;
        }
        return false;
    }
    
    /**
     * Upgrade avionics
     */
    public boolean upgradeAvionics() {
        if (avionicsLevel >= 5) {
            System.out.println("✗ Avionics already at maximum level");
            return false;
        }
        
        avionicsLevel++;
        System.out.println("✓ Avionics upgraded to Level " + avionicsLevel);
        return true;
    }
    
    /**
     * Upgrade radar
     */
    public boolean upgradeRadar() {
        if (radarUpgradeLevel >= 5) {
            System.out.println("✗ Radar already at maximum level");
            return false;
        }
        
        radarUpgradeLevel++;
        System.out.println("✓ Radar upgraded to Level " + radarUpgradeLevel);
        return true;
    }
    
    /**
     * Upgrade engine
     */
    public boolean upgradeEngine() {
        if (engineBoostLevel >= 5) {
            System.out.println("✗ Engine already at maximum level");
            return false;
        }
        
        engineBoostLevel++;
        System.out.println("✓ Engine upgraded to Level " + engineBoostLevel);
        return true;
    }
    
    /**
     * Get current loadout info
     */
    public String getCurrentLoadout() {
        StringBuilder sb = new StringBuilder();
        sb.append("Current Loadout for ").append(getName()).append(":\n");
        
        for (int i = 0; i < 8; i++) {
            String weapon = equippedWeapons[i];
            sb.append("  Hardpoint ").append(i).append(": ").append(weapon != null ? weapon : "Empty").append("\n");
        }
        
        return sb.toString();
    }
    
    /**
     * Get available weapons
     */
    public java.util.List<String> getAvailableWeapons() {
        return weaponInventory.getAvailableWeapons();
    }
    
    /**
     * Get weapon inventory
     */
    public WeaponInventory getWeaponInventory() {
        return weaponInventory;
    }
    
    // Getters
    public int getAvionicsLevel() { return avionicsLevel; }
    public int getRadarUpgradeLevel() { return radarUpgradeLevel; }
    public int getEngineBoostLevel() { return engineBoostLevel; }
    public int getManeuverabilityBonus() { return maneuverabilityBonus; }
}