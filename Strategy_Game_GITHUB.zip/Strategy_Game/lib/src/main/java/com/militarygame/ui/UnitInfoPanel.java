package com.militarygame.ui;

public class UnitInfoPanel {

}
