package com.militarygame.combat;

public class BattleLog {

}
