package com.militarygame.units.infantry.France.basicInfantry;

import com.militarygame.countries.Countries;
import com.militarygame.units.infantry.Infantry;

public class BasicInfantry extends Infantry {
    
    private String weaponName;
    private int magazineCapacity;
    private int currentMagazine;
    
    public BasicInfantry(String name, int x, int y) {
        super();
        initializeBasicInfantry();
    }
    
    /**
     * Initialize Basic Infantry specific stats
     */
    private void initializeBasicInfantry() {
        // Basic Infantry stats
        this.maxHealth = 35;
        this.health = maxHealth;
        this.attack = 12;
        this.defense = 8;
        this.attackRange = 1;
        this.movementSpeed = 3;
        this.maxMovementPoints = movementSpeed;
        this.movementPoints = maxMovementPoints;
        
        // Infantry specific
        this.morale = 100;
        this.maxMorale = 100;
        this.stamina = 100;
        this.maxStamina = 100;
        
        this.weaponName = "FAMAS";
        
        System.out.println("👮 Basic Infantry '" + getName() + "' initialized");
        System.out.println("  Health: " + maxHealth);
        System.out.println("  Weapon: " + weaponName);
        System.out.println("  Magazine: " + currentMagazine + "/" + magazineCapacity);
    }
    
    /**
     * Reload weapon
     */
    public void reload() {
        this.currentMagazine = magazineCapacity;
        System.out.println("🔄 " + getName() + " reloaded (" + magazineCapacity + " rounds)");
    }
    
    public String getWeaponName() { return weaponName; }
}
