package com.militarygame.ui;

public class Menu {

}
