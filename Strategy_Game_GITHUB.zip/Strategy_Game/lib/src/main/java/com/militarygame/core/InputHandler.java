package com.militarygame.core;

public class InputHandler {

}
