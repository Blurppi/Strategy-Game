package com.militarygame.countries;

public class Georgia {

}
