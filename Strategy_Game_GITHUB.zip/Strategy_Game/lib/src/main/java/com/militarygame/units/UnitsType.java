package com.militarygame.units;

public enum UnitsType {
    INFANTRY("Infantry", 1),
    TANK("Tank", 2),
    AIRCRAFT("Aircraft", 3),
    HELICOPTER("Helicopter", 4),
    ARTILLERY("Artillery", 5),
    ANTI_AIR("Anti-Aircraft", 6),
    SHIP("Ship", 7),
    SUBMARINE("Submarine", 8),
    TRANSPORT("Transport", 9),
    SUPPORT("Support", 10);
    
    private String displayName;
    private int tier;
    
    UnitsType(String displayName, int tier) {
        this.displayName = displayName;
        this.tier = tier;
    }
    
    public String getDisplayName() { return displayName; }
    public int getTier() { return tier; }
}
