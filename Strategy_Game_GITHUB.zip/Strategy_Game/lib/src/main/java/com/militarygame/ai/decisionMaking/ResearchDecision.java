package com.militarygame.ai.decisionMaking;

public class ResearchDecision {

}
