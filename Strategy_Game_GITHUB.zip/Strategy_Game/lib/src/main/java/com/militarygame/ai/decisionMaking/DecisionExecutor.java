package com.militarygame.ai.decisionMaking;

import com.militarygame.countries.*;
import com.militarygame.map.europe.EuropeMap;
import com.militarygame.units.Units;

public class DecisionExecutor {
    private Countries country;
    private EuropeMap map;
    
    public DecisionExecutor(Countries country, EuropeMap map) {
        this.country = country;
        this.map = map;
    }
    
    public void executeMovement(UnitMoveDecision decision) {
        Units unit = decision.getUnit();
        unit.move(decision.getDestinationTile());
        System.out.println(unit.getName() + " moved to " + decision.getDestinationTile());
    }
    
    public void executeAttack(AttackDecision decision) {
        Units attacker = decision.getAttacker();
        Units defender = decision.getDefender();
        attacker.attack(defender);
        System.out.println(attacker.getName() + " attacked " + defender.getName());
    }
    
    public void executeResearchDecision(ResearchDecision decision) {
        country.getResearchTree().researchTech(decision.getTechName());
        System.out.println(country.getName() + " is researching " + decision.getTechName());
    }
}