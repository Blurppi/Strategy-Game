package com.militarygame.ai.strategy;

public class StrategicAI {

}
