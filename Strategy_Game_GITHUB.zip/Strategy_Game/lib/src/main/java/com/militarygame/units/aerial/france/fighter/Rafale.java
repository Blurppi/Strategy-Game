package com.militarygame.units.aerial.france.fighter;

import com.militarygame.countries.Countries;
import com.militarygame.units.aerial.Aircrafts;
import com.militarygame.units.aerial.weapons.WeaponInventory;

public class Rafale extends Aircrafts {
    
    // Rafale specs
    private int avionicsLevel;
    private int radarUpgradeLevel;
    private int engineBoostLevel;
    private int maneuverabilityBonus; // +8 (very good maneuverability)
    
    // Weapon system
    private WeaponInventory weaponInventory;
    private String[] equippedWeapons;
    
    public Rafale(String name, Countries owner, int x, int y) {
        super(name, owner, x, y);
        initializeRafale();
    }
    
    /**
     * Initialize Rafale
     */
    private void initializeRafale() {
        this.maxHealth = 95;
        this.health = maxHealth;
        this.attack = 38;
        this.defense = 20;
        this.maxAmmunition = 600;
        this.ammunition = maxAmmunition;
        this.maxFuel = 5000; // Internal fuel
        this.fuel = maxFuel;
        this.maxSupplies = 160;
        this.supplies = maxSupplies;
        
        // Aircraft specific
        this.maxAltitude = 18000;
        this.maxSpeed = 2124;
        
        // Rafale specificities
        this.avionicsLevel = 3;
        this.radarUpgradeLevel = 2;
        this.engineBoostLevel = 1;
        this.maneuverabilityBonus = 8; // Very good maneuverability
        
        // Initialize weapon inventory
        this.weaponInventory = new WeaponInventory();
        this.equippedWeapons = new String[12];
        
        // Load default loadout
        loadDefaultLoadoutAA();
        
        // Add external fuel tanks (2000L each)
        addFuelTank("External Tank 1", 2000);
        addFuelTank("External Tank 2", 2000);
        addFuelTank("External Tank 3", 2000);
        
        System.out.println("✈ Rafale '" + getName() + "' initialized");
        System.out.println("  Max Speed: Mach 2.0");
        System.out.println("  Avionics Level: " + avionicsLevel);
        System.out.println("  Default Loadout: MICA IR/EM + Meteor");
        System.out.println("  Total Fuel: " + getFuel() + "L (Internal: 5000L + External: 6000L)");
        System.out.println("  Maneuverability Bonus: +" + maneuverabilityBonus);
    }
    
    /**
     * Load default Air-to-Air loadout
     */
    private void loadDefaultLoadoutAA() {
        equippedWeapons[0] = "MICA IR";
        equippedWeapons[1] = "MICA EM";
        equippedWeapons[2] = "Meteor";
        equippedWeapons[3] = "Fuel Tank";
        equippedWeapons[4] = "Meteor";
        equippedWeapons[5] = "Fuel Tank";
        equippedWeapons[6] = "Meteor";
        equippedWeapons[7] = "Fuel Tank";
        equippedWeapons[8] = "Meteor";
        equippedWeapons[9] = "MICA EM";
        equippedWeapons[10] = "MICA IR";
        equippedWeapons[11] = "30mm Cannon";
    }
    
    /**
     * Perform omni-role maneuver
     */
    public void performOmniRoleManeuver() {
        if (fuel < 45) {
            System.out.println("✗ Not enough fuel");
            return;
        }
        
        this.defense += (6 + maneuverabilityBonus / 2); // +10 defense with bonus
        this.attack += 3;
        this.fuel -= 45;
        System.out.println("🔄 " + getName() + " performing omni-role maneuver (Attack +3, Defense +" + (6 + maneuverabilityBonus / 2) + ")");
    }
    
    /**
     * Equip weapon on hardpoint
     */
    public boolean equipWeapon(int hardpointIndex, String weaponName) {
        if (hardpointIndex < 0 || hardpointIndex > 11) {
            System.out.println("✗ Invalid hardpoint: " + hardpointIndex);
            return false;
        }
        
        if (!weaponInventory.isWeaponResearched(weaponName)) {
            System.out.println("✗ Weapon not researched yet: " + weaponName);
            return false;
        }
        
        equippedWeapons[hardpointIndex] = weaponName;
        System.out.println("✓ " + weaponName + " equipped to hardpoint " + hardpointIndex);
        return true;
    }
    
    /**
     * Get equipped weapon on hardpoint
     */
    public String getEquippedWeapon(int hardpointIndex) {
        if (hardpointIndex >= 0 && hardpointIndex < 12) {
            return equippedWeapons[hardpointIndex];
        }
        return null;
    }
    
    /**
     * Research a weapon
     */
    public boolean researchWeapon(String weaponName) {
        if (weaponInventory.researchWeapon(weaponName)) {
            System.out.println("✓ " + getName() + " researched " + weaponName);
            return true;
        }
        return false;
    }
    
    /**
     * Upgrade avionics
     */
    public boolean upgradeAvionics() {
        if (avionicsLevel >= 5) {
            System.out.println("✗ Avionics already at maximum level");
            return false;
        }
        
        avionicsLevel++;
        System.out.println("✓ Avionics upgraded to Level " + avionicsLevel);
        return true;
    }
    
    /**
     * Upgrade radar
     */
    public boolean upgradeRadar() {
        if (radarUpgradeLevel >= 5) {
            System.out.println("✗ Radar already at maximum level");
            return false;
        }
        
        radarUpgradeLevel++;
        System.out.println("✓ Radar upgraded to Level " + radarUpgradeLevel);
        return true;
    }
    
    /**
     * Upgrade engine
     */
    public boolean upgradeEngine() {
        if (engineBoostLevel >= 5) {
            System.out.println("✗ Engine already at maximum level");
            return false;
        }
        
        engineBoostLevel++;
        System.out.println("✓ Engine upgraded to Level " + engineBoostLevel);
        return true;
    }
    
    /**
     * Get current loadout info
     */
    public String getCurrentLoadout() {
        StringBuilder sb = new StringBuilder();
        sb.append("Current Loadout for ").append(getName()).append(":\n");
        
        for (int i = 0; i < 12; i++) {
            String weapon = equippedWeapons[i];
            sb.append("  Hardpoint ").append(i).append(": ").append(weapon != null ? weapon : "Empty").append("\n");
        }
        
        return sb.toString();
    }
    
    /**
     * Get available weapons
     */
    public java.util.List<String> getAvailableWeapons() {
        return weaponInventory.getAvailableWeapons();
    }
    
    /**
     * Get weapon inventory
     */
    public WeaponInventory getWeaponInventory() {
        return weaponInventory;
    }
    
    // Getters
    public int getAvionicsLevel() { return avionicsLevel; }
    public int getRadarUpgradeLevel() { return radarUpgradeLevel; }
    public int getEngineBoostLevel() { return engineBoostLevel; }
    public int getManeuverabilityBonus() { return maneuverabilityBonus; }
}