package com.militarygame.units.infantry.France.marines;

public class ModernMarines {

}
