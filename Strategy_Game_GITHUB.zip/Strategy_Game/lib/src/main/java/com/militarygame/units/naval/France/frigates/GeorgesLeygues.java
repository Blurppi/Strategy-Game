package com.militarygame.units.naval.France.frigates;

public class GeorgesLeygues {

}
