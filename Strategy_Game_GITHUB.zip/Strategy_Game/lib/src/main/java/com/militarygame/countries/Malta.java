package com.militarygame.countries;

public class Malta {

}
