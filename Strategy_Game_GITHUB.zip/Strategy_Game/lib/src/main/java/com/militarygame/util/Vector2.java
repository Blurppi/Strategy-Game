package com.militarygame.util;

public class Vector2 {

}
