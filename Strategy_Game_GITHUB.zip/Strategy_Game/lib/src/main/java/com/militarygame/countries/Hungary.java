package com.militarygame.countries;

public class Hungary {

}
