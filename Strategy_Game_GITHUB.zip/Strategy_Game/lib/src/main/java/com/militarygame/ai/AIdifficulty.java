package com.militarygame.ai;

public enum AIdifficulty {
    EASY(0.25f, 100),           // 25% of optimal decisions, slow thinking
    MEDIUM(0.5f, 500),         // 50% of optimal decisions
    HARD(0.75f, 2000),          // 75% optimal decisions, fast thinking
    IMPOSSIBLE(1f, 5000);    // optimal + bonuses
    
    private float decisionAccuracy;  // How close to optimal decisions
    private int tokenBudget;         // API tokens per turn
    
    AIdifficulty(float accuracy, int tokens) {
        this.decisionAccuracy = accuracy;
        this.tokenBudget = tokens;
    }
    
    public float getDecisionAccuracy() { return decisionAccuracy; }
    public int getTokenBudget() { return tokenBudget; }
}