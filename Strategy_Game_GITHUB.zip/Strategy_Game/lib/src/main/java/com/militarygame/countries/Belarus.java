package com.militarygame.countries;

public class Belarus {

}
