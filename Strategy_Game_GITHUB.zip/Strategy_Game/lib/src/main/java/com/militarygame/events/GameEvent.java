package com.militarygame.events;

public class GameEvent {

}
