package com.militarygame.core;

import javax.swing.*;


import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.militarygame.map.europe.EuropeMap;
import com.militarygame.map.europe.EuropeTile;
import com.militarygame.countries.*;
import com.militarygame.countries.CountryType;
import com.militarygame.units.Units;
import com.militarygame.units.UnitFactory;
import com.militarygame.cities.Cities;
import com.militarygame.cities.CityType;
import com.militarygame.ai.*;
import com.militarygame.ai.chatgpt.ChatGPTAI;
import com.militarygame.rendering.MapRenderer;
import com.militarygame.rendering.UnitRenderer;
import com.militarygame.rendering.UiRenderer;
import com.militarygame.rendering.CameraController;
import com.militarygame.util.Config;
import com.militarygame.util.Constants;



private void initializeCountries()

    map.addCountryRegions(france);
    map.addCountryRegions(russia);
    map.addCountryRegions(germany);
    map.addCountryRegions(uk);


public class GamePanel extends JPanel {
    
    // Game components
    private EuropeMap map;
    private List<Countries> countries;
    private List<AIcontroller> aiControllers;
    private GameState gameState;
    private InputHandler inputHandler;
    
    // Rendering components
    private MapRenderer mapRenderer;
    private UnitRenderer unitRenderer;
    private UiRenderer uiRenderer;
    private CameraController cameraController;
    
    // Game state variables
    private boolean gameRunning;
    private int currentTurn;
    private long gameStartTime;
    private int framesPerSecond;
    private int frameCount;
    private long lastFPSTime;
    
    // UI state
    private Units selectedUnit;
    private Cities selectedCity;
    private boolean showTechTree;
    private boolean showUnitInfo;
    private boolean showCountryInfo;
    private String currentMessage;
    private long messageDisplayTime;
    
    // Game flow
    private Countries playerCountry;
    private boolean waitingForPlayerInput;
    private boolean aiPhaseActive;
    
    // Constants
    private static final int TARGET_FPS = 60;
    private static final long MESSAGE_DISPLAY_DURATION = 3000; // 3 seconds
    
    public GamePanel() {
        // Set panel properties
        setPreferredSize(new Dimension(
            Config.getInt("game.window.width", 1200),
            Config.getInt("game.window.height", 800)
        ));
        setBackground(Color.BLACK);
        setFocusable(true);
        setDoubleBuffered(true);
        
        // Initialize game
        initializeGame();
        
        // Setup input handling
        setupInputHandling();
        
        // Initialize timing
        gameStartTime = System.currentTimeMillis();
        lastFPSTime = gameStartTime;
        frameCount = 0;
        framesPerSecond = 0;
        
        // Start game loop
        startGameLoop();
    }
    
    /**
     * Initialize all game components
     */
    private void initializeGame() {
        System.out.println("========== INITIALIZING GAME ==========");
        
        // Create world map
        int mapWidth = Config.getInt("map.width", 200);
        int mapHeight = Config.getInt("map.height", 150);
        map = new EuropeMap(mapWidth, mapHeight);
        System.out.println("✓ World map created: " + mapWidth + "x" + mapHeight);
        
        // Initialize collections
        countries = new ArrayList<>();
        aiControllers = new ArrayList<>();
        
        // Initialize game state
        gameState = new GameState();
        currentTurn = 1;
        gameRunning = true;
        waitingForPlayerInput = true;
        aiPhaseActive = false;
        
        // Create countries and assign cities
        initializeCountries();
        
        // Assign countries to map
        map.setCountries(countries);
        System.out.println("✓ " + countries.size() + " countries initialized");
        
        // Create AI controllers for non-player countries
        initializeAICountries();
        System.out.println("✓ " + aiControllers.size() + " AI controllers created");
        
        // Initialize rendering components
        initializeRenderers();
        System.out.println("✓ Rendering components initialized");
        
        // Add starting units to countries
        addStartingUnits();
        System.out.println("✓ Starting units deployed");
        
        System.out.println("========== GAME INITIALIZED ==========\n");
    }
    
    /**
     * Create all countries and assign cities to them
     */
    private void initializeCountries() {
        // PLAYER COUNTRY
        Countries france = new Countries("France", CountryType.France);
        countries.add(france);
        playerCountry = france;
        
        // Add French cities
        Cities paris = new Cities("Paris", 80, 60, CityType.CAPITAL);
        Cities marseille = new Cities("Marseille", 90, 90, CityType.MAJOR);
        Cities lyon = new Cities("Lyon", 85, 75, CityType.MAJOR);
        Cities toulouse = new Cities("Toulouse", 75, 85, CityType.MINOR);
        Cities bordeaux = new Cities("Bordeaux", 70, 80, CityType.MINOR);
        Cities lille = new Cities("Lille", 85, 50, CityType.MINOR);
        Cities strasbourg = new Cities("Strasbourg", 95, 55, CityType.MINOR);
        Cities brest = new Cities("Brest", 65, 65, CityType.MINOR);
        
        france.addCity(paris);
        france.addCity(marseille);
        france.addCity(lyon);
        france.addCity(toulouse);
        france.addCity(bordeaux);
        france.addCity(lille);
        france.addCity(strasbourg);
        france.addCity(brest);
        
        map.addCity(paris);
        map.addCity(marseille);
        map.addCity(lyon);
        map.addCity(toulouse);
        map.addCity(bordeaux);
        map.addCity(lille);
        map.addCity(strasbourg);
        map.addCity(brest);
        
        // RUSSIA
        Countries russia = new Countries("Russia", CountryType.RUSSIA);
        countries.add(russia);
        
        Cities moscow = new Cities("Moscow", 150, 50, CityType.CAPITAL);
        Cities stPetersburg = new Cities("Saint Petersburg", 140, 30, CityType.MAJOR);
        Cities nizhnyNovgorod = new Cities("Nizhny Novgorod", 155, 60, CityType.MAJOR);
        Cities kazan = new Cities("Kazan", 160, 45, CityType.MINOR);
        Cities volgograd = new Cities("Volgograd", 165, 75, CityType.MINOR);
        Cities rostov = new Cities("Rostov-on-Don", 155, 85, CityType.MINOR);
        Cities voronezh = new Cities("Voronezh", 140, 70, CityType.MINOR);
        Cities kaliningrad = new Cities("Kaliningrad", 120, 35, CityType.MINOR);
        
        russia.addCity(moscow);
        russia.addCity(stPetersburg);
        russia.addCity(nizhnyNovgorod);
        russia.addCity(kazan);
        russia.addCity(volgograd);
        russia.addCity(rostov);
        russia.addCity(voronezh);
        russia.addCity(kaliningrad);
        
        map.addCity(moscow);
        map.addCity(stPetersburg);
        map.addCity(nizhnyNovgorod);
        map.addCity(kazan);
        map.addCity(volgograd);
        map.addCity(rostov);
        map.addCity(voronezh);
        map.addCity(kaliningrad);
        
        // GERMANY
        Countries germany = new Countries("Germany", CountryType.GERMANY);
        countries.add(germany);
        
        Cities berlin = new Cities("Berlin", 110, 45, CityType.CAPITAL);
        Cities hamburg = new Cities("Hamburg", 105, 35, CityType.MAJOR);
        Cities munich = new Cities("Munich", 110, 60, CityType.MAJOR);
        Cities cologne = new Cities("Cologne", 100, 40, CityType.MINOR);
        Cities frankfurt = new Cities("Frankfurt", 105, 50, CityType.MINOR);
        Cities stuttgart = new Cities("Stuttgart", 105, 55, CityType.MINOR);
        Cities dusseldorf = new Cities("Düsseldorf", 100, 38, CityType.MINOR);
        Cities leipzig = new Cities("Leipzig", 115, 48, CityType.MINOR);
        
        germany.addCity(berlin);
        germany.addCity(hamburg);
        germany.addCity(munich);
        germany.addCity(cologne);
        germany.addCity(frankfurt);
        germany.addCity(stuttgart);
        germany.addCity(dusseldorf);
        germany.addCity(leipzig);
        
        map.addCity(berlin);
        map.addCity(hamburg);
        map.addCity(munich);
        map.addCity(cologne);
        map.addCity(frankfurt);
        map.addCity(stuttgart);
        map.addCity(dusseldorf);
        map.addCity(leipzig);
        
        // UNITED KINGDOM
        Countries uk = new Countries("United Kingdom", CountryType.UNITED_KINGDOM);
        countries.add(uk);
        
        Cities london = new Cities("London", 75, 45, CityType.CAPITAL);
        Cities birmingham = new Cities("Birmingham", 75, 42, CityType.MAJOR);
        Cities manchester = new Cities("Manchester", 75, 38, CityType.MAJOR);
        Cities glasgow = new Cities("Glasgow", 70, 30, CityType.MINOR);
        Cities liverpool = new Cities("Liverpool", 72, 38, CityType.MINOR);
        Cities leeds = new Cities("Leeds", 78, 38, CityType.MINOR);
        Cities edinburgh = new Cities("Edinburgh", 75, 28, CityType.MINOR);
        Cities bristol = new Cities("Bristol", 73, 48, CityType.MINOR);
        
        uk.addCity(london);
        uk.addCity(birmingham);
        uk.addCity(manchester);
        uk.addCity(glasgow);
        uk.addCity(liverpool);
        uk.addCity(leeds);
        uk.addCity(edinburgh);
        uk.addCity(bristol);
        
        map.addCity(london);
        map.addCity(birmingham);
        map.addCity(manchester);
        map.addCity(glasgow);
        map.addCity(liverpool);
        map.addCity(leeds);
        map.addCity(edinburgh);
        map.addCity(bristol);
    }
    
    /**
     * Initialize AI controllers for all non-player countries
     */
    private void initializeAICountries() {
        String openaiKey = Config.getApiKey("openai.api.key");
        
        if (openaiKey == null || openaiKey.isEmpty()) {
            System.out.println("⚠ WARNING: OpenAI API key not found. AI will be disabled.");
            System.out.println("  Please set openai.api.key in secrets.properties");
            return;
        }
        
        // Russia AI - Aggressive
        AIController russiaAI = new ChatGPTAI(
            getCountryByName("Russia"),
            map,
            AIstrategy.AGGRESSIVE,
            AIdifficulty.HARD,
            openaiKey
        );
        aiControllers.add(russiaAI);
        System.out.println("✓ Russia AI initialized (AGGRESSIVE, HARD)");
        
        // Germany AI - Balanced
        AIController germanyAI = new ChatGPTAI(
            getCountryByName("Germany"),
            map,
            AIstrategy.BALANCED,
            AIdifficulty.MEDIUM,
            openaiKey
        );
        aiControllers.add(germanyAI);
        System.out.println("✓ Germany AI initialized (BALANCED, MEDIUM)");
        
        // UK AI - Defensive
        AIController ukAI = new ChatGPTAI(
            getCountryByName("United Kingdom"),
            map,
            AIstrategy.DEFENSIVE,
            AIdifficulty.MEDIUM,
            openaiKey
        );
        aiControllers.add(ukAI);
        System.out.println("✓ UK AI initialized (DEFENSIVE, MEDIUM)");
    }
    
    /**
     * Initialize all rendering components
     */
    private void initializeRenderers() {
        mapRenderer = new MapRenderer(map);
        unitRenderer = new UnitRenderer(map);
        uiRenderer = new UIRenderer(map, this);
        cameraController = new CameraController(getWidth(), getHeight(), map);
    }
    
    /**
     * Add starting units to each country
     */
    private void addStartingUnits() {
        for (Countries country : countries) {
            if (country.equals(playerCountry)) {
                // Give player more units to start
                addUnitsToCountry(country, 5);
            } else {
                // AI gets fewer units initially
                addUnitsToCountry(country, 3);
            }
        }
    }
    
    /**
     * Helper method to add units to a country
     */
    private void addUnitsToCountry(Countries country, int unitCount) {
        UnitFactory factory = new UnitFactory();
        List<City> cities = country.getCities();
        
        for (int i = 0; i < unitCount && i < cities.size(); i++) {
            City city = cities.get(i);
            Unit unit = factory.createUnit("Infantry", country);
            
            // Place unit at city location
            Tile tile = map.getTile(city.getX(), city.getY());
            unit.setCurrentTile(tile);
            
            country.addUnit(unit);
        }
    }
    
    /**
     * Setup input handling (keyboard and mouse)
     */
    private void setupInputHandling() {
        inputHandler = new InputHandler(this, map, countries, playerCountry);
        addMouseListener(inputHandler);
        addMouseMotionListener(inputHandler);
        addKeyListener(inputHandler);
        
        // Also add direct keyboard handling
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
        });
    }
    
    /**
     * Handle keyboard input
     */
    private void handleKeyPress(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_ESCAPE:
                // Open pause menu
                System.out.println("Pause menu (not implemented yet)");
                break;
            case KeyEvent.VK_T:
                // Toggle tech tree
                showTechTree = !showTechTree;
                System.out.println("Tech tree toggled: " + showTechTree);
                break;
            case KeyEvent.VK_I:
                // Toggle unit info
                showUnitInfo = !showUnitInfo;
                System.out.println("Unit info toggled: " + showUnitInfo);
                break;
            case KeyEvent.VK_C:
                // Toggle country info
                showCountryInfo = !showCountryInfo;
                System.out.println("Country info toggled: " + showCountryInfo);
                break;
            case KeyEvent.VK_SPACE:
                // End player turn
                if (gameState.isPlayerTurn()) {
                    endPlayerTurn();
                }
                break;
            case KeyEvent.VK_UP:
                // Pan camera up
                cameraController.panUp();
                break;
            case KeyEvent.VK_DOWN:
                // Pan camera down
                cameraController.panDown();
                break;
            case KeyEvent.VK_LEFT:
                // Pan camera left
                cameraController.panLeft();
                break;
            case KeyEvent.VK_RIGHT:
                // Pan camera right
                cameraController.panRight();
                break;
        }
    }
    
    /**
     * Start the main game loop
     */
    private void startGameLoop() {
        Thread gameThread = new Thread(() -> {
            long lastTime = System.nanoTime();
            double amountOfTicks = TARGET_FPS;
            double ns = 1000000000.0 / amountOfTicks;
            double delta = 0;
            
            while (gameRunning) {
                long now = System.nanoTime();
                delta += (now - lastTime) / ns;
                lastTime = now;
                
                while (delta >= 1) {
                    update();
                    delta--;
                }
                
                repaint();
                
                // Calculate FPS
                updateFPS();
                
                // Sleep to prevent CPU overuse
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        gameThread.setName("GameLoop-Thread");
        gameThread.setDaemon(false);
        gameThread.start();
    }
    
    /**
     * Update game state
     */
    private void update() {
        // Update camera
        cameraController.update();
        
        // Update game logic based on turn phase
        if (gameState.isPlayerTurn()) {
            updatePlayerTurn();
        } else if (!aiPhaseActive) {
            startAIPhase();
        }
        
        // Update UI messages
        if (currentMessage != null) {
            long elapsedTime = System.currentTimeMillis() - messageDisplayTime;
            if (elapsedTime > MESSAGE_DISPLAY_DURATION) {
                currentMessage = null;
            }
        }
    }
    
    /**
     * Update during player turn
     */
    private void updatePlayerTurn() {
        // Player input is handled by InputHandler
        // This is where you can add automatic player turn logic if needed
    }
    
    /**
     * Start AI phase
     */
    private void startAIPhase() {
        aiPhaseActive = true;
        System.out.println("\n========== TURN " + currentTurn + " - AI PHASE ==========");
        
        // Execute each AI's turn
        for (AIController ai : aiControllers) {
            try {
                ai.takeTurn();
            } catch (Exception e) {
                System.err.println("❌ Error in AI turn for " + ai.getCountry().getName() + ": " + e.getMessage());
                e.printStackTrace();
                showMessage("AI Error: " + e.getMessage());
            }
        }
        
        System.out.println("========== END AI PHASE ==========\n");
        
        // Move to next turn
        currentTurn++;
        gameState.setPlayerTurn(true);
        aiPhaseActive = false;
        showMessage("Turn " + currentTurn + " - Player's Turn");
    }
    
    /**
     * End player turn
     */
    public void endPlayerTurn() {
        System.out.println("[PLAYER] Turn ended");
        gameState.setPlayerTurn(false);
        showMessage("AI is thinking...");
    }
    
    /**
     * Display a message on screen
     */
    public void showMessage(String message) {
        currentMessage = message;
        messageDisplayTime = System.currentTimeMillis();
        System.out.println("📝 " + message);
    }
    
    /**
     * Update FPS counter
     */
    private void updateFPS() {
        frameCount++;
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFPSTime >= 1000) {
            framesPerSecond = frameCount;
            frameCount = 0;
            lastFPSTime = currentTime;
        }
    }
    
    /**
     * Render the game
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        // Enable quality rendering
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        
        // Draw game layers
        mapRenderer.render(g2d, getWidth(), getHeight(), cameraController);
        unitRenderer.render(g2d, getWidth(), getHeight(), cameraController);
        
        // Draw UI overlays
        uiRenderer.renderUI(g2d, getWidth(), getHeight());
        
        // Draw debug info
        if (Config.getBoolean("debug.enabled", false)) {
            drawDebugInfo(g2d);
        }
        
        // Draw messages
        if (currentMessage != null) {
            drawMessage(g2d);
        }
        
        // Draw turn info
        drawTurnInfo(g2d);
    }
    
    /**
     * Draw turn and phase information
     */
    private void drawTurnInfo(Graphics2D g2d) {
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        
        String turnText = "Turn: " + currentTurn;
        String phaseText = gameState.isPlayerTurn() ? "PLAYER TURN" : "AI TURN";
        
        g2d.drawString(turnText, 10, 30);
        g2d.drawString(phaseText, 10, 55);
        
        // Draw country info
        int y = 85;
        for (Country country : countries) {
            if (country.equals(playerCountry)) {
                g2d.setColor(Color.YELLOW); // Highlight player
            } else {
                g2d.setColor(country.getColor());
            }
            
            String countryInfo = country.getName() + ": " + 
                               country.getUnits().size() + " units, " + 
                               country.getCities().size() + " cities, " +
                               "RP: " + country.getResearchPoints();
            
            g2d.drawString(countryInfo, 10, y);
            y += 25;
        }
    }
    
    /**
     * Draw on-screen message
     */
    private void drawMessage(Graphics2D g2d) {
        g2d.setColor(new Color(0, 0, 0, 200)); // Semi-transparent black
        g2d.fillRect(getWidth() / 2 - 200, getHeight() / 2 - 50, 400, 100);
        
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 18));
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(currentMessage);
        g2d.drawString(currentMessage, getWidth() / 2 - textWidth / 2, getHeight() / 2);
    }
    
    /**
     * Draw debug information
     */
    private void drawDebugInfo(Graphics2D g2d) {
        g2d.setColor(Color.GREEN);
        g2d.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        int y = getHeight() - 100;
        g2d.drawString("FPS: " + framesPerSecond, 10, y);
        g2d.drawString("Camera X: " + cameraController.getCameraX(), 10, y + 15);
        g2d.drawString("Camera Y: " + cameraController.getCameraY(), 10, y + 30);
        g2d.drawString("Selected Unit: " + (selectedUnit != null ? selectedUnit.getName() : "None"), 10, y + 45);
        g2d.drawString("Game Time: " + getGameTimeFormatted(), 10, y + 60);
    }
    
    /**
     * Format game time for display
     */
    private String getGameTimeFormatted() {
        long elapsedSeconds = (System.currentTimeMillis() - gameStartTime) / 1000;
        long hours = elapsedSeconds / 3600;
        long minutes = (elapsedSeconds % 3600) / 60;
        long seconds = elapsedSeconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
    
    /**
     * Helper method to get country by name
     */
    private Countries getCountryByName(String name) {
        for (Countries country : countries) {
            if (country.getName().equals(name)) {
                return country;
            }
        }
        return null;
    }
    
    /**
     * Cleanup resources
     */
    public void cleanup() {
        gameRunning = false;
        System.out.println("Shutting down game...");
        
        for (AIcontroller ai : aiControllers) {
            try {
                ai.shutdown();
            } catch (Exception e) {
                System.err.println("Error shutting down AI: " + e.getMessage());
            }
        }
        
        System.out.println("Game shut down complete.");
    }
    
    // ===== GETTERS =====
    
    public EuropeMap getMap() { return map; }
    public List<Countries> getCountries() { return countries; }
    public Countries getPlayerCountry() { return playerCountry; }
    public GameState getGameState() { return gameState; }
    public int getCurrentTurn() { return currentTurn; }
    public int getFPS() { return framesPerSecond; }
    public Units getSelectedUnit() { return selectedUnit; }
    public void setSelectedUnit(Units unit) { this.selectedUnit = unit; }
    public Cities getSelectedCity() { return selectedCity; }
    public void setSelectedCity(Cities city) { this.selectedCity = city; }
    public CameraController getCameraController() { return cameraController; }
    public boolean isShowTechTree() { return showTechTree; }
    public boolean isShowUnitInfo() { return showUnitInfo; }
    public boolean isShowCountryInfo() { return showCountryInfo; }
}


private void initializeGame() {
    // ... existing code ...
    
    // Initialize city manager
    cityManager = new CityManager();
    
    // Create countries
    initializeCountries();
    
    // Initialize cities for each country
    for (Country country : countries) {
        cityManager.addCitiesForCountry(country);
    }
    
    System.out.println("✓ " + cityManager.getTotalCities() + " cities initialized");
}

private void update() {
    // ... existing code ...
    
    // Update cities
    cityManager.updateAllCities();
}

public CityManager getCityManager() { return cityManager; }