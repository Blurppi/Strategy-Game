package com.militarygame.ai;

public enum AIstrategy {
    AGGRESSIVE(1.5f, 0.3f, 0.2f),      // More attacks, less defense
    DEFENSIVE(0.5f, 1.5f, 0.3f),       // More defense, fewer attacks
    BALANCED(1.0f, 1.0f, 0.5f),        // Equal everything
    RESEARCH_FOCUSED(0.3f, 0.8f, 1.5f), // Prioritize research
    EXPANSIONIST(1.2f, 0.7f, 0.6f);    // Conquer cities
    
    private float attackModifier;
    private float defenseModifier;
    private float researchModifier;
    
    AIstrategy(float attack, float defense, float research) {
        this.attackModifier = attack;
        this.defenseModifier = defense;
        this.researchModifier = research;
    }
    
    public float getAttackModifier() { return attackModifier; }
    public float getDefenseModifier() { return defenseModifier; }
    public float getResearchModifier() { return researchModifier; }
}
