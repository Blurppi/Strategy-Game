package com.militarygame.units;

public enum UnitsStatus {
    READY("Ready"),
    MOVING("Moving"),
    ATTACKING("Attacking"),
    DAMAGED("Damaged"),
    RETREATING("Retreating"),
    DESTROYED("Destroyed");
    
    private String displayName;
    
    UnitsStatus(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() { return displayName; }
}
