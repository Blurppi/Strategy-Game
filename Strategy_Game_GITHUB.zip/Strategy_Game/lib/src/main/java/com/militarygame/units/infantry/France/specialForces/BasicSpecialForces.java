package com.militarygame.units.infantry.France.specialForces;

public class BasicSpecialForces {

}
