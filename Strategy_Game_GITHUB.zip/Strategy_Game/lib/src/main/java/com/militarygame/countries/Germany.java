package com.militarygame.countries;

public class Germany {

}
