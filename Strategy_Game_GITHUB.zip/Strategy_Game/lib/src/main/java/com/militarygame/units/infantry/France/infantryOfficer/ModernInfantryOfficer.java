package com.militarygame.units.infantry.France.infantryOfficer;

public class ModernInfantryOfficer {

}
