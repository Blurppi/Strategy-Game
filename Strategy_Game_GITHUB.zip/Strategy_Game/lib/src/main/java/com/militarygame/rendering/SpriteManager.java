package com.militarygame.rendering;

public class SpriteManager {

}
