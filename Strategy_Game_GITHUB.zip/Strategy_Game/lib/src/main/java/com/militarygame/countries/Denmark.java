package com.militarygame.countries;

public class Denmark {

}
