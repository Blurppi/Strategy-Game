package com.militarygame.cities;

public enum CityType {
    CAPITAL(10, 7, 0, 100),         // slots, health, defense, production
    MAJOR(10, 6, 0, 100),
    MEDIUM(10, 5, 0, 100),
    MINOR(10, 4, 0, 100);
    
    private int buildingSlots;
    private int population;
    private int baseDefense;
    private int baseProduction;
    
    CityType(int slots, int health, int defense, int production) {
        this.buildingSlots = slots;
        this.population = health;
        this.baseDefense = defense;
        this.baseProduction = production;
    }
    
    public int getBuildingSlots() { return buildingSlots; }
    public int getMaxHealth() { return population; }
    public int getBaseDefense() { return baseDefense; }
    public int getBaseProduction() { return baseProduction; }
}
