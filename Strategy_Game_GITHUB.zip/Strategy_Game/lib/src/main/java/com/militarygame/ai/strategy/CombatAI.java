package com.militarygame.ai.strategy;

public class CombatAI {

}
