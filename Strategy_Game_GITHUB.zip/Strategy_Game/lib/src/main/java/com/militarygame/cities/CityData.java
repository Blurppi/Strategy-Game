package com.militarygame.cities;

import com.google.gson.*;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

public class CityData {
    private JsonObject citiesData;
    
    public CityData() {
        loadCityData();
    }
    
    private void loadCityData() {
        try {
            InputStream inputStream = CityData.class.getClassLoader()
                .getResourceAsStream("data/cities.json");
            
            if (inputStream == null) {
                System.err.println("❌ cities.json not found!");
                return;
            }
            
            JsonParser parser = new JsonParser();
            citiesData = parser.parse(new InputStreamReader(inputStream)).getAsJsonObject();
            System.out.println("✓ City data loaded successfully");
            
        } catch (Exception e) {
            System.err.println("❌ Error loading city data: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Get all cities for a country
     */
    public List<City> getCitiesForCountry(String countryName) {
        List<City> cities = new ArrayList<>();
        
        try {
            JsonObject countriesData = citiesData.getAsJsonObject("countries");
            JsonArray countryCities = countriesData.getAsJsonObject(countryName)
                .getAsJsonArray("cities");
            
            for (JsonElement element : countryCities) {
                JsonObject cityJson = element.getAsJsonObject();
                
                City city = new City(
                    cityJson.get("name").getAsString(),
                    cityJson.get("code").getAsString(),
                    cityJson.get("x").getAsInt(),
                    cityJson.get("y").getAsInt(),
                    CityType.valueOf(cityJson.get("type").getAsString())
                );
                
                // Add buildings
                JsonArray buildingsArray = cityJson.getAsJsonArray("buildings");
                for (JsonElement buildingElement : buildingsArray) {
                    String buildingName = buildingElement.getAsString();
                    city.addBuilding(BuildingType.valueOf(buildingName));
                }
                
                cities.add(city);
            }
        } catch (Exception e) {
            System.err.println("Error loading cities for " + countryName + ": " + e.getMessage());
        }
        
        return cities;
    }
}
