package com.militarygame.units.aerial.weapons;

public class Weapons {
    private String name;
    private WeaponsType type;
    private int damage;
    private int range;
    private int ammoPerShot;
    private int cooldown; // turns between shots
    private int currentCooldown;
    private boolean isEquipped;
    
    public Weapons(String name, WeaponsType type, int damage, int range, int ammoPerShot, int cooldown) {
        this.name = name;
        this.type = type;
        this.damage = damage;
        this.range = range;
        this.ammoPerShot = ammoPerShot;
        this.cooldown = cooldown;
        this.currentCooldown = 0;
        this.isEquipped = false;
    }
    
    public void updateCooldown() {
        if (currentCooldown > 0) {
            currentCooldown--;
        }
    }
    
    public boolean canFire() {
        return currentCooldown <= 0;
    }
    
    public void fire() {
        if (canFire()) {
            this.currentCooldown = cooldown;
        }
    }
    
    // Getters and Setters
    public String getName() { return name; }
    public WeaponsType getType() { return type; }
    public int getDamage() { return damage; }
    public int getRange() { return range; }
    public int getAmmoPerShot() { return ammoPerShot; }
    public int getCooldown() { return cooldown; }
    public int getCurrentCooldown() { return currentCooldown; }
    public boolean isEquipped() { return isEquipped; }
    public void setEquipped(boolean equipped) { this.isEquipped = equipped; }
}
