package com.militarygame;

public class GameWindow {

}
