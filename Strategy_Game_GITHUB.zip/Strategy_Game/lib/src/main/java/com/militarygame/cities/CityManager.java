package com.militarygame.cities;

import com.militarygame.countries.*;
import java.util.*;

public class CityManager {
    private List<City> allCities;
    private CityData cityData;
    
    public CityManager() {
        this.allCities = new ArrayList<>();
        this.cityData = new CityData();
    }
    
    /**
     * Initialize cities for a country
     */
    public void addCitiesForCountry(Countries country) {
        List<City> countryCities = cityData.getCitiesForCountry(country.getName());
        
        for (City city : countryCities) {
            city.setOwner(country);
            allCities.add(city);
            country.addCity(city);
        }
        
        System.out.println("✓ Added " + countryCities.size() + " cities to " + country.getName());
    }
    
    /**
     * Update all cities each turn
     */
    public void updateAllCities() {
        for (City city : allCities) {
            city.update();
        }
    }
    
    /**
     * Get city by name
     */
    public City getCityByName(String name) {
        for (City city : allCities) {
            if (city.getName().equalsIgnoreCase(name)) {
                return city;
            }
        }
        return null;
    }
    
    /**
     * Get city by coordinates
     */
    public City getCityAt(int x, int y) {
        for (City city : allCities) {
            if (city.getX() == x && city.getY() == y) {
                return city;
            }
        }
        return null;
    }
    
    /**
     * Conquer a city
     */
    public void conquerCity(City city, Countries newOwner) {
        Countries previousOwner = city.getOwner();
        city.setOwner(newOwner);
        city.endSiege();
        
        // Reduce morale after conquest
        city.getStats().setMorale(40);
        
        System.out.println("⚔ " + newOwner.getName() + " conquered " + city.getName() + 
                         " from " + previousOwner.getName());
    }
    
    public List<City> getAllCities() { return new ArrayList<>(allCities); }
    public int getTotalCities() { return allCities.size(); }
}
