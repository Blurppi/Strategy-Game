package com.militarygame.cities;

import com.militarygame.countries.Countries;
import com.militarygame.map.europe.EuropeMap;
import com.militarygame.cities.resources.ResourcesManager;
import java.util.*;

public class Cities {
    private String name;
    private String code;              // City code (e.g., "75" for Paris)
    private int x, y;                 // Map coordinates
    private Countries owner;
    private EuropeMap region;
    private CityType type;
    
    // City properties
    private int health;
    private int maxHealth;
    private CityStats stats;
    
    // Buildings
    private List<CityBuilding> buildings;
    private int buildingSlots;
    
    // Units garrisoned
    private List<String> garrisonedUnits; // Unit IDs
    
    // Development
    private boolean isUnderSiege;
    private int siegeCounter;
    private Countries siegingCountry;
    
    public Cities(String name, String code, int x, int y, CityType type) {
        this.name = name;
        this.code = code;
        this.x = x;
        this.y = y;
        this.type = type;
        this.maxHealth = type.getMaxHealth();
        this.health = maxHealth;
        this.buildingSlots = type.getBuildingSlots();
        
        this.buildings = new ArrayList<>();
        this.garrisonedUnits = new ArrayList<>();
        this.stats = new CityStats();
        
        this.isUnderSiege = false;
        this.siegeCounter = 0;
    }
    
    /**
     * Add a building to the city
     */
    public boolean addBuilding(BuildingType buildingType) {
        if (buildings.size() < buildingSlots) {
            buildings.add(new CityBuilding(buildingType));
            updateBuildingBonuses();
            ResourcesManager.updateCityProduction(this);
            System.out.println("✓ " + buildingType.getName() + " built in " + name);
            return true;
        }
        System.out.println("✗ No building slots available in " + name);
        return false;
    }
    
    /**
     * Start building construction
     */
    public boolean startConstruction(BuildingType buildingType) {
        if (buildings.size() < buildingSlots) {
            buildings.add(new CityBuilding(buildingType, true));
            System.out.println("⚙ Construction started: " + buildingType.getName() + " in " + name);
            return true;
        }
        return false;
    }
    
    /**
     * Upgrade a building
     */
    public boolean upgradeBuilding(BuildingType buildingType) {
        for (CityBuilding building : buildings) {
            if (building.getType() == buildingType && building.isConstructed()) {
                BuildingType nextLevel = building.getType().getNextLevel();
                if (nextLevel != null) {
                    int indexOf = buildings.indexOf(building);
                    buildings.set(indexOf, new CityBuilding(nextLevel));
                    updateBuildingBonuses();
                    ResourcesManager.updateCityProduction(this);
                    System.out.println("✓ " + buildingType.getName() + " upgraded");
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Update all building bonuses based on what's built
     */
    private void updateBuildingBonuses() {
        stats.updateBuildingBonuses(buildings);
    }
    
    /**
     * Start unit production
     */
    public boolean startUnitProduction(String unitType) {
        if (stats.canProduceUnit(unitType)) {
            stats.consumeResourcesForUnit(unitType);
            int productionTime = ResourcesManager.getProductionTime(this, unitType);
            stats.addToProductionQueue(unitType, productionTime);
            System.out.println("⚙ Started production: " + unitType + " (" + productionTime + " turns)");
            return true;
        }
        System.out.println("✗ Not enough resources for " + unitType);
        return false;
    }
    
    /**
     * Take damage from attack
     */
    public void takeDamage(int damage) {
        this.health -= damage;
        if (this.health < 0) {
            this.health = 0;
        }
        
        // Damage buildings too
        if (!buildings.isEmpty()) {
            int buildingDamage = damage / 3;
            buildings.get(0).takeDamage(buildingDamage);
        }
    }
    
    /**
     * Repair the city
     */
    public void repair(int amount) {
        this.health = Math.min(this.health + amount, maxHealth);
    }
    
    /**
     * Begin siege
     */
    public void beginSiege(Countries attacker) {
        this.isUnderSiege = true;
        this.siegingCountry = attacker;
        this.siegeCounter = 0;
        System.out.println("🏰 " + name + " is under siege by " + attacker.getName());
    }
    
    /**
     * End siege
     */
    public void endSiege() {
        this.isUnderSiege = false;
        this.siegingCountry = null;
        System.out.println("🏰 Siege of " + name + " ended");
    }
    
    /**
     * Update city each turn
     */
    public void update() {
        // Update resources
        stats.updateResources();
        
        // Regenerate health
        health = Math.min(health + 2 + stats.getHealthRegeneration(), maxHealth);
        
        // Update building construction
        for (CityBuilding building : buildings) {
            building.updateConstruction(10);
        }
        
        // Update production queues
        stats.updateProduction();
        
        // Handle siege
        if (isUnderSiege) {
            siegeCounter++;
            stats.setMorale(stats.getMorale() - 5);
            
            if (siegeCounter >= 5) {
                owner = siegingCountry;
                stats.setMorale(40);
                endSiege();
            }
        }
        
        // Morale regenerates
        if (stats.getMorale() < 100) {
            stats.setMorale(stats.getMorale() + 2);
        }
    }
    
    /**
     * Get available building slots
     */
    public int getAvailableSlots() {
        return buildingSlots - buildings.size();
    }
    
    /**
     * Check if building exists
     */
    public boolean hasBuilding(BuildingType type) {
        for (CityBuilding building : buildings) {
            if (building.getType() == type && building.isConstructed()) {
                return true;
            }
        }
        return false;
    }
    
    // ===== GETTERS & SETTERS =====
    
    public String getName() { return name; }
    public String getCode() { return code; }
    public int getX() { return x; }
    public int getY() { return y; }
    public Countries getOwner() { return owner; }
    public void setOwner(Countries owner) { this.owner = owner; }
    public EuropeMap getRegion() { return region; }
    public void setRegion(EuropeMap region) { this.region = region; }
    public CityType getType() { return type; }
    
    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }
    public CityStats getStats() { return stats; }
    
    public List<CityBuilding> getBuildings() { return new ArrayList<>(buildings); }
    public List<String> getGarrisonedUnits() { return new ArrayList<>(garrisonedUnits); }
    
    public boolean isUnderSiege() { return isUnderSiege; }
    public Countries getSiegingCountry() { return siegingCountry; }
    public int getSiegeCounter() { return siegeCounter; }
}