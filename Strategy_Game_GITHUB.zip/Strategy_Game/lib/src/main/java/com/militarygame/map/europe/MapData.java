package com.militarygame.map.europe;

import com.google.gson.*;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

public class MapData {
    private JsonObject regionsData;
    
    public MapData() {
        loadRegionData();
    }
    
    private void loadRegionData() {
        try {
            InputStream inputStream = MapData.class.getClassLoader()
                .getResourceAsStream("data/regions.json");
            
            if (inputStream == null) {
                System.err.println("❌ regions.json not found!");
                return;
            }
            
            JsonParser parser = new JsonParser();
            regionsData = parser.parse(new InputStreamReader(inputStream)).getAsJsonObject();
            System.out.println("✓ Region data loaded successfully");
            
        } catch (Exception e) {
            System.err.println("❌ Error loading region data: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Get all regions for a country
     */
    public List<County> getRegionsForCountry(String countryName) {
        List<County> regions = new ArrayList<>();
        
        try {
            JsonObject countriesData = regionsData.getAsJsonObject("countries");
            JsonArray countryRegions = countriesData.getAsJsonObject(countryName)
                .getAsJsonArray("regions");
            
            for (JsonElement element : countryRegions) {
                JsonObject regionJson = element.getAsJsonObject();
                
                Region region = new Region(
                    regionJson.get("name").getAsString(),
                    regionJson.get("code").getAsString(),
                    regionJson.get("x").getAsInt(),
                    regionJson.get("y").getAsInt(),
                    regionJson.get("width").getAsInt(),
                    regionJson.get("height").getAsInt(),
                    RegionType.valueOf(regionJson.get("type").getAsString())
                );
                
                regions.add(region);
            }
        } catch (Exception e) {
            System.err.println("Error loading regions for " + countryName + ": " + e.getMessage());
        }
        
        return regions;
    }
    
    /**
     * Get color for a country
     */
    public java.awt.Color getCountryColor(String countryName) {
        try {
            JsonObject countriesData = regionsData.getAsJsonObject("countries");
            JsonArray colorArray = countriesData.getAsJsonObject(countryName)
                .getAsJsonArray("color");
            
            return new java.awt.Color(
                colorArray.get(0).getAsInt(),
                colorArray.get(1).getAsInt(),
                colorArray.get(2).getAsInt()
            );
        } catch (Exception e) {
            return java.awt.Color.GRAY;
        }
    }
}
