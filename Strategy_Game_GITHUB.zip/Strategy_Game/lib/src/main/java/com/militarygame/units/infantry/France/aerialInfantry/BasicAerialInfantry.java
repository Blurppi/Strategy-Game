package com.militarygame.units.infantry.France.aerialInfantry;

public class BasicAerialInfantry {

}
