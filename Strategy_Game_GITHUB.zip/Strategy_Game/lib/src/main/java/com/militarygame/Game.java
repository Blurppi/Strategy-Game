package com.militarygame;

public class Game {

}
