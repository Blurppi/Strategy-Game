package com.militarygame.core;

public class GameLoop {

}
