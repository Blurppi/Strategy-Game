package com.militarygame.cities;

import com.militarygame.cities.resources.Resources;
import com.militarygame.cities.resources.ResourceType;
import java.util.*;

public class CityStats {
    // Population
    private int population;
    private int maxPopulation;
    
    // Morale and health
    private int morale;
    
    // Military
    private int defensePower;
    private int detectionRange;
    private int zone;
    
    // Production bonuses from buildings
    private int productionBonus;
    private int embarcationTime;
    private int mobilizationSpeed;
    private int manpowerGeneration;
    private int healthRegeneration;
    private int populationGrowth;
    private int moraleBoost;
    private int troopSpeed;
    
    // Research
    private int researchPointsPerTurn;
    
    // Resources
    private Map<ResourceType, Resources> resources;
    private Map<String, Integer> unitProductionQueue;
    
    public CityStats() {
        this.population = 100000;
        this.maxPopulation = 500000;
        this.morale = 80;
        
        this.defensePower = 20;
        this.detectionRange = 100;
        this.zone = 50;
        
        this.productionBonus = 0;
        this.embarcationTime = 50;
        this.mobilizationSpeed = 0;
        this.manpowerGeneration = 0;
        this.healthRegeneration = 0;
        this.populationGrowth = 100;
        this.moraleBoost = 0;
        this.troopSpeed = 0;
        
        this.researchPointsPerTurn = 10;
        
        this.resources = new HashMap<>();
        initializeResources();
        
        this.unitProductionQueue = new HashMap<>();
    }
    
    private void initializeResources() {
        resources.put(ResourceType.SUPPLIES, new Resources(ResourceType.SUPPLIES, 5000));
        resources.put(ResourceType.COMPONENTS, new Resources(ResourceType.COMPONENTS, 3000));
        resources.put(ResourceType.FUEL, new Resources(ResourceType.FUEL, 4000));
        resources.put(ResourceType.ELECTRONICS, new Resources(ResourceType.ELECTRONICS, 2000));
        resources.put(ResourceType.RARE_MATERIALS, new Resources(ResourceType.RARE_MATERIALS, 1000));
        resources.put(ResourceType.MONEY, new Resources(ResourceType.MONEY, 50000));
        resources.put(ResourceType.MANPOWER, new Resources(ResourceType.MANPOWER, 100000));
    }
    
    /**
     * Update all building bonuses based on buildings in the city
     */
    public void updateBuildingBonuses(List<CityBuilding> buildings) {
        // Reset bonuses
        productionBonus = 0;
        embarcationTime = 50;
        mobilizationSpeed = 0;
        manpowerGeneration = 0;
        healthRegeneration = 0;
        populationGrowth = 100;
        moraleBoost = 0;
        troopSpeed = 0;
        researchPointsPerTurn = 10;
        int defenseBonus = 0;
        
        // Calculate bonuses from each building
        for (CityBuilding building : buildings) {
            if (!building.isConstructed()) continue;
            
            String buildingName = building.getType().getBaseName().toUpperCase();
            int level = building.getLevel();
            
            switch (buildingName) {
                case "MILITARY BASE":
                    productionBonus += level * 5;
                    troopSpeed += level * 2;
                    break;
                    
                case "AIRPORT":
                    productionBonus += level * 5;
                    break;
                    
                case "HARBOR":
                    embarcationTime -= level * 5; // Reduces time
                    if (level >= 2) {
                        productionBonus += level * 5;
                    }
                    break;
                    
                case "WEAPON INDUSTRY":
                    productionBonus += level * 4;
                    break;
                    
                case "HOSPITAL":
                case "FIELD HOSPITAL":
                    healthRegeneration += level * 5;
                    break;
                    
                case "RADAR STATION":
                    defenseBonus += level * 5;
                    detectionRange += level * 50;
                    break;
                    
                case "RECRUITMENT OFFICE":
                    mobilizationSpeed += level * 5;
                    manpowerGeneration += level * 20;
                    break;
                    
                case "SECRET RESEARCH LAB":
                    researchPointsPerTurn += level * 10;
                    break;
                    
                case "BUNKER":
                case "COMBAT OUTPOST":
                case "GUN EMPLACEMENT":
                    defenseBonus += level * 15;
                    break;
                    
                case "CITY FARM":
                case "RURAL FARM":
                    manpowerGeneration += level * 50;
                    populationGrowth += level * 20;
                    break;
                    
                case "COMPONENTS INDUSTRY":
                case "REFINERY":
                case "ELECTRONICS INDUSTRY":
                case "RARE MATERIALS INDUSTRY":
                    productionBonus += level * 4;
                    break;
            }
        }
        
        // Apply final values
        defensePower = 20 + defenseBonus;
        embarcationTime = Math.max(embarcationTime, 10); // Minimum
    }
    
    /**
     * Update resources and population each turn
     */
    public void updateResources() {
        for (Resources resource : resources.values()) {
            resource.updateProduction();
        }
        
        // Population growth
        int growth = (int) ((double) population * populationGrowth / 10000);
        population = Math.min(population + growth + manpowerGeneration, maxPopulation);
        
        // Morale regeneration
        if (morale < 100) {
            morale = Math.min(morale + 2 + moraleBoost, 100);
        }
    }
    
    public void setResourceProduction(ResourceType type, int amount) {
        Resources resource = resources.get(type);
        if (resource != null) {
            resource.setProductionPerTurn(amount);
        }
    }
    
    /**
     * Check if enough resources for unit production
     */
    public boolean canProduceUnit(String unitType) {
        return switch (unitType.toUpperCase()) {
            case "INFANTRY" ->
                hasEnoughResources(100, 50, 0, 0, 0, 0);
            case "TANK" ->
                hasEnoughResources(50, 200, 150, 100, 50, 0);
            case "AIRCRAFT" ->
                hasEnoughResources(0, 100, 200, 250, 0, 0);
            case "SHIP" ->
                hasEnoughResources(50, 300, 100, 150, 100, 0);
            default -> false;
        };
    }
    
    private boolean hasEnoughResources(int supplies, int components, int fuel, 
                                       int electronics, int rareMat, int money) {
        return resources.get(ResourceType.SUPPLIES).getAmount() >= supplies &&
               resources.get(ResourceType.COMPONENTS).getAmount() >= components &&
               resources.get(ResourceType.FUEL).getAmount() >= fuel &&
               resources.get(ResourceType.ELECTRONICS).getAmount() >= electronics &&
               resources.get(ResourceType.RARE_MATERIALS).getAmount() >= rareMat &&
               resources.get(ResourceType.MONEY).getAmount() >= money;
    }
    
    /**
     * Consume resources for unit production
     */
    public void consumeResourcesForUnit(String unitType) {
        switch (unitType.toUpperCase()) {
            case "INFANTRY":
                resources.get(ResourceType.SUPPLIES).consume(100);
                resources.get(ResourceType.MANPOWER).consume(500);
                break;
            case "TANK":
                resources.get(ResourceType.COMPONENTS).consume(200);
                resources.get(ResourceType.FUEL).consume(150);
                resources.get(ResourceType.MANPOWER).consume(300);
                break;
            case "AIRCRAFT":
                resources.get(ResourceType.ELECTRONICS).consume(250);
                resources.get(ResourceType.FUEL).consume(200);
                resources.get(ResourceType.MANPOWER).consume(200);
                break;
            case "SHIP":
                resources.get(ResourceType.COMPONENTS).consume(300);
                resources.get(ResourceType.FUEL).consume(100);
                resources.get(ResourceType.MANPOWER).consume(400);
                break;
        }
    }
    
    public void addToProductionQueue(String unitType, int turnsToComplete) {
        unitProductionQueue.put(unitType, turnsToComplete);
    }
    
    public void updateProduction() {
        List<String> completed = new ArrayList<>();
        for (String unit : unitProductionQueue.keySet()) {
            int turnsLeft = unitProductionQueue.get(unit) - 1;
            if (turnsLeft <= 0) {
                completed.add(unit);
            } else {
                unitProductionQueue.put(unit, turnsLeft);
            }
        }
        completed.forEach(unitProductionQueue::remove);
    }
    
    // ===== GETTERS & SETTERS =====
    
    public int getPopulation() { return population; }
    public void setPopulation(int pop) { this.population = Math.min(pop, maxPopulation); }
    public int getMaxPopulation() { return maxPopulation; }
    
    public int getMorale() { return morale; }
    public void setMorale(int morale) { this.morale = Math.max(0, Math.min(morale, 100)); }
    
    public int getDefensePower() { return defensePower; }
    public int getDetectionRange() { return detectionRange; }
    public int getZone() { return zone; }
    
    public int getProductionBonus() { return productionBonus; }
    public int getResearchPointsPerTurn() { return researchPointsPerTurn; }
    public int getEmbarcationTime() { return embarcationTime; }
    public int getMobilizationSpeed() { return mobilizationSpeed; }
    public int getTroopSpeed() { return troopSpeed; }
    public int getPopulationGrowth() { return populationGrowth; }
    public int getHealthRegeneration() { return healthRegeneration; }
    public int getMoraleBoost() { return moraleBoost; }
    
    public Resources getResource(ResourceType type) { return resources.get(type); }
    public Map<ResourceType, Resources> getAllResources() { return new HashMap<>(resources); }
    public Map<String, Integer> getProductionQueue() { return new HashMap<>(unitProductionQueue); }
}