package com.militarygame.countries;

public class Spain {

}
