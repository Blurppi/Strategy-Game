package com.militarygame.countries;

public class Ireland {

}
