package com.militarygame.countries;

public class Azerbaijan {

}
