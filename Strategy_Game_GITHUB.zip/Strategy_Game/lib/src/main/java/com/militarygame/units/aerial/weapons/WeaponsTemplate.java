package com.militarygame.units.aerial.weapons;

import java.util.*;

public class WeaponsTemplate {
    private String name;
    private String description;
    private String aircraftType; // e.g., "Mirage2000"
    private Map<Integer, String> hardpointLoadout; // hardpoint index -> weapon name
    
    public WeaponsTemplate(String name, String aircraftType) {
        this.name = name;
        this.aircraftType = aircraftType;
        this.description = "";
        this.hardpointLoadout = new HashMap<>();
    }
    
    /**
     * Set weapon on hardpoint
     */
    public void setWeaponOnHardpoint(int hardpointIndex, String weaponName) {
        hardpointLoadout.put(hardpointIndex, weaponName);
    }
    
    /**
     * Get weapon on hardpoint
     */
    public String getWeaponOnHardpoint(int hardpointIndex) {
        return hardpointLoadout.getOrDefault(hardpointIndex, null);
    }
    
    /**
     * Get template as string for display
     */
    public String getTemplateInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("Template: ").append(name).append("\n");
        sb.append("Aircraft: ").append(aircraftType).append("\n");
        if (!description.isEmpty()) {
            sb.append("Description: ").append(description).append("\n");
        }
        sb.append("Loadout:\n");
        
        for (int i = 0; i < 6; i++) {
            String weapon = hardpointLoadout.getOrDefault(i, "Empty");
            sb.append("  Hardpoint ").append(i).append(": ").append(weapon).append("\n");
        }
        
        return sb.toString();
    }
    
    // Getters and Setters
    public String getName() { return name; }
    public String getAircraftType() { return aircraftType; }
    public String getDescription() { return description; }
    public void setDescription(String desc) { this.description = desc; }
    public Map<Integer, String> getHardpointLoadout() { return new HashMap<>(hardpointLoadout); }
}
