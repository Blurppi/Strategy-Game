package com.militarygame.cities.resources;

import com.militarygame.cities.Cities;
import com.militarygame.cities.CityBuilding;

public class ResourcesManager {
    
    /**
     * Update production based on buildings in city
     */
    public static void updateCityProduction(Cities city) {
        CityBuilding[] buildings = city.getBuildings().toArray(new CityBuilding[0]);
        
        // Reset all production
        for (ResourceType type : ResourceType.values()) {
            city.getStats().setResourceProduction(type, 0);
        }
        
        int suppliesProduction = 0;
        int componentsProduction = 0;
        int fuelProduction = 0;
        int electronicsProduction = 0;
        int rareMaterialsProduction = 0;
        int moneyProduction = 100; // Base from city
        int manpowerProduction = city.getStats().getPopulation() / 1000;
        
        // Calculate production from each building
        for (CityBuilding building : buildings) {
            if (!building.isConstructed()) continue;
            
            String baseName = building.getType().getBaseName().toUpperCase();
            int level = building.getLevel();
            
            switch (baseName) {
                case "COMPONENTS INDUSTRY":
                    componentsProduction += level * 40;
                    break;
                case "REFINERY":
                    fuelProduction += level * 45;
                    break;
                case "ELECTRONICS INDUSTRY":
                    electronicsProduction += level * 35;
                    break;
                case "RARE MATERIALS INDUSTRY":
                    rareMaterialsProduction += level * 20;
                    break;
                case "WEAPON INDUSTRY":
                    suppliesProduction += level * 50;
                    componentsProduction += level * 30;
                    break;
                case "CITY FARM":
                case "RURAL FARM":
                    suppliesProduction += level * 30;
                    manpowerProduction += level * 50;
                    break;
            }
        }
        
        // Apply production rates
        city.getStats().setResourceProduction(ResourceType.SUPPLIES, suppliesProduction);
        city.getStats().setResourceProduction(ResourceType.COMPONENTS, componentsProduction);
        city.getStats().setResourceProduction(ResourceType.FUEL, fuelProduction);
        city.getStats().setResourceProduction(ResourceType.ELECTRONICS, electronicsProduction);
        city.getStats().setResourceProduction(ResourceType.RARE_MATERIALS, rareMaterialsProduction);
        city.getStats().setResourceProduction(ResourceType.MONEY, moneyProduction);
        city.getStats().setResourceProduction(ResourceType.MANPOWER, manpowerProduction);
    }
    
    /**
     * Check if city has enough resources for unit production
     */
    public static boolean canProduceUnit(Cities city, String unitType) {
        return city.getStats().canProduceUnit(unitType);
    }
    
    /**
     * Get production time for a unit
     */
    public static int getProductionTime(Cities city, String unitType) {
        int baseTime = switch (unitType.toUpperCase()) {
            case "INFANTRY" -> 5;
            case "TANK" -> 15;
            case "AIRCRAFT" -> 20;
            case "SHIP" -> 25;
            default -> 10;
        };
        
        // Apply mobilization speed bonus
        int speedBonus = city.getStats().getMobilizationSpeed();
        int adjustedTime = (baseTime * (100 - speedBonus)) / 100;
        
        return Math.max(1, adjustedTime);
    }
}
