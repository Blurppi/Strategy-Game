package com.militarygame.map.europe;

import com.militarygame.countries.*;
import java.util.ArrayList;
import java.util.List;

public class County {
    private String name;
    private String code;              // e.g., "75" for Paris
    private Countries owner;
    private CountyType type;
    private int x, y;                 // Center coordinates
    private int width, height;        // Region dimensions
    private List<Tile> tiles;
    private int population;
    private int defensePower;         // How hard to conquer
    
    public County(String name, String code, int x, int y, int width, int height, CountyType type) {
        this.name = name;
        this.code = code;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.type = type;
        this.tiles = new ArrayList<>();
        this.population = 100000;
        this.defensePower = calculateDefense(type);
    }
    
    private int calculateDefense(CountyType type) {
        switch(type) {
            case CAPITAL: return 50;
            case MAJOR: return 30;
            case MEDIUM: return 15;
            case MINOR: return 5;
            default: return 0;
        }
    }
    
    public void addTile(Tile tile) {
        tiles.add(tile);
    }
    
    public List<Tile> getTiles() {
        return new ArrayList<>(tiles);
    }
    
    // Getters and setters
    public String getName() { return name; }
    public String getCode() { return code; }
    public Countries getOwner() { return owner; }
    public void setOwner(Countries owner) { this.owner = owner; }
    public CountyType getType() { return type; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getPopulation() { return population; }
    public int getDefensePower() { return defensePower; }
    public int getTileCount() { return tiles.size();}
    }