package com.militarygame.weapons.gun.France;

public class Famas {

}
