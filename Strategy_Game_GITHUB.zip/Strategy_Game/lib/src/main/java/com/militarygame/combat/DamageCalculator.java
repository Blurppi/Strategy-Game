package com.militarygame.combat;

public class DamageCalculator {

}
