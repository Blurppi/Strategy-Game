package com.militarygame.util;

public class MathUtils {

}
