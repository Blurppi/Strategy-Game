package com.militarygame.units;

import com.militarygame.countries.Countries;
import com.militarygame.map.europe.EuropeTile;
import java.util.*;

public class Units {
    private String id;
    private String name;
    private UnitsType type;
    private Countries owner;
    
    // Position
    private EuropeTile currentTile;
    protected int x, y;  // CHANGED TO PROTECTED
    
    // Combat stats - CHANGED TO PROTECTED
    protected int health;
    protected int maxHealth;
    protected int attack;
    protected int defense;
    protected int attackRange;
    
    // Movement - CHANGED TO PROTECTED
    protected int movementPoints;
    protected int maxMovementPoints;
    protected int movementSpeed;
    
    // Experience and level
    private int experience;
    private int level;
    private int veterancy;
    
    // Status
    protected boolean isMoving;  // CHANGED TO PROTECTED
    protected boolean isInCombat;  // CHANGED TO PROTECTED
    protected boolean isAlive;  // CHANGED TO PROTECTED
    protected UnitsStatus status;  // CHANGED TO PROTECTED
    
    // Supplies and fuel - ALREADY PROTECTED
    protected int ammunition;
    protected int maxAmmunition;
    protected int fuel;
    protected int maxFuel;
    protected int supplies;
    protected int maxSupplies;
    
    // Crew - CHANGED TO PROTECTED
    protected int crewHealth;
    protected int maxCrewHealth;
    
    // Special abilities
    private List<String> abilities;
    private Map<String, Integer> activeAbilities;
    
    // Upgrades and equipment
    private List<String> upgrades;
    private Map<String, Boolean> equipment;
    
    public Units(String name, UnitsType type, Countries owner, int x, int y) {
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.type = type;
        this.owner = owner;
        this.x = x;
        this.y = y;
        
        // Initialize stats based on unit type
        initializeStats(type);
        
        this.isMoving = false;
        this.isInCombat = false;
        this.isAlive = true;
        this.status = UnitsStatus.READY;
        
        this.abilities = new ArrayList<>();
        this.activeAbilities = new HashMap<>();
        
        this.upgrades = new ArrayList<>();
        this.equipment = new HashMap<>();
    }
    
    /**
     * Initialize unit stats based on type
     */
    private void initializeStats(UnitsType type) {
        switch (type) {
            case INFANTRY:
                this.maxHealth = 50;
                this.attack = 12;
                this.defense = 8;
                this.attackRange = 1;
                this.movementSpeed = 3;
                this.maxAmmunition = 300;
                this.maxFuel = 100;
                this.maxSupplies = 100;
                break;
                
            case TANK:
                this.maxHealth = 120;
                this.attack = 25;
                this.defense = 18;
                this.attackRange = 3;
                this.movementSpeed = 2;
                this.maxAmmunition = 50;
                this.maxFuel = 200;
                this.maxSupplies = 150;
                break;
                
            case AIRCRAFT:
                this.maxHealth = 70;
                this.attack = 30;
                this.defense = 5;
                this.attackRange = 8;
                this.movementSpeed = 6;
                this.maxAmmunition = 100;
                this.maxFuel = 300;
                this.maxSupplies = 80;
                break;
                
            case ARTILLERY:
                this.maxHealth = 60;
                this.attack = 40;
                this.defense = 4;
                this.attackRange = 10;
                this.movementSpeed = 1;
                this.maxAmmunition = 80;
                this.maxFuel = 120;
                this.maxSupplies = 120;
                break;
                
            case HELICOPTER:
                this.maxHealth = 80;
                this.attack = 28;
                this.defense = 6;
                this.attackRange = 6;
                this.movementSpeed = 5;
                this.maxAmmunition = 120;
                this.maxFuel = 250;
                this.maxSupplies = 100;
                break;
                
            case ANTI_AIR:
                this.maxHealth = 50;
                this.attack = 22;
                this.defense = 8;
                this.attackRange = 7;
                this.movementSpeed = 2;
                this.maxAmmunition = 60;
                this.maxFuel = 150;
                this.maxSupplies = 100;
                break;
                
            case SHIP:
                this.maxHealth = 200;
                this.attack = 35;
                this.defense = 15;
                this.attackRange = 12;
                this.movementSpeed = 3;
                this.maxAmmunition = 150;
                this.maxFuel = 500;
                this.maxSupplies = 300;
                break;
                
            case SUBMARINE:
                this.maxHealth = 150;
                this.attack = 32;
                this.defense = 20;
                this.attackRange = 10;
                this.movementSpeed = 2;
                this.maxAmmunition = 100;
                this.maxFuel = 400;
                this.maxSupplies = 250;
                break;
                
            case TRANSPORT:
                this.maxHealth = 40;
                this.attack = 0;
                this.defense = 5;
                this.attackRange = 0;
                this.movementSpeed = 4;
                this.maxAmmunition = 0;
                this.maxFuel = 200;
                this.maxSupplies = 500;
                break;
                
            default:
                this.maxHealth = 50;
                this.attack = 10;
                this.defense = 5;
                this.attackRange = 1;
                this.movementSpeed = 2;
                this.maxAmmunition = 100;
                this.maxFuel = 100;
                this.maxSupplies = 100;
        }
        
        // Initialize current values
        this.health = maxHealth;
        this.ammunition = maxAmmunition;
        this.fuel = maxFuel;
        this.supplies = maxSupplies;
        this.maxMovementPoints = movementSpeed;
        this.movementPoints = maxMovementPoints;
        
        this.maxCrewHealth = 100;
        this.crewHealth = maxCrewHealth;
        
        this.experience = 0;
        this.level = 1;
        this.veterancy = 0;
    }
    
    /**
     * Move unit to a new position
     */
    public boolean move(EuropeTile destination) {
        if (!canMove()) {
            System.out.println("✗ " + name + " cannot move (no movement points)");
            return false;
        }
        
        int distance = calculateDistance(currentTile, destination);
        
        if (distance > movementPoints) {
            System.out.println("✗ " + name + " cannot reach destination (too far)");
            return false;
        }
        
        // Check fuel consumption
        int fuelCost = distance * 5;
        if (fuel < fuelCost) {
            System.out.println("✗ " + name + " out of fuel");
            return false;
        }
        
        // Move unit
        this.currentTile = destination;
        this.x = destination.getX();
        this.y = destination.getY();
        this.movementPoints -= distance;
        this.fuel -= fuelCost;
        this.isMoving = true;
        this.status = UnitsStatus.MOVING;
        
        System.out.println("✓ " + name + " moved to (" + x + "," + y + ")");
        return true;
    }
    
    /**
     * Calculate distance between two tiles
     */
    private int calculateDistance(EuropeTile from, EuropeTile to) {
        if (from == null || to == null) return 0;
        int dx = Math.abs(from.getX() - to.getX());
        int dy = Math.abs(from.getY() - to.getY());
        return (int) Math.sqrt(dx * dx + dy * dy);
    }
    
    /**
     * Attack another unit
     */
    public void attack(Units target) {
        if (!canAttack()) {
            System.out.println("✗ " + name + " cannot attack (out of ammunition or supplies)");
            return;
        }
        
        if (calculateDistance(currentTile, target.currentTile) > attackRange) {
            System.out.println("✗ " + name + " cannot reach target (out of range)");
            return;
        }
        
        // Check ammunition
        if (ammunition <= 0) {
            System.out.println("✗ " + name + " out of ammunition");
            return;
        }
        
        // Calculate damage
        int baseDamage = attack;
        int veterancyBonus = veterancy * 2;
        int defenseReduction = target.defense / 2;
        int totalDamage = baseDamage + veterancyBonus - defenseReduction;
        
        // Apply randomness (±20%)
        int variance = (int) (totalDamage * 0.2);
        totalDamage += (Math.random() * variance) - (variance / 2);
        totalDamage = Math.max(1, totalDamage);
        
        // Apply damage
        target.takeDamage(totalDamage);
        this.ammunition -= 10;
        this.isInCombat = true;
        this.status = UnitsStatus.ATTACKING;
        
        // Gain experience
        addExperience(50);
        
        System.out.println("⚔ " + name + " attacked " + target.getName() + " for " + totalDamage + " damage");
    }
    
    /**
     * Take damage
     */
    public void takeDamage(double damage) {
        int actualDamage = (int) damage;
        
        // Defense reduces damage
        double damageReduction = defense * 0.05;
        actualDamage = (int) (actualDamage * (1 - damageReduction));
        actualDamage = Math.max(1, actualDamage);
        
        this.health -= actualDamage;
        
        if (health <= 0) {
            health = 0;
            isAlive = false;
            status = UnitsStatus.DESTROYED;
            System.out.println("💀 " + name + " has been destroyed!");
        } else if (health < maxHealth / 3) {
            status = UnitsStatus.DAMAGED;
        }
    }
    
    /**
     * Repair unit
     */
    public void repair(int amount) {
        int oldHealth = health;
        this.health = Math.min(health + amount, maxHealth);
        
        if (status == UnitsStatus.DAMAGED && health >= maxHealth / 3) {
            status = UnitsStatus.READY;
        }
        
        System.out.println("✓ " + name + " repaired (+" + (health - oldHealth) + " health)");
    }
    
    /**
     * Resupply unit
     */
    public void resupply() {
        this.ammunition = maxAmmunition;
        this.fuel = maxFuel;
        this.supplies = maxSupplies;
        System.out.println("✓ " + name + " resupplied");
    }
    
    /**
     * Retreat from combat
     */
    public void retreat() {
        this.isInCombat = false;
        this.status = UnitsStatus.RETREATING;
        this.movementPoints = maxMovementPoints;
        System.out.println("🏃 " + name + " is retreating");
    }
    
    /**
     * Add experience and level up
     */
    public void addExperience(int exp) {
        this.experience += exp;
        
        // Level up every 500 experience
        int newLevel = 1 + (experience / 500);
        
        if (newLevel > level) {
            levelUp();
        }
    }
    
    /**
     * Level up unit
     */
    private void levelUp() {
        this.level++;
        if (veterancy < 5) {
            this.veterancy++;
        }
        
        // Stat improvements on level up
        this.maxHealth += 10;
        this.health = maxHealth;
        this.attack += 2;
        this.defense += 1;
        
        System.out.println("⬆ " + name + " reached level " + level + "!");
    }
    
    /**
     * Add ability to unit
     */
    public void addAbility(String abilityName) {
        if (!abilities.contains(abilityName)) {
            abilities.add(abilityName);
            activeAbilities.put(abilityName, 0);
            System.out.println("✓ " + name + " learned " + abilityName);
        }
    }
    
    /**
     * Use ability
     */
    public boolean useAbility(String abilityName, Units target) {
        if (!abilities.contains(abilityName)) {
            System.out.println("✗ " + name + " doesn't have " + abilityName);
            return false;
        }
        
        int cooldown = activeAbilities.getOrDefault(abilityName, 0);
        if (cooldown > 0) {
            System.out.println("✗ " + abilityName + " is on cooldown for " + cooldown + " more turns");
            return false;
        }
        
        System.out.println("🌟 " + name + " used " + abilityName);
        activeAbilities.put(abilityName, 3);
        return true;
    }
    
    /**
     * Add upgrade to unit
     */
    public void addUpgrade(String upgradeName) {
        if (!upgrades.contains(upgradeName)) {
            upgrades.add(upgradeName);
            
            // Apply upgrade bonuses
            switch (upgradeName) {
                case "Enhanced Armor":
                    this.defense += 3;
                    this.maxHealth += 20;
                    break;
                case "Improved Engine":
                    this.movementSpeed += 1;
                    this.maxMovementPoints += 1;
                    break;
                case "Better Weapons":
                    this.attack += 5;
                    this.maxAmmunition += 50;
                    break;
                case "Advanced Electronics":
                    this.attackRange += 1;
                    break;
            }
            
            System.out.println("✓ " + name + " upgraded with " + upgradeName);
        }
    }
    
    /**
     * Update unit each turn
     */
    public void update() {
        if (!isAlive) return;
        
        // Regenerate movement points
        if (movementPoints < maxMovementPoints) {
            movementPoints = maxMovementPoints;
        }
        
        // Consume fuel (idling)
        if (fuel > 0) {
            fuel -= 1;
        }
        
        // Consume supplies
        if (supplies > 0) {
            supplies -= 1;
        }
        
        // Crew health regeneration
        if (crewHealth < maxCrewHealth) {
            crewHealth = Math.min(crewHealth + 5, maxCrewHealth);
        }
        
        // Update ability cooldowns
        for (String ability : activeAbilities.keySet()) {
            int cooldown = activeAbilities.get(ability);
            if (cooldown > 0) {
                activeAbilities.put(ability, cooldown - 1);
            }
        }
        
        // Reset combat status if not in combat
        if (!isInCombat) {
            status = UnitsStatus.READY;
        }
        
        // Check critical status
        if (fuel < 10) {
            System.out.println("⚠ " + name + " is running low on fuel!");
        }
        if (ammunition < 10) {
            System.out.println("⚠ " + name + " is running low on ammunition!");
        }
    }
    
    /**
     * Check if unit can move
     */
    public boolean canMove() {
        return isAlive && movementPoints > 0 && fuel > 0;
    }
    
    /**
     * Check if unit can attack
     */
    public boolean canAttack() {
        return isAlive && ammunition > 0 && supplies > 0 && health > 0;
    }
    
    // ===== GETTERS & SETTERS =====
    
    public String getId() { return id; }
    public String getName() { return name; }
    public UnitsType getType() { return type; }
    public Countries getOwner() { return owner; }
    public void setOwner(Countries owner) { this.owner = owner; }
    
    public EuropeTile getCurrentTile() { return currentTile; }
    public void setCurrentTile(EuropeTile tile) { this.currentTile = tile; }
    public int getX() { return x; }
    public int getY() { return y; }
    
    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }
    public int getAttack() { return attack; }
    public int getDefense() { return defense; }
    public int getAttackRange() { return attackRange; }
    
    public int getMovementPoints() { return movementPoints; }
    public int getMaxMovementPoints() { return maxMovementPoints; }
    public int getMovementSpeed() { return movementSpeed; }
    
    public int getExperience() { return experience; }
    public int getLevel() { return level; }
    public int getVeterancy() { return veterancy; }
    
    public int getAmmunition() { return ammunition; }
    public int getMaxAmmunition() { return maxAmmunition; }
    public int getFuel() { return fuel; }
    public int getMaxFuel() { return maxFuel; }
    public int getSupplies() { return supplies; }
    public int getMaxSupplies() { return maxSupplies; }
    
    public int getCrewHealth() { return crewHealth; }
    public int getMaxCrewHealth() { return maxCrewHealth; }
    
    public boolean isAlive() { return isAlive; }
    public boolean isInCombat() { return isInCombat; }
    public UnitsStatus getStatus() { return status; }
    
    public List<String> getAbilities() { return new ArrayList<>(abilities); }
    public List<String> getUpgrades() { return new ArrayList<>(upgrades); }
}