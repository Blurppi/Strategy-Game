package com.militarygame.countries;

public class Russia {

}
