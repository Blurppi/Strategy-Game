package com.militarygame.map.europe;
import com.militarygame.units.UnitsType;

public class Tile {
    private int x;
    private int y;
    private TerrainType terrain;
    private County region;
    private boolean isWalkable;
    private boolean isWater;
    
    public Tile(int x, int y, TerrainType terrain) {
        this.x = x;
        this.y = y;
        this.terrain = terrain;
        this.region = null;
        this.isWalkable = true;
        this.isWater = (terrain == TerrainType.WATER);
    }
    
    /**
     * Check if this tile can be walked on
     */
    public boolean canWalkOn(UnitsType unitType) {
        switch (unitType) {
            case SUBMARINE:
            case SHIP:
                return isWater; // Navy units only on water
            case AIRCRAFT:
            case HELICOPTER:
                return true; // Air units can go anywhere
            default:
                return isWalkable && !isWater; // Land units avoid water
        }
    }
    
    /**
     * Get movement cost for a unit type
     */
    public int getMovementCost(UnitsType unitType) {
        if (!canWalkOn(unitType)) {
            return Integer.MAX_VALUE; // Impassable
        }
        
        switch (terrain) {
            case GRASS:
                return 1;
            case FOREST:
                return 2;
            case MOUNTAIN:
                return 3;
            case WATER:
                return 2;
            case DESERT:
                return 2;
            case URBAN:
                return 1;
            case SWAMP:
                return 4;
            default:
                return 1;
        }
    }
    
    /**
     * Get defense bonus for units on this terrain
     */
    public int getDefenseBonus() {
        switch (terrain) {
            case FOREST:
                return 2;
            case MOUNTAIN:
                return 3;
            case URBAN:
                return 2;
            case SWAMP:
                return 1;
            default:
                return 0;
        }
    }
    
    /**
     * Check if this tile has line of sight to another tile
     */
    public boolean hasLineOfSight(Tile other) {
        if (other == null) return false;
        
        // Simple line of sight - blocked by mountains
        return !(this.terrain == TerrainType.MOUNTAIN || 
                 other.terrain == TerrainType.MOUNTAIN);
    }
    
    // ===== GETTERS & SETTERS =====
    
    public int getX() { return x; }
    public int getY() { return y; }
    
    public TerrainType getTerrain() { return terrain; }
    public void setTerrain(TerrainType terrain) { 
        this.terrain = terrain;
        this.isWater = (terrain == TerrainType.WATER);
    }
    
    public County getRegion() { return region; }
    public void setRegion(County region) { this.region = region; }
    
    public boolean isWalkable() { return isWalkable; }
    public void setWalkable(boolean walkable) { this.isWalkable = walkable; }
    
    public boolean isWater() { return isWater; }
    
    @Override
    public String toString() {
        return "Tile(" + x + "," + y + ")[" + terrain + "]";
    }
    
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Tile)) return false;
        Tile other = (Tile) obj;
        return this.x == other.x && this.y == other.y;
    }
    
    @Override
    public int hashCode() {
        return x * 31 + y;
    }
}