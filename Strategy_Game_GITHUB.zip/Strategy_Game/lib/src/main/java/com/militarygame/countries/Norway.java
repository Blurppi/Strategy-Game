package com.militarygame.countries;

public class Norway {

}
