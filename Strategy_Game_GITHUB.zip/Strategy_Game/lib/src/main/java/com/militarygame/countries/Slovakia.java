package com.militarygame.countries;

public class Slovakia {

}
