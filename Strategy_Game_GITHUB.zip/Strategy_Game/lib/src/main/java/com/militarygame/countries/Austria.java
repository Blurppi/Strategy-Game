package com.militarygame.countries;

public class Austria {

}
