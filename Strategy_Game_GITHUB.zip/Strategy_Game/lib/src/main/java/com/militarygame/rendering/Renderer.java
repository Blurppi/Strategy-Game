package com.militarygame.rendering;

public class Renderer {

}
