package com.militarygame.util;

public class Logger {

}
