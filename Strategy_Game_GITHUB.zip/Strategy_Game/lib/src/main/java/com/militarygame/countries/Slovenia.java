package com.militarygame.countries;

public class Slovenia {

}
