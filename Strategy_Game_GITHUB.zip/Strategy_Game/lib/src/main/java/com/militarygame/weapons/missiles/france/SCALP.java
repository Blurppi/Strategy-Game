package com.militarygame.weapons.missiles.france;

public class SCALP {

}
