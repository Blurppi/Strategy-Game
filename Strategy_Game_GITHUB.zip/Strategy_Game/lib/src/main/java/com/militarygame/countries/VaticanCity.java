package com.militarygame.countries;

public class VaticanCity {

}
