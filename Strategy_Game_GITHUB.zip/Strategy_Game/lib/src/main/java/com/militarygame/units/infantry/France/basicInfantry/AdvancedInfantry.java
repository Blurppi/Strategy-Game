package com.militarygame.units.infantry.France.basicInfantry;

public class AdvancedInfantry {

}
