package com.militarygame.countries;

public class Switzerland {

}
