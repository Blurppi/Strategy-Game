package com.militarygame.units.aerial;

import com.militarygame.countries.Countries;
import com.militarygame.units.Units;
import com.militarygame.units.UnitsType;
import com.militarygame.units.UnitsStatus;
import com.militarygame.units.aerial.weapons.FuelTank;
import java.util.*;

public class Aircrafts extends Units {
    
    // Aircraft-specific stats
    protected int altitude;
    protected int maxAltitude;
    protected int cruiseSpeed;
    protected int maxSpeed;
    protected int radar;
    protected int maxRadar;
    protected int ecm;
    protected int maxECM;
    
    // Aircraft systems
    protected boolean isRadarActive;
    protected boolean isStealthMode;
    protected boolean isAfterburnerActive;
    
    // Loadout
    protected int hardpoints;
    protected String[] weapons;
    protected List<FuelTank> fuelTanks; // External fuel tanks
    
    // Flight status
    protected boolean isFlying;
    protected boolean isLanding;
    protected int fuelBurn;
    protected int engineHealth;
    protected int maxEngineHealth;
    
    public Aircrafts(String name, Countries owner, int x, int y) {
        super(name, UnitsType.AIRCRAFT, owner, x, y);
        initializeAircraft();
    }
    
    /**
     * Initialize aircraft-specific stats
     */
    protected void initializeAircraft() {
        this.maxAltitude = 10000;
        this.altitude = 0;
        this.cruiseSpeed = 800;
        this.maxSpeed = 1200;
        this.radar = 100;
        this.maxRadar = 100;
        this.ecm = 80;
        this.maxECM = 80;
        
        this.isRadarActive = false;
        this.isStealthMode = false;
        this.isAfterburnerActive = false;
        
        this.hardpoints = 6;
        this.weapons = new String[hardpoints];
        
        this.fuelTanks = new ArrayList<>();
        
        this.isFlying = false;
        this.isLanding = false;
        this.fuelBurn = 5;
        this.engineHealth = 100;
        this.maxEngineHealth = 100;
    }
    
    /**
     * Add external fuel tank
     */
    public void addFuelTank(String tankName, int capacity) {
        FuelTank tank = new FuelTank(tankName, capacity);
        fuelTanks.add(tank);
        this.maxFuel += capacity;
        this.fuel += capacity;
        System.out.println("✓ " + tankName + " (" + capacity + "L) added (Total fuel: " + fuel + "L)");
    }
    
    /**
     * Remove fuel tank
     */
    public void removeFuelTank(String tankName) {
        for (FuelTank tank : fuelTanks) {
            if (tank.getName().equalsIgnoreCase(tankName)) {
                this.maxFuel -= tank.getCapacity();
                this.fuel -= tank.getCurrentFuel();
                fuelTanks.remove(tank);
                System.out.println("✓ " + tankName + " removed");
                return;
            }
        }
        System.out.println("✗ Fuel tank not found: " + tankName);
    }
    
    /**
     * Get total external fuel tank capacity
     */
    public int getTotalFuelTankCapacity() {
        int total = 0;
        for (FuelTank tank : fuelTanks) {
            total += tank.getCapacity();
        }
        return total;
    }
    
    /**
     * Get list of fuel tanks
     */
    public List<FuelTank> getFuelTanks() {
        return new ArrayList<>(fuelTanks);
    }
    
    /**
     * Take off from ground
     */
    public boolean takeOff() {
        if (isFlying) {
            System.out.println("✗ " + getName() + " is already flying");
            return false;
        }
        
        if (getFuel() < 50) {
            System.out.println("✗ " + getName() + " doesn't have enough fuel to take off");
            return false;
        }
        
        if (getHealth() < getMaxHealth() / 2) {
            System.out.println("✗ " + getName() + " is too damaged to take off");
            return false;
        }
        
        this.isFlying = true;
        this.altitude = 1000;
        this.setStatus(UnitsStatus.MOVING);
        System.out.println("✈ " + getName() + " took off (Altitude: " + altitude + "m)");
        return true;
    }
    
    /**
     * Land aircraft
     */
    public boolean land() {
        if (!isFlying) {
            System.out.println("✗ " + getName() + " is not flying");
            return false;
        }
        
        this.altitude = 0;
        this.isFlying = false;
        this.isLanding = false;
        this.setStatus(UnitsStatus.READY);
        System.out.println("✈ " + getName() + " landed");
        return true;
    }
    
    /**
     * Change altitude
     */
    public boolean changeAltitude(int newAltitude) {
        if (!isFlying) {
            System.out.println("✗ " + getName() + " must be flying to change altitude");
            return false;
        }
        
        if (newAltitude < 0 || newAltitude > maxAltitude) {
            System.out.println("✗ Invalid altitude: " + newAltitude);
            return false;
        }
        
        int altitudeDelta = Math.abs(newAltitude - altitude);
        int fuelNeeded = altitudeDelta / 100;
        
        if (getFuel() < fuelNeeded) {
            System.out.println("✗ " + getName() + " doesn't have enough fuel");
            return false;
        }
        
        this.altitude = newAltitude;
        this.setFuel(getFuel() - fuelNeeded);
        System.out.println("✈ " + getName() + " changed altitude to " + newAltitude + "m");
        return true;
    }
    
    /**
     * Activate radar
     */
    public void activateRadar() {
        if (!isRadarActive) {
            this.isRadarActive = true;
            this.fuelBurn += 2;
            System.out.println("📡 " + getName() + " radar activated");
        }
    }
    
    /**
     * Deactivate radar
     */
    public void deactivateRadar() {
        if (isRadarActive) {
            this.isRadarActive = false;
            this.fuelBurn -= 2;
            System.out.println("📡 " + getName() + " radar deactivated");
        }
    }
    
    /**
     * Activate stealth mode
     */
    public void activateStealth() {
        if (!isStealthMode) {
            this.isStealthMode = true;
            this.fuelBurn += 3;
            this.defense += 5;
            System.out.println("🌫 " + getName() + " stealth mode activated");
        }
    }
    
    /**
     * Deactivate stealth mode
     */
    public void deactivateStealth() {
        if (isStealthMode) {
            this.isStealthMode = false;
            this.fuelBurn -= 3;
            this.defense -= 5;
            System.out.println("🌫 " + getName() + " stealth mode deactivated");
        }
    }
    
    /**
     * Activate afterburner
     */
    public void activateAfterburner() {
        if (!isAfterburnerActive && getFuel() > 20) {
            this.isAfterburnerActive = true;
            this.fuelBurn += 5;
            this.setMovementSpeed(getMovementSpeed() + 2);
            System.out.println("🔥 " + getName() + " afterburner activated");
        }
    }
    
    /**
     * Deactivate afterburner
     */
    public void deactivateAfterburner() {
        if (isAfterburnerActive) {
            this.isAfterburnerActive = false;
            this.fuelBurn -= 5;
            this.setMovementSpeed(getMovementSpeed() - 2);
            System.out.println("🔥 " + getName() + " afterburner deactivated");
        }
    }
    
    /**
     * Equip weapon to hardpoint
     */
    public boolean equipWeapon(int hardpointIndex, String weaponName) {
        if (hardpointIndex < 0 || hardpointIndex >= hardpoints) {
            System.out.println("✗ Invalid hardpoint: " + hardpointIndex);
            return false;
        }
        
        this.weapons[hardpointIndex] = weaponName;
        System.out.println("✓ " + weaponName + " equipped to hardpoint " + hardpointIndex);
        return true;
    }
    
    /**
     * Fire missile
     */
    public void fireMissile(int hardpointIndex, Units target) {
        if (hardpointIndex < 0 || hardpointIndex >= hardpoints) {
            System.out.println("✗ Invalid hardpoint: " + hardpointIndex);
            return;
        }
        
        if (weapons[hardpointIndex] == null) {
            System.out.println("✗ No weapon equipped at hardpoint " + hardpointIndex);
            return;
        }
        
        if (getAmmunition() <= 0) {
            System.out.println("✗ " + getName() + " out of ammunition");
            return;
        }
        
        int missileDamage = getAttack() + 10;
        target.takeDamage(missileDamage);
        this.setAmmunition(getAmmunition() - 1);
        
        System.out.println("🚀 " + getName() + " fired " + weapons[hardpointIndex] + " at " + target.getName());
    }
    
    /**
     * Update aircraft each turn
     */
    @Override
    public void update() {
        if (!isAlive()) return;
        
        if (isFlying) {
            int fuelConsumption = fuelBurn;
            
            if (isAfterburnerActive) {
                fuelConsumption += 5;
            }
            
            if (isStealthMode) {
                fuelConsumption += 3;
            }
            
            this.setFuel(getFuel() - fuelConsumption);
            
            if (getFuel() < 10) {
                System.out.println("⚠ " + getName() + " fuel critical - attempting to land");
                land();
            }
        }
        
        if (getHealth() < getMaxHealth()) {
            engineHealth = (getHealth() * 100) / getMaxHealth();
        }
        
        if (isRadarActive) {
            this.ecm = Math.max(0, ecm - 1);
        }
        
        if (!isRadarActive && ecm < maxECM) {
            this.ecm = Math.min(ecm + 1, maxECM);
        }
        
        super.update();
    }
    
    // Helper setters
    protected void setStatus(UnitsStatus status) {
        this.status = status;
    }
    
    protected void setMovementSpeed(int speed) {
        this.movementSpeed = Math.max(1, speed);
    }
    
    protected void setFuel(int fuel) {
        this.fuel = Math.max(0, Math.min(fuel, maxFuel));
    }
    
    protected void setAmmunition(int ammo) {
        this.ammunition = Math.max(0, Math.min(ammo, maxAmmunition));
    }
    
    // Getters
    public int getAltitude() { return altitude; }
    public void setAltitude(int altitude) { this.altitude = altitude; }
    public int getMaxAltitude() { return maxAltitude; }
    public void setMaxAltitude(int altitude) { this.maxAltitude = altitude; }
    
    public int getCruiseSpeed() { return cruiseSpeed; }
    public int getMaxSpeed() { return maxSpeed; }
    public void setMaxSpeed(int speed) { this.maxSpeed = speed; }
    
    public int getRadar() { return radar; }
    public int getMaxRadar() { return maxRadar; }
    
    public int getECM() { return ecm; }
    public int getMaxECM() { return maxECM; }
    
    public boolean isRadarActive() { return isRadarActive; }
    public boolean isStealthMode() { return isStealthMode; }
    public boolean isAfterburnerActive() { return isAfterburnerActive; }
    public boolean isFlying() { return isFlying; }
    
    public int getHardpoints() { return hardpoints; }
    public String[] getWeapons() { return weapons; }
    public String getWeapon(int index) {
        if (index >= 0 && index < hardpoints) {
            return weapons[index];
        }
        return null;
    }
    
    public int getEngineHealth() { return engineHealth; }
    public int getMaxEngineHealth() { return maxEngineHealth; }
    
    public int getFuelBurn() { return fuelBurn; }
}