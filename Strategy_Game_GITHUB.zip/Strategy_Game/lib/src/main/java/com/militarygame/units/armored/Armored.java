package com.militarygame.units.armored;

import com.militarygame.countries.Countries;
import com.militarygame.units.Units;
import com.militarygame.units.UnitsType;

public abstract class Armored extends Units {
    
    protected int armorLevel;
    protected int turretRotationSpeed;
    protected boolean hasTracksOrWheels; // true = tracks, false = wheels
    
    public Armored(String name, Countries owner, int x, int y) {
        super(name, UnitsType.TANK, owner, x, y);
        this.armorLevel = 1;
        this.turretRotationSpeed = 10;
        this.hasTracksOrWheels = true;
    }
    
    public int getArmorLevel() { return armorLevel; }
    public void setArmorLevel(int level) { this.armorLevel = level; }
    
    public int getTurretRotationSpeed() { return turretRotationSpeed; }
    public void setTurretRotationSpeed(int speed) { this.turretRotationSpeed = speed; }
    
    public boolean hasTracksOrWheels() { return hasTracksOrWheels; }
    public void setTracksOrWheels(boolean hasTracks) { this.hasTracksOrWheels = hasTracks; }
}
