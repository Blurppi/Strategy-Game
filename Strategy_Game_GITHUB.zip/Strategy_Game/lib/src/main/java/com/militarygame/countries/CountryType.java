package com.militarygame.countries;

public enum CountryType {
	ALBANIA("Albania"),
	ANDORRA("Androrra"),
	ARMENIA("Armenia"),
	AUSTRIA("Austria"),
	AZERBAIJAN("Azerbaijan"),
	BELARUS("Belarus"),
	BELGIUM("Belgium"),
	BOSNIANDHERZEGOVINA("Bosina And Herzegovina"),
	BULGARIA("Bulgaria"),
	CROATIA("Croatia"),
	CZECHREPUBLIC("Czech Republic"),
	DENMARK("Denmark"),
	ESTONIA("Estonia"),
	FINLAND("Finland"),
	FRANCE("France"),
	GEORGIA("Georgia"),
	GERMANY("Germany"),
	GREECE("Greece"),
	HUNGARY("Hungary"),
	ICELAND("Iceland"),
	IRELAND("Ireland"),
	ITALY("Italy"),
	KOSOVO("Kosovo"),
	LATVIA("Latvia"),
	LETTONIA("Lettonia"),
	LIECHTENSTEIN("Liechtenstein"),
	LUXEMBOURG("Luxembourg"),
	MALTA("Malta"),
	MOLDOVA("Moldova"),
	MONACO("Monaco"),
	MONTENEGRO("Montenegro"),
	NETHERLANDS("Netherlands"),
	NORTHMACEDONIA("North Macedonia"),
	NORWAY("NORWAY"),
	POLAND("Poland"),
	PORTUGAL("Portugal"),
	ROMANIA("Romania"),
	RUSSIA("Russia"),
	SANMARINO("San Marino"),
	SERBIA("Serbia"),
	SLOVAKIA("Slovakia"),
	SLOVENIA("Slovenia"),
	SPAIN("Spain"),
	SWEDEN("Sweden"),
	SWITZERLAND("Switzerland"),
	TURKEY("Turkey"),
	UK("United Kingdom"),
	UKRAINE("Ukraine"),
	VATICANCITY("Vatican City");

    
    private String displayName;
    
    CountryType(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() {
        return displayName;
    }
}
