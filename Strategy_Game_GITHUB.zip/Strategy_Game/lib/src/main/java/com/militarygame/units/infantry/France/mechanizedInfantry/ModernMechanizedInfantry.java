package com.militarygame.units.infantry.France.mechanizedInfantry;

public class ModernMechanizedInfantry {

}
