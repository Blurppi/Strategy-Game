package com.militarygame.weapons.missiles.france;

public class Magic2 {

}
