package com.militarygame.save;

public class GameData {

}
