package com.militarygame.units.aerial.weapons;

public enum Missiles {
    // Magic missiles (French, IR-guided)
    MAGIC_1("Magic 1", 18, 6, 1, 2),
    MAGIC_2("Magic 2", 22, 7, 1, 2),
    
    // Matra missiles (French, Radar-guided)
    MATRA_530("Matra 530", 28, 10, 1, 2),
    SUPER_MATRA_530("Super Matra 530", 32, 12, 1, 2),
    
    // MICA missiles (French, Advanced)
    MICA_EM("MICA EM", 35, 14, 1, 3),
    MICA_IR("MICA IR", 33, 13, 1, 3),
    
    // Meteor (Advanced, long-range)
    METEOR("Meteor", 40, 20, 1, 3),
    
    // Cannon
    CANNON_30MM("30mm Cannon", 8, 1, 20, 0);
    
    private String displayName;
    private int damage;
    private int range;
    private int ammoPerShot;
    private int cooldown;
    
    Missiles(String displayName, int damage, int range, int ammoPerShot, int cooldown) {
        this.displayName = displayName;
        this.damage = damage;
        this.range = range;
        this.ammoPerShot = ammoPerShot;
        this.cooldown = cooldown;
    }
    
    public String getDisplayName() { return displayName; }
    public int getDamage() { return damage; }
    public int getRange() { return range; }
    public int getAmmoPerShot() { return ammoPerShot; }
    public int getCooldown() { return cooldown; }
}