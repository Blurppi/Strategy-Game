package com.militarygame.events;

public class GameOverEvent {

}
